import KernelNatRecursor

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# The actual Bool.casesOn selector path

This uncompiled source candidate follows the raw-literal export-02 body:
Bool.casesOn is an ordinary abbreviation with arguments motive, major,
false branch, true branch; it delta-unfolds to four lambdas applying Bool.rec
in the order motive, false branch, true branch, major. The finite pins below
describe its annotated universe-1 installation. They have not yet been
discharged by an annotation/installation run.

Local-loop fuel is separate from knot fuel. In particular, a full WHNF
branch run at its fixed local budget is not reused at budget minus one.
No native result, expected numerical answer, or whole selector run is a
premise. Every operational function is the existing ConLeche function.
-/

namespace ADWH.Experiments.Chapter15.KernelBoolSelector

open ConLeche
open KernelLowOperation (natExpr binary)
open KernelNatRecursor (app2 app3 app4 one HeadRunsAbove RunsAbove
  neverPiPrefix iotaCerts_never_prefix plainRule)
open KernelScalarSteps (NatOperation ScalarResult)

def recName : ConLeche.Name := boolName.str "rec"
def casesName : ConLeche.Name := boolName.str "casesOn"
def boolType : Expr := .const boolName []
def boolExpr (value : Bool) : Expr :=
  .const (if value then boolTrueName else boolFalseName) []
def selected (value : Bool) (no yes : Expr) : Expr := if value then yes else no

def recCall (motive no yes major : Expr) : Expr :=
  app4 (.const recName [one]) motive no yes major
def casesCall (motive major no yes : Expr) : Expr :=
  app4 (.const casesName [one]) motive major no yes

def motiveType : Expr := .forallE boolType (.sort one) ⟨.never⟩
def recFalseType : Expr := .app (.bvar 0) (boolExpr false)
def recTrueType : Expr := .app (.bvar 1) (boolExpr true)
def recType : Expr :=
  .forallE motiveType
    (.forallE recFalseType
      (.forallE recTrueType
        (.forallE boolType (.app (.bvar 3) (.bvar 0)) ⟨.never⟩)
        ⟨.never⟩)
      ⟨.never⟩)
    ⟨.never⟩
def ruleRhs (value : Bool) : Expr :=
  .lam motiveType
    (.lam recFalseType
      (.lam recTrueType (.bvar (if value then 0 else 1)) ⟨.never⟩)
      ⟨.never⟩)
    ⟨.never⟩

def casesFalseType : Expr := .app (.bvar 1) (boolExpr false)
def casesTrueType : Expr := .app (.bvar 2) (boolExpr true)
def casesType : Expr :=
  .forallE motiveType
    (.forallE boolType
      (.forallE casesFalseType
        (.forallE casesTrueType (.app (.bvar 3) (.bvar 2)) ⟨.never⟩)
        ⟨.never⟩)
      ⟨.never⟩)
    ⟨.never⟩
def casesBody : Expr :=
  app4 (.const recName [one]) (.bvar 3) (.bvar 1) (.bvar 0) (.bvar 2)
def casesRhs : Expr :=
  .lam motiveType
    (.lam boolType
      (.lam casesFalseType (.lam casesTrueType casesBody ⟨.never⟩) ⟨.never⟩)
      ⟨.never⟩)
    ⟨.never⟩

/-- Exact operational source pins at universe 1. The environment's semantic
validity remains the installer's responsibility; none is asserted here. -/
structure BoolPins (env : Env) where
  recVal : ConstantVal
  falseVal : ConstantVal
  trueVal : ConstantVal
  casesVal : ConstantVal
  falseRawRhs : Expr
  trueRawRhs : Expr
  casesRawRhs : Expr
  recNamePin : recVal.name = recName
  falseNamePin : falseVal.name = boolFalseName
  trueNamePin : trueVal.name = boolTrueName
  casesNamePin : casesVal.name = casesName
  recStored : env.find? recName = some (.recInfo recVal 3 3
    [plainRule boolFalseName 0 falseRawRhs, plainRule boolTrueName 0 trueRawRhs])
  falseStored : env.find? boolFalseName = some (.ctorInfo falseVal 0 0)
  trueStored : env.find? boolTrueName = some (.ctorInfo trueVal 0 0)
  casesStored : env.find? casesName = some (.defnInfo casesVal casesRawRhs .abbrev)
  recLevelArity : recVal.levelParams.length = 1
  casesLevelArity : casesVal.levelParams.length = 1
  falseLevels : falseVal.levelParams = []
  trueLevels : trueVal.levelParams = []
  recTypePin : recVal.type.instantiateLevelParams recVal.levelParams [one] = recType
  falseTypePin : falseVal.type.instantiateLevelParams falseVal.levelParams [] = boolType
  trueTypePin : trueVal.type.instantiateLevelParams trueVal.levelParams [] = boolType
  casesTypePin : casesVal.type.instantiateLevelParams casesVal.levelParams [one] = casesType
  falseRhsPin : falseRawRhs.instantiateLevelParams recVal.levelParams [one] = ruleRhs false
  trueRhsPin : trueRawRhs.instantiateLevelParams recVal.levelParams [one] = ruleRhs true
  casesRhsPin : casesRawRhs.instantiateLevelParams casesVal.levelParams [one] = casesRhs

/-- The actual local WHNF loop succeeds for every sufficiently large knot
fuel and every sufficiently large local loop budget, at every scoped depth.
This predicate names the existing loop; it introduces no new evaluator. -/
def LoopRunsAbove (env : Env) (e value : Expr)
    (knotThreshold loopThreshold : Nat) : Prop :=
  ∀ fuel depth budget, knotThreshold ≤ fuel → loopThreshold ≤ budget →
    whnfLoop (pureFns .verified env fuel) env depth budget e = .ok value

private theorem majorToCtor_two_rules (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (name : ConLeche.Name) (first second : RecRule) (major : Expr) :
    majorToCtor .verified r env depth name [first, second] major = .ok major := by
  cases condition : isCtorApp env major <;>
    simp only [majorToCtor, condition]
  all_goals rfl

private theorem prepare_bool (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (pins : BoolPins env) (major : Expr) (value : Bool)
    (majorRun : r.whnf depth major = .ok (boolExpr value)) :
    prepareMajor .verified r env depth recName
      [plainRule boolFalseName 0 pins.falseRawRhs,
       plainRule boolTrueName 0 pins.trueRawRhs] major = .ok (boolExpr value) := by
  have converted : litMajorToCtor r env depth (boolExpr value) =
      .ok (boolExpr value) := rfl
  change (r.whnf depth major >>= fun majorValue =>
    litMajorToCtor r env depth majorValue >>= fun convertedMajor =>
      majorToCtor .verified r env depth recName
        [plainRule boolFalseName 0 pins.falseRawRhs,
         plainRule boolTrueName 0 pins.trueRawRhs] convertedMajor) = _
  rw [majorRun]
  dsimp only [Bind.bind, Except.bind]
  rw [converted]
  dsimp only [Bind.bind, Except.bind]
  exact majorToCtor_two_rules r env depth recName
    (plainRule boolFalseName 0 pins.falseRawRhs)
    (plainRule boolTrueName 0 pins.trueRawRhs) (boolExpr value)

private theorem rec_certificate (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (pins : BoolPins env) (motive no yes major : Expr) :
    iotaCerts r env depth true
      (pins.recVal.type.instantiateLevelParams pins.recVal.levelParams [one])
      [motive, no, yes, major] = .ok true := by
  apply iotaCerts_never_prefix
  rw [pins.recTypePin]
  simp only [List.length_cons, List.length_nil, recType, neverPiPrefix,
    PropWhen.isNever_never, Bool.true_and]

/-- Both real Bool iota cases, for an arbitrary expression whose actual
local full WHNF run produces the corresponding constructor. -/
theorem iota_bool (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (pins : BoolPins env) (motive no yes major : Expr) (value : Bool)
    (majorRun : r.whnf depth major = .ok (boolExpr value)) :
    iotaRec .verified r env depth (recCall motive no yes major) =
      .ok (some (app3 (ruleRhs value) motive no yes)) := by
  have prepared := prepare_bool r env depth pins major value majorRun
  have recCert := rec_certificate r env depth pins motive no yes (boolExpr value)
  have arity : [motive, no, yes, major].length = 3 + 1 ∧
      [one].length = pins.recVal.levelParams.length :=
    ⟨rfl, pins.recLevelArity.symm⟩
  have headEq : (recCall motive no yes major).getAppFn =
      .const recName [one] := rfl
  have argsEq : (recCall motive no yes major).getAppArgs =
      [motive, no, yes, major] := rfl
  have majorArg : [motive, no, yes, major].getD 3 (.bvar 0) = major := rfl
  cases value with
  | false =>
      have constructorHead : (boolExpr false).getAppFn =
          .const boolFalseName [] := rfl
      have constructorArgs : (boolExpr false).getAppArgs = [] := rfl
      have ruleFound :
          [plainRule boolFalseName 0 pins.falseRawRhs,
           plainRule boolTrueName 0 pins.trueRawRhs].find?
            (fun rule => rule.ctor == boolFalseName) =
            some (plainRule boolFalseName 0 pins.falseRawRhs) := rfl
      unfold iotaRec
      rw [headEq]
      dsimp only []
      rw [pins.recStored]
      dsimp only []
      rw [argsEq, ite_eq_left arity, majorArg, prepared]
      dsimp only [Bind.bind, Except.bind]
      rw [constructorHead]
      dsimp only []
      rw [pins.falseStored]
      dsimp only []
      rw [ruleFound]
      dsimp only []
      rw [constructorArgs, pins.falseLevels]
      change (iotaCerts r env depth true
          (pins.recVal.type.instantiateLevelParams pins.recVal.levelParams [one])
          [motive, no, yes, boolExpr false] >>= fun checked =>
        if checked then
          pure (some (Expr.mkAppN
            (pins.falseRawRhs.instantiateLevelParams pins.recVal.levelParams [one])
            [motive, no, yes]))
        else pure none) = _
      rw [recCert]
      change (Except.ok (some (Expr.mkAppN
        (pins.falseRawRhs.instantiateLevelParams pins.recVal.levelParams [one])
        [motive, no, yes])) : CheckM (Option Expr)) = _
      rw [pins.falseRhsPin]
      all_goals rfl
  | true =>
      have constructorHead : (boolExpr true).getAppFn =
          .const boolTrueName [] := rfl
      have constructorArgs : (boolExpr true).getAppArgs = [] := rfl
      have ruleFound :
          [plainRule boolFalseName 0 pins.falseRawRhs,
           plainRule boolTrueName 0 pins.trueRawRhs].find?
            (fun rule => rule.ctor == boolTrueName) =
            some (plainRule boolTrueName 0 pins.trueRawRhs) := rfl
      unfold iotaRec
      rw [headEq]
      dsimp only []
      rw [pins.recStored]
      dsimp only []
      rw [argsEq, ite_eq_left arity, majorArg, prepared]
      dsimp only [Bind.bind, Except.bind]
      rw [constructorHead]
      dsimp only []
      rw [pins.trueStored]
      dsimp only []
      rw [ruleFound]
      dsimp only []
      rw [constructorArgs, pins.trueLevels]
      change (iotaCerts r env depth true
          (pins.recVal.type.instantiateLevelParams pins.recVal.levelParams [one])
          [motive, no, yes, boolExpr true] >>= fun checked =>
        if checked then
          pure (some (Expr.mkAppN
            (pins.trueRawRhs.instantiateLevelParams pins.recVal.levelParams [one])
            [motive, no, yes]))
        else pure none) = _
      rw [recCert]
      change (Except.ok (some (Expr.mkAppN
        (pins.trueRawRhs.instantiateLevelParams pins.recVal.levelParams [one])
        [motive, no, yes])) : CheckM (Option Expr)) = _
      rw [pins.trueRhsPin]
      all_goals rfl

private theorem bounded_mono {bound larger : Nat} (le : bound ≤ larger) :
    ∀ {e : Expr}, e.looseBVarsBounded bound = true →
      e.looseBVarsBounded larger = true := by
  intro e
  induction e generalizing bound larger with
  | bvar i => simp_all [Expr.looseBVarsBounded]; omega
  | app fn arg ihFn ihArg =>
      intro h
      simp only [Expr.looseBVarsBounded, Bool.and_eq_true_iff] at h ⊢
      exact ⟨ihFn le h.1, ihArg le h.2⟩
  | lam domain body binderMeta ihDomain ihBody =>
      intro h
      simp only [Expr.looseBVarsBounded, Bool.and_eq_true_iff] at h ⊢
      exact ⟨ihDomain le h.1, ihBody (by omega) h.2⟩
  | forallE domain body binderMeta ihDomain ihBody =>
      intro h
      simp only [Expr.looseBVarsBounded, Bool.and_eq_true_iff] at h ⊢
      exact ⟨ihDomain le h.1, ihBody (by omega) h.2⟩
  | letE domain value body ihDomain ihValue ihBody =>
      intro h
      simp only [Expr.looseBVarsBounded, Bool.and_eq_true_iff] at h ⊢
      exact ⟨⟨ihDomain le h.1.1, ihValue le h.1.2⟩, ihBody (by omega) h.2⟩
  | proj name index e ih =>
      intro h
      simp only [Expr.looseBVarsBounded] at h ⊢
      exact ih le h
  | _ => simp [Expr.looseBVarsBounded]

private theorem instantiate_bounded {value : Expr} :
    ∀ {e : Expr} {cutoff : Nat}, e.looseBVarsBounded cutoff = true →
      e.instantiate1 value cutoff = e := by
  intro e
  induction e with
  | bvar index =>
      intro cutoff h
      simp only [Expr.looseBVarsBounded, decide_eq_true_eq] at h
      have neq : ¬ index = cutoff := by omega
      have notAbove : ¬ index > cutoff := by omega
      simp [Expr.instantiate1, neq, notAbove]
  | _ =>
      intro cutoff h
      simp_all [Expr.looseBVarsBounded, Expr.instantiate1]

private theorem instantiate_closed (e : Expr) (closed : e.looseBVarsBounded 0 = true)
    (value : Expr) (cutoff : Nat) : e.instantiate1 value cutoff = e :=
  instantiate_bounded (bounded_mono (Nat.zero_le cutoff) closed)

private theorem beta_of_head (env : Env) (fuel depth : Nat)
    (fn argument domain body : Expr)
    (headRun : whnfCore .verified env fuel depth fn =
      .ok (.lam domain body ⟨.never⟩)) :
    whnfCore .verified env (fuel + 1) depth (.app fn argument) =
      whnfCore .verified env fuel depth (body.instantiate1 argument) := by
  let r := pureFns .verified env fuel
  have hh : r.whnfCore false depth fn = .ok (.lam domain body ⟨.never⟩) := headRun
  change whnfCoreBody .verified r env false depth (.app fn argument) =
    r.whnfCore false depth (body.instantiate1 argument)
  dsimp only [whnfCoreBody]
  rw [hh]
  dsimp only [Bind.bind, Except.bind]
  rw [show betaGateFires .verified .never = true from by
    change PropWhen.isNever .never = true
    exact PropWhen.isNever_never]
  all_goals rfl

private theorem false_rhs_beta (env : Env) (fuel depth : Nat)
    (motive no yes : Expr) (noClosed : no.looseBVarsBounded 0 = true) :
    whnfCore .verified env (fuel + 4) depth (app3 (ruleRhs false) motive no yes) =
      whnfCore .verified env (fuel + 3) depth no := by
  have first : whnfCore .verified env (fuel + 2) depth (.app (ruleRhs false) motive) =
      .ok (.lam (recFalseType.instantiate1 motive)
        (.lam (recTrueType.instantiate1 motive 1) (.bvar 1) ⟨.never⟩) ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 1) depth (ruleRhs false) motive motiveType
      (.lam recFalseType (.lam recTrueType (.bvar 1) ⟨.never⟩) ⟨.never⟩) rfl).trans rfl
  have second : whnfCore .verified env (fuel + 3) depth
      (app2 (ruleRhs false) motive no) =
      .ok (.lam ((recTrueType.instantiate1 motive 1).instantiate1 no) no ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 2) depth (.app (ruleRhs false) motive) no
      (recFalseType.instantiate1 motive)
      (.lam (recTrueType.instantiate1 motive 1) (.bvar 1) ⟨.never⟩) first).trans rfl
  exact (beta_of_head env (fuel + 3) depth (app2 (ruleRhs false) motive no) yes
    ((recTrueType.instantiate1 motive 1).instantiate1 no) no second).trans
      (congrArg (whnfCore .verified env (fuel + 3) depth)
        (instantiate_closed no noClosed yes 0))

private theorem true_rhs_beta (env : Env) (fuel depth : Nat)
    (motive no yes : Expr) :
    whnfCore .verified env (fuel + 4) depth (app3 (ruleRhs true) motive no yes) =
      whnfCore .verified env (fuel + 3) depth yes := by
  have first : whnfCore .verified env (fuel + 2) depth (.app (ruleRhs true) motive) =
      .ok (.lam (recFalseType.instantiate1 motive)
        (.lam (recTrueType.instantiate1 motive 1) (.bvar 0) ⟨.never⟩) ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 1) depth (ruleRhs true) motive motiveType
      (.lam recFalseType (.lam recTrueType (.bvar 0) ⟨.never⟩) ⟨.never⟩) rfl).trans rfl
  have second : whnfCore .verified env (fuel + 3) depth
      (app2 (ruleRhs true) motive no) =
      .ok (.lam ((recTrueType.instantiate1 motive 1).instantiate1 no) (.bvar 0) ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 2) depth (.app (ruleRhs true) motive) no
      (recFalseType.instantiate1 motive)
      (.lam (recTrueType.instantiate1 motive 1) (.bvar 0) ⟨.never⟩) first).trans rfl
  exact beta_of_head env (fuel + 3) depth (app2 (ruleRhs true) motive no) yes
    ((recTrueType.instantiate1 motive 1).instantiate1 no) (.bvar 0) second

private theorem iota_short (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (pins : BoolPins env) (e : Expr)
    (head : e.getAppFn = .const recName [one])
    (short : e.getAppArgs.length ≠ 4) :
    iotaRec .verified r env depth e = .ok none := by
  have arity : ¬ (e.getAppArgs.length = 3 + 1 ∧
      [one].length = pins.recVal.levelParams.length) := by
    intro h
    exact short h.1
  unfold iotaRec
  rw [head]
  dsimp only []
  rw [pins.recStored]
  dsimp only []
  rw [ite_eq_right arity]
  all_goals rfl

private theorem head_of_no_iota (env : Env) (fuel depth : Nat)
    (fn argument : Expr)
    (notLam : fn.isLam = false)
    (headRun : whnfCore .verified env fuel depth fn = .ok fn)
    (noIota : iotaRec .verified (pureFns .verified env fuel) env depth
      (.app fn argument) = .ok none) :
    whnfCore .verified env (fuel + 1) depth (.app fn argument) =
      .ok (.app fn argument) := by
  have hh : (pureFns .verified env fuel).whnfCore false depth fn = .ok fn := headRun
  change whnfCoreBody .verified (pureFns .verified env fuel) env false depth
    (.app fn argument) = _
  dsimp only [whnfCoreBody]
  rw [hh]
  dsimp only [Bind.bind, Except.bind]
  cases fn with
  | lam =>
      change true = false at notLam
      cases notLam
  | _ =>
      dsimp only []
      rw [noIota]
      all_goals rfl

private theorem rec_prefix (env : Env) (fuel depth : Nat) (pins : BoolPins env)
    (motive no yes : Expr) :
    whnfCore .verified env (fuel + 4) depth
      (app3 (.const recName [one]) motive no yes) =
      .ok (app3 (.const recName [one]) motive no yes) := by
  have first : whnfCore .verified env (fuel + 2) depth
      (.app (.const recName [one]) motive) =
      .ok (.app (.const recName [one]) motive) :=
    head_of_no_iota env (fuel + 1) depth _ _ rfl rfl
      (iota_short _ env depth pins _ rfl (by change (1 : Nat) ≠ 4; decide))
  have second : whnfCore .verified env (fuel + 3) depth
      (app2 (.const recName [one]) motive no) =
      .ok (app2 (.const recName [one]) motive no) :=
    head_of_no_iota env (fuel + 2) depth _ _ rfl first
      (iota_short _ env depth pins _ rfl (by change (2 : Nat) ≠ 4; decide))
  exact head_of_no_iota env (fuel + 3) depth _ _ rfl second
    (iota_short _ env depth pins _ rfl (by change (3 : Nat) ≠ 4; decide))

/-- The complete actual recursor step, including the three beta reductions.
The major is normalized by the actual full WHNF child call. -/
theorem whnfCore_bool (env : Env) (fuel depth : Nat) (pins : BoolPins env)
    (motive no yes major : Expr) (value : Bool)
    (noClosed : no.looseBVarsBounded 0 = true)
    (majorRun : whnf .verified env (fuel + 5) depth major = .ok (boolExpr value)) :
    whnfCore .verified env (fuel + 6) depth (recCall motive no yes major) =
      whnfCore .verified env (fuel + 4) depth (selected value no yes) := by
  let r := pureFns .verified env (fuel + 5)
  have hh : r.whnfCore false depth (app3 (.const recName [one]) motive no yes) =
      .ok (app3 (.const recName [one]) motive no yes) :=
    rec_prefix env (fuel + 1) depth pins motive no yes
  have reduced := iota_bool r env depth pins motive no yes major value majorRun
  change whnfCoreBody .verified r env false depth
    (.app (app3 (.const recName [one]) motive no yes) major) = _
  dsimp only [whnfCoreBody]
  rw [hh]
  change (iotaRec .verified r env depth (recCall motive no yes major) >>= fun outcome =>
    match outcome with
    | some next => r.whnfCore false depth next
    | none => pure (recCall motive no yes major)) = _
  rw [reduced]
  cases value with
  | false => exact false_rhs_beta env (fuel + 1) depth motive no yes noClosed
  | true => exact true_rhs_beta env (fuel + 1) depth motive no yes

theorem headRunsAbove_bool (env : Env) (pins : BoolPins env)
    (motive no yes major head : Expr) (value : Bool)
    (majorThreshold branchThreshold : Nat)
    (noClosed : no.looseBVarsBounded 0 = true)
    (majorRun : RunsAbove env major (boolExpr value) majorThreshold)
    (branchRun : HeadRunsAbove env (selected value no yes) head branchThreshold) :
    HeadRunsAbove env (recCall motive no yes major) head
      (Nat.max majorThreshold branchThreshold + 6) := by
  intro fuel depth enough
  have majorMax := Nat.le_max_left majorThreshold branchThreshold
  have branchMax := Nat.le_max_right majorThreshold branchThreshold
  have shape : fuel = (fuel - 6) + 6 := by omega
  have hm := majorRun ((fuel - 6) + 5) depth (by omega)
  rw [shape, whnfCore_bool env (fuel - 6) depth pins motive no yes major value noClosed hm]
  exact branchRun ((fuel - 6) + 4) depth (by omega)

private theorem cases_substitution (motive major no yes : Expr)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (majorClosed : major.looseBVarsBounded 0 = true)
    (noClosed : no.looseBVarsBounded 0 = true) :
    Expr.instantiate1
      (((casesBody.instantiate1 motive 3).instantiate1 major 2).instantiate1 no 1)
      yes = recCall motive no yes major := by
  have hm := instantiate_closed motive motiveClosed
  have hc := instantiate_closed major majorClosed
  have hn := instantiate_closed no noClosed
  simp [casesBody, recCall, app4, app3, app2, Expr.instantiate1, hm, hc, hn]

/-- Four actual beta steps for the exact exported casesOn wrapper body.
The last supplied branch is never traversed by a later substitution, so no
extra closedness premise for that branch is needed by this local equation. -/
theorem whnfCore_cases_body (env : Env) (fuel depth : Nat)
    (motive major no yes : Expr)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (majorClosed : major.looseBVarsBounded 0 = true)
    (noClosed : no.looseBVarsBounded 0 = true) :
    whnfCore .verified env (fuel + 5) depth (app4 casesRhs motive major no yes) =
      whnfCore .verified env (fuel + 4) depth (recCall motive no yes major) := by
  have first : whnfCore .verified env (fuel + 2) depth (.app casesRhs motive) =
      .ok (.lam boolType
        (.lam (casesFalseType.instantiate1 motive 1)
          (.lam (casesTrueType.instantiate1 motive 2)
            (casesBody.instantiate1 motive 3) ⟨.never⟩) ⟨.never⟩) ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 1) depth casesRhs motive motiveType
      (.lam boolType
        (.lam casesFalseType (.lam casesTrueType casesBody ⟨.never⟩) ⟨.never⟩)
        ⟨.never⟩) rfl).trans rfl
  have second : whnfCore .verified env (fuel + 3) depth
      (app2 casesRhs motive major) =
      .ok (.lam ((casesFalseType.instantiate1 motive 1).instantiate1 major)
        (.lam ((casesTrueType.instantiate1 motive 2).instantiate1 major 1)
          ((casesBody.instantiate1 motive 3).instantiate1 major 2) ⟨.never⟩)
        ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 2) depth (.app casesRhs motive) major boolType
      (.lam (casesFalseType.instantiate1 motive 1)
        (.lam (casesTrueType.instantiate1 motive 2)
          (casesBody.instantiate1 motive 3) ⟨.never⟩) ⟨.never⟩) first).trans rfl
  have third : whnfCore .verified env (fuel + 4) depth
      (app3 casesRhs motive major no) =
      .ok (.lam
        (((casesTrueType.instantiate1 motive 2).instantiate1 major 1).instantiate1 no)
        (((casesBody.instantiate1 motive 3).instantiate1 major 2).instantiate1 no 1)
        ⟨.never⟩) := by
    exact (beta_of_head env (fuel + 3) depth (app2 casesRhs motive major) no
      ((casesFalseType.instantiate1 motive 1).instantiate1 major)
      (.lam ((casesTrueType.instantiate1 motive 2).instantiate1 major 1)
        ((casesBody.instantiate1 motive 3).instantiate1 major 2) ⟨.never⟩)
      second).trans rfl
  exact (beta_of_head env (fuel + 4) depth (app3 casesRhs motive major no) yes
    (((casesTrueType.instantiate1 motive 2).instantiate1 major 1).instantiate1 no)
    (((casesBody.instantiate1 motive 3).instantiate1 major 2).instantiate1 no 1)
    third).trans
      (congrArg (whnfCore .verified env (fuel + 4) depth)
        (cases_substitution motive major no yes motiveClosed majorClosed noClosed))

theorem headRunsAbove_cases_body (env : Env) (pins : BoolPins env)
    (motive major no yes head : Expr) (value : Bool)
    (majorThreshold branchThreshold : Nat)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (majorClosed : major.looseBVarsBounded 0 = true)
    (noClosed : no.looseBVarsBounded 0 = true)
    (majorRun : RunsAbove env major (boolExpr value) majorThreshold)
    (branchRun : HeadRunsAbove env (selected value no yes) head branchThreshold) :
    HeadRunsAbove env (app4 casesRhs motive major no yes) head
      (Nat.max majorThreshold branchThreshold + 7) := by
  have recRun := headRunsAbove_bool env pins motive no yes major head value
    majorThreshold branchThreshold noClosed majorRun branchRun
  intro fuel depth enough
  have shape : fuel = (fuel - 5) + 5 := by omega
  rw [shape, whnfCore_cases_body env (fuel - 5) depth motive major no yes
    motiveClosed majorClosed noClosed]
  exact recRun ((fuel - 5) + 4) depth (by omega)

private theorem iota_cases_none (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (pins : BoolPins env) (e : Expr)
    (head : e.getAppFn = .const casesName [one]) :
    iotaRec .verified r env depth e = .ok none := by
  unfold iotaRec
  rw [head]
  dsimp only []
  rw [pins.casesStored]
  all_goals rfl

private theorem cases_head (env : Env) (fuel depth : Nat) (pins : BoolPins env)
    (motive major no yes : Expr) :
    whnfCore .verified env (fuel + 5) depth (casesCall motive major no yes) =
      .ok (casesCall motive major no yes) := by
  have first : whnfCore .verified env (fuel + 2) depth
      (.app (.const casesName [one]) motive) =
      .ok (.app (.const casesName [one]) motive) :=
    head_of_no_iota env (fuel + 1) depth _ _ rfl rfl
      (iota_cases_none _ env depth pins _ rfl)
  have second : whnfCore .verified env (fuel + 3) depth
      (app2 (.const casesName [one]) motive major) =
      .ok (app2 (.const casesName [one]) motive major) :=
    head_of_no_iota env (fuel + 2) depth _ _ rfl first
      (iota_cases_none _ env depth pins _ rfl)
  have third : whnfCore .verified env (fuel + 4) depth
      (app3 (.const casesName [one]) motive major no) =
      .ok (app3 (.const casesName [one]) motive major no) :=
    head_of_no_iota env (fuel + 3) depth _ _ rfl second
      (iota_cases_none _ env depth pins _ rfl)
  exact head_of_no_iota env (fuel + 4) depth _ _ rfl third
    (iota_cases_none _ env depth pins _ rfl)

private theorem cases_unfold (env : Env) (pins : BoolPins env)
    (motive major no yes : Expr) :
    unfoldDefinition env (casesCall motive major no yes) =
      some (app4 casesRhs motive major no yes) := by
  have headEq : (casesCall motive major no yes).getAppFn =
      .const casesName [one] := rfl
  have argsEq : (casesCall motive major no yes).getAppArgs =
      [motive, major, no, yes] := rfl
  have arity : [one].length = pins.casesVal.levelParams.length :=
    pins.casesLevelArity.symm
  unfold unfoldDefinition
  rw [headEq]
  dsimp only []
  rw [pins.casesStored]
  change (if [one].length = pins.casesVal.levelParams.length then
    some (Expr.mkAppN
      (pins.casesRawRhs.instantiateLevelParams pins.casesVal.levelParams [one])
      (casesCall motive major no yes).getAppArgs)
    else none) = _
  rw [ite_eq_left arity, argsEq, pins.casesRhsPin]
  all_goals rfl

/-- Exactly one real local-loop iteration is consumed by the ordinary
wrapper delta step. This equality also exposes exhaustion at budget zero;
it never resets or silently borrows a local loop budget. -/
theorem whnfLoop_cases_delta (env : Env) (fuel depth budget : Nat)
    (pins : BoolPins env) (motive major no yes : Expr) :
    whnfLoop (pureFns .verified env (fuel + 5)) env depth (budget + 1)
        (casesCall motive major no yes) =
      whnfLoop (pureFns .verified env (fuel + 5)) env depth budget
        (app4 casesRhs motive major no yes) := by
  let r := pureFns .verified env (fuel + 5)
  have hh : r.whnfCore false depth (casesCall motive major no yes) =
      .ok (casesCall motive major no yes) :=
    cases_head env fuel depth pins motive major no yes
  change whnfStep r env depth (whnfLoop r env depth budget)
    (casesCall motive major no yes) = _
  unfold whnfStep
  rw [hh]
  change (match unfoldDefinition env (casesCall motive major no yes) with
    | some next => whnfLoop r env depth budget next
    | none => pure (casesCall motive major no yes)) = _
  rw [cases_unfold env pins motive major no yes]
  all_goals rfl

/-- Once two actual head runs agree, the existing step executes the same
literal/delta tail and the same continuation. This includes arbitrary
arithmetic children and does not assume either whole input run. -/
theorem whnfStep_eq_of_same_head (r : CoreFns CheckM) (env : Env) (depth : Nat)
    (continuation : Expr → CheckM Expr) (left right head : Expr)
    (hl : r.whnfCore false depth left = .ok head)
    (hr : r.whnfCore false depth right = .ok head) :
    whnfStep r env depth continuation left =
      whnfStep r env depth continuation right := by
  unfold whnfStep
  rw [hl, hr]
  all_goals rfl

/-- Delta plus the certified wrapper/recursor head steps transfer to the
selected branch's actual local loop with exactly one fewer iteration. -/
theorem whnfLoop_cases_select (env : Env) (fuel depth budget : Nat)
    (pins : BoolPins env) (motive major no yes head : Expr) (value : Bool)
    (majorThreshold branchThreshold : Nat)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (majorClosed : major.looseBVarsBounded 0 = true)
    (noClosed : no.looseBVarsBounded 0 = true)
    (majorRun : RunsAbove env major (boolExpr value) majorThreshold)
    (branchRun : HeadRunsAbove env (selected value no yes) head branchThreshold)
    (enough : Nat.max majorThreshold branchThreshold + 7 ≤ fuel) :
    whnfLoop (pureFns .verified env fuel) env depth (budget + 2)
        (casesCall motive major no yes) =
      whnfLoop (pureFns .verified env fuel) env depth (budget + 1)
        (selected value no yes) := by
  have bodyRun := headRunsAbove_cases_body env pins motive major no yes head value
    majorThreshold branchThreshold motiveClosed majorClosed noClosed majorRun branchRun
  have branchMax := Nat.le_max_right majorThreshold branchThreshold
  have hh : (pureFns .verified env fuel).whnfCore false depth
      (app4 casesRhs motive major no yes) = .ok head := bodyRun fuel depth enough
  have hb : (pureFns .verified env fuel).whnfCore false depth
      (selected value no yes) = .ok head := branchRun fuel depth (by omega)
  have shape : (fuel - 5) + 5 = fuel := by omega
  have delta := whnfLoop_cases_delta env (fuel - 5) depth (budget + 1)
    pins motive major no yes
  rw [shape] at delta
  rw [delta]
  change whnfStep (pureFns .verified env fuel) env depth
      (whnfLoop (pureFns .verified env fuel) env depth budget)
      (app4 casesRhs motive major no yes) =
    whnfStep (pureFns .verified env fuel) env depth
      (whnfLoop (pureFns .verified env fuel) env depth budget)
      (selected value no yes)
  exact whnfStep_eq_of_same_head _ env depth _ _ _ head hh hb

theorem loopRunsAbove_cases (env : Env) (pins : BoolPins env)
    (motive major no yes head result : Expr) (value : Bool)
    (majorThreshold headThreshold branchKnotThreshold branchLoopThreshold : Nat)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (majorClosed : major.looseBVarsBounded 0 = true)
    (noClosed : no.looseBVarsBounded 0 = true)
    (majorRun : RunsAbove env major (boolExpr value) majorThreshold)
    (branchHead : HeadRunsAbove env (selected value no yes) head headThreshold)
    (branchLoop : LoopRunsAbove env (selected value no yes) result
      branchKnotThreshold branchLoopThreshold)
    (positiveBranchBudget : 1 ≤ branchLoopThreshold) :
    LoopRunsAbove env (casesCall motive major no yes) result
      (Nat.max (Nat.max majorThreshold headThreshold + 7) branchKnotThreshold)
      (branchLoopThreshold + 1) := by
  intro fuel depth budget enoughFuel enoughBudget
  have headMax := Nat.le_max_left
    (Nat.max majorThreshold headThreshold + 7) branchKnotThreshold
  have loopMax := Nat.le_max_right
    (Nat.max majorThreshold headThreshold + 7) branchKnotThreshold
  have shape : budget = (budget - 2) + 2 := by omega
  rw [shape, whnfLoop_cases_select env fuel depth (budget - 2) pins
    motive major no yes head value majorThreshold headThreshold
    motiveClosed majorClosed noClosed majorRun branchHead (by omega)]
  exact branchLoop fuel depth ((budget - 2) + 1) (by omega) (by omega)

/-- Only an explicit bound by the unchanged fixed local budget permits the
transition from LoopRunsAbove to full WHNF. Arithmetic child calls then use
the existing full-WHNF entry point, which has its own local loop as defined. -/
theorem runsAbove_of_loop (env : Env) (e result : Expr)
    (knotThreshold loopThreshold : Nat)
    (run : LoopRunsAbove env e result knotThreshold loopThreshold)
    (withinFixedLoop : loopThreshold ≤ whnfLoopFuel) :
    RunsAbove env e result (knotThreshold + 1) := by
  intro fuel depth enough
  have shape : fuel = (fuel - 1) + 1 := by omega
  rw [shape]
  change whnfLoop (pureFns .verified env (fuel - 1)) env depth whnfLoopFuel e = _
  exact run (fuel - 1) depth whnfLoopFuel (by omega) withinFixedLoop

private theorem loop_scalar_of_head (r : CoreFns CheckM) (env : Env)
    (depth budget : Nat) (e result : Expr)
    (headRun : r.whnfCore false depth e = .ok result)
    (normal : ScalarResult env result) :
    whnfLoop r env depth (budget + 1) e = .ok result := by
  change whnfStep r env depth (whnfLoop r env depth budget) e = _
  unfold whnfStep
  rw [headRun]
  rcases normal with ⟨n, rfl⟩ | ⟨name, valueType, params, fields, rfl, found⟩
  · rfl
  · dsimp only [reduceNat, Bind.bind, Except.bind, unfoldDefinition, Expr.getAppFn]
    rw [found]
    all_goals rfl

/-- The scalar source contract with an explicit one-iteration local bound,
needed before adding a wrapper's delta cost. -/
theorem loopRunsAbove_scalar (env : Env) (e result : Expr) (headThreshold : Nat)
    (headRun : HeadRunsAbove env e result headThreshold)
    (normal : ScalarResult env result) :
    LoopRunsAbove env e result headThreshold 1 := by
  intro fuel depth budget enoughFuel enoughBudget
  have hh : (pureFns .verified env fuel).whnfCore false depth e = .ok result :=
    headRun fuel depth enoughFuel
  have shape : budget = (budget - 1) + 1 := by omega
  rw [shape]
  exact loop_scalar_of_head _ env depth (budget - 1) e result hh normal

/-- The existing fixed binary table needs two local iterations: one to
obtain its scalar result and one to finish that result. Every recursive
arithmetic child uses the existing full-WHNF entry point at the same knot
fuel, and therefore starts its own unchanged local loop. -/
theorem loopRunsAbove_binary (env : Env) (e left right result : Expr)
    (name : ConLeche.Name) (a b : Nat)
    (headThreshold leftThreshold rightThreshold : Nat)
    (operation : NatOperation name)
    (stored : natOpStored env name = true)
    (headRun : HeadRunsAbove env e (binary name left right) headThreshold)
    (leftRun : RunsAbove env left (natExpr a) leftThreshold)
    (rightRun : RunsAbove env right (natExpr b) rightThreshold)
    (table : natOpResult name a b = some result)
    (normal : ScalarResult env result) :
    LoopRunsAbove env e result
      (Nat.max 1 (Nat.max headThreshold (Nat.max leftThreshold rightThreshold))) 2 := by
  intro fuel depth budget enoughFuel enoughBudget
  have positiveMax := Nat.le_max_left 1
    (Nat.max headThreshold (Nat.max leftThreshold rightThreshold))
  have innerMax := Nat.le_max_right 1
    (Nat.max headThreshold (Nat.max leftThreshold rightThreshold))
  have headMax := Nat.le_max_left headThreshold (Nat.max leftThreshold rightThreshold)
  have childrenMax := Nat.le_max_right headThreshold (Nat.max leftThreshold rightThreshold)
  have leftMax := Nat.le_max_left leftThreshold rightThreshold
  have rightMax := Nat.le_max_right leftThreshold rightThreshold
  let r := pureFns .verified env fuel
  have hh : r.whnfCore false depth e = .ok (binary name left right) :=
    headRun fuel depth (by omega)
  have hl : r.whnf depth left = .ok (natExpr a) := leftRun fuel depth (by omega)
  have hr : r.whnf depth right = .ok (natExpr b) := rightRun fuel depth (by omega)
  have recognized :
      (name = natAddName ∨ name = natSubName ∨ name = natMulName ∨
        name = natPowName ∨ name = natBeqName ∨ name = natBleName ∨
        name = natDivName ∨ name = natModName ∨ name = natGcdName ∨
        name = natLandName ∨ name = natLorName ∨ name = natXorName ∨
        name = natShiftLeftName ∨ name = natShiftRightName) ∧
        natOpStored env name = true := ⟨operation, stored⟩
  have reduceRun : reduceNat r env depth (binary name left right) =
      .ok (some result) := by
    dsimp only [binary, reduceNat]
    rw [ite_eq_left recognized]
    rw [hl]
    dsimp only [Bind.bind, Except.bind, natExpr, rawNatLit?]
    rw [hr]
    dsimp only [Bind.bind, Except.bind, natExpr, rawNatLit?]
    exact congrArg Except.ok table
  have budgetShape : budget = (budget - 2) + 2 := by omega
  rw [budgetShape]
  change whnfStep r env depth (whnfLoop r env depth ((budget - 2) + 1)) e = _
  unfold whnfStep
  rw [hh]
  change (reduceNat r env depth (binary name left right) >>= fun reduced =>
    match reduced with
    | some value => whnfLoop r env depth ((budget - 2) + 1) value
    | none =>
        match unfoldDefinition env (binary name left right) with
        | some value => whnfLoop r env depth ((budget - 2) + 1) value
        | none => pure (binary name left right)) = _
  rw [reduceRun]
  change whnfLoop r env depth ((budget - 2) + 1) result = _
  apply loop_scalar_of_head r env depth (budget - 2) result result ?_ normal
  have fuelShape : fuel = (fuel - 1) + 1 := by omega
  rcases normal with ⟨n, rfl⟩ | ⟨name, _, _, _, rfl, _⟩
  · change whnfCore .verified env fuel depth (natExpr n) = _
    rw [fuelShape]
    all_goals rfl
  · change whnfCore .verified env fuel depth (.const name []) = _
    rw [fuelShape]
    all_goals rfl

/-- Full WHNF of the real casesOn call follows only after paying the delta
iteration and checking the resulting local threshold against the unchanged
fixed budget. The branch run is an actual smaller operational premise. -/
theorem runsAbove_cases (env : Env) (pins : BoolPins env)
    (motive major no yes head result : Expr) (value : Bool)
    (majorThreshold headThreshold branchKnotThreshold branchLoopThreshold : Nat)
    (motiveClosed : motive.looseBVarsBounded 0 = true)
    (majorClosed : major.looseBVarsBounded 0 = true)
    (noClosed : no.looseBVarsBounded 0 = true)
    (majorRun : RunsAbove env major (boolExpr value) majorThreshold)
    (branchHead : HeadRunsAbove env (selected value no yes) head headThreshold)
    (branchLoop : LoopRunsAbove env (selected value no yes) result
      branchKnotThreshold branchLoopThreshold)
    (positiveBranchBudget : 1 ≤ branchLoopThreshold)
    (withinFixedLoop : branchLoopThreshold + 1 ≤ whnfLoopFuel) :
    RunsAbove env (casesCall motive major no yes) result
      (Nat.max (Nat.max majorThreshold headThreshold + 7) branchKnotThreshold + 1) :=
  runsAbove_of_loop env _ result
    (Nat.max (Nat.max majorThreshold headThreshold + 7) branchKnotThreshold)
    (branchLoopThreshold + 1)
    (loopRunsAbove_cases env pins motive major no yes head result value
      majorThreshold headThreshold branchKnotThreshold branchLoopThreshold
      motiveClosed majorClosed noClosed majorRun branchHead branchLoop positiveBranchBudget)
    withinFixedLoop

#print axioms iota_bool
#print axioms whnfCore_bool
#print axioms headRunsAbove_bool
#print axioms whnfCore_cases_body
#print axioms headRunsAbove_cases_body
#print axioms whnfLoop_cases_delta
#print axioms whnfStep_eq_of_same_head
#print axioms whnfLoop_cases_select
#print axioms loopRunsAbove_cases
#print axioms runsAbove_of_loop
#print axioms loopRunsAbove_scalar
#print axioms loopRunsAbove_binary
#print axioms runsAbove_cases

end ADWH.Experiments.Chapter15.KernelBoolSelector
