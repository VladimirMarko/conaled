# Staged proofs for the actual Bool selector

## Status and purpose

This directory contains an **uncompiled, source-only proof variant** of
`kernel-bool-reference/source/KernelBoolSelector.lean`. It preserves every
definition, structure field, theorem statement, operational guard, fuel bound,
import, option and printed root. The original candidate and its historical
review remain unchanged. No gate, preflight, compiler, exporter, evaluator or
counter was executed while preparing this variant.

The immediate purpose is to prepare the actual `ConLeche.iotaRec`,
`whnfCore`, `unfoldDefinition` and `whnfLoop` selector contracts for a fresh
check. It introduces neither a replacement expression language nor a new
evaluator. The source still requires the exact `BoolPins env` premises and
actual child-run equations described below.

## Accepted dependency and observed diagnostic

The proposed dependency is the corrected eight-module bundled closure from
[`kernel-bundled-reference` complete-02](../kernel-bundled-reference/gate/attempts/complete-02/report.json).
That saved run reports 62 accepted roots, 20 outputs, 27.806141771987313 seconds
and 834,908 KiB peak child RSS. Its raw report SHA256 is
`f44b12bcdb20a4ec5171556d55eda94aa9d766ea34666b0257ae8bcd3e8f26e4`.
The exact accepted `KernelNatRecursor.lean` has SHA256
`126beff77f617603e5da5bc0662d3c64ee8962645e9ca6262cbf7dda79e358df`.
These are proof-source and saved-result provenance; **no compiled dependency
objects are reused** by the proposed check.

The preceding bundled complete-01 terminated normally with three diagnostics
in `rec_prefix`: `decide` was asked to close application-spine length goals
that still contained free expression parameters. Its 11 Natrec reports were
all unaccepted because the module failed, including five reports that contained
only allowed axioms. The later accepted source first changes each goal to the
closed proposition `(1 : Nat) ≠ 4`, `(2 : Nat) ≠ 4` or `(3 : Nat) ≠ 4`.
The retained [actual diagnostic log](../kernel-bundled-reference/gate/attempts/complete-01/KernelNatRecursor.stdout.log)
justifies the same preventive repair in the Bool source. **There has been no
Bool compiler attempt or observed Bool diagnostic.**

The earlier Bool inventory deliberately binds a historical failed Natrec04
source. It is retained here only as original-source and contract provenance;
it does not certify this new variant or supply the proposed dependency. The
new inventory explicitly selects the accepted corrected bundled02 source.

## Exact source changes

[`PROOF-EDITS.json`](PROOF-EDITS.json) records two ordered, reversible layers.
The first makes the three closed-length repairs in `rec_prefix`. The second
replaces four proof bodies, with their original headers unchanged:

| Proof | Change and justification |
| --- | --- |
| `prepare_bool` | Exposes the entire non-K monadic branch of `prepareMajor` for its two-rule list. A local reflexive equation states that literal conversion leaves a Bool constructor unchanged. The actual major run and that conversion are then rewritten separately. |
| `iota_bool` | Establishes small reflexive equations for the exact recursor head, argument list and major slot, then for each nullary constructor head, empty argument list and matching stored rule. Each environment match is reduced after its stored-record equation. The original recursor certificate and instantiated RHS premises are retained. |
| `iota_short` | Uses the ordinary short-arity rewrite after the stored recursor match, as in the accepted Natrec proof. |
| `cases_unfold` | Establishes the exact wrapper head and argument list, then explicitly changes to the whole universe-arity conditional before rewriting its guard and instantiated body. This avoids matching a partially reduced decision instance. |

These four bodies remove all 14 explicit default-transparency rewrite
configurations. This is a proof elaboration hypothesis. It makes no assertion
about which theorem consumed time in earlier silent failures, no performance
improvement claim and no claim that every possible Bool diagnostic is fixed.
The three length repairs and four body replacements together affect five
theorems. There is no unrelated proof refactor or print relocation.

The forward and inverse source-text checks recover the original 38,785 bytes
exactly. All 13 public and 17 private theorem headers match; the entire prefix
containing the 18 definitions and `BoolPins` is byte-identical; all 13 printed
roots retain their original order. The final source remains a legacy-format
module importing only `KernelNatRecursor`.

## Mathematical contract retained

`BoolPins` names the exact installed recursor, two nullary constructors and
ordinary `Bool.casesOn` abbreviation at universe 1. It retains the stored
record forms, declaration names, level arities, fully instantiated annotated
types and fully instantiated rule/wrapper bodies. Its 7 data fields and 19
equational guards are unchanged. Raw export records in
[`BOOL-EXPORT-PINS.json`](../kernel-bool-reference/BOOL-EXPORT-PINS.json) support
the source shape; they are not an installed environment or a proof of these
annotation guards.

The actual wrapper order is motive, major, false branch, true branch. Its
four-lambda body calls `Bool.rec` in the order motive, false branch, true
branch, major. The iota theorem normalizes an arbitrary major expression using
its actual child full-WHNF run, then selects the matching branch. It does not
assume the successful run of the whole selector being proved.

Knot fuel and local loop budget remain separate. The recursor equation has
the original `fuel + 6` to `fuel + 4` head-run relationship; the wrapper beta
composition has the original conservative threshold. Delta consumes exactly
one local-loop iteration. Scalar and binary compositions retain local
thresholds 1 and 2. Uniform loop contracts quantify over every sufficiently
large knot fuel and local budget at every scoped depth. The final full-WHNF
transport still requires the explicit local threshold bound by the unchanged
`whnfLoopFuel`. A full branch run at its fixed budget is not silently reused
at one less than that budget.

Closedness premises remain exactly where unlifted substitution requires them.
No new premise supplies a native answer, an expected count, a whole-selector
run, an arbitrary valid environment or an assumed equality of the target
numeral.

## Proposed fresh scope and trust boundary

The exact proposed source order is the eight accepted bundled02 physical
sources, followed by this new `KernelBoolSelector` source: **9 physical
modules, 29 mathematical origins, 75 roots and 22 default outputs**. The
bundle remains one module-format source with six default outputs; the eight
legacy-format modules produce two each. This is an inventory proposal, not a
selected or executed gate and not a claim that the larger closure fits.

Any selected check must rebuild the entire proposed mathematical closure
under the unchanged cumulative 30-second, one-CPU/thread, 1-GiB RSS policy,
`-j1 -M1024`, default heartbeat/recursion/output settings and strict options.
Only `propext`, `Quot.sound` and `Classical.choice` are allowed. Source-keyed
permanent markers, raw diagnostics, exact roots, snapshots and default output
inventory remain required. No prepared experimental or upstream objects,
unsafe computation, added axioms or native decision mechanism are proposed.

This source work does not discharge the installed Bool pins, prove complete
normalization of either structural fold, install a cache/checker extension or
produce the ordinary stock-kernel `cqueens 16` numeral theorem. The accepted
Natrec step contracts are a real dependency milestone; those remaining
integration obligations stay explicit.

## Ownership

The original Bool source was authored by `regression_audit`. This isolated
proof-only variant and its source-text provenance were authored by
`validity_contracts`; root independently reviews and alone selects or executes
a future gate. The prior accepted Natrec result was executed by root under
counting_route's frozen gate. The inventory distinguishes these roles and
does not label author self-checks as an independent review.
