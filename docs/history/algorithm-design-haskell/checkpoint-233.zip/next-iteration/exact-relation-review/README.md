# Prospective exact relation certificates for the fixed guarded B functions

## Assessment

There is a sound, fairly small proof-checking idea here: an external calculation may propose signed linear identities, while a separate certificate derives each identity from the complete guarded functions using exact Shannon restrictions. The kernel need not trust the sample matrix, the nullspace algorithm or a claim that a basis has a particular rank. It can check the proposed pointwise identities directly.

This is a proposal for a different representation of equality evidence. It is not evidence that a useful identity exists, that its certificate is small, or that it would make the queens computation fit the existing limits. No nullspace calculation, new sample, symbolic expansion, identity search, counter, rank calculation or Lean run was performed for this assessment. The checkpoint and completed probe files remain unchanged.

## What the existing sample can suggest

The accepted Python replay reports 35 complete B views, 35 greedy witness requests, 19 distinct sample assignments and sampled rank 19 modulo two. The original natural-valued sample matrix therefore has 19 rows and 35 columns. Its full row rank modulo two implies full row rank over the rationals: a nonzero minor modulo two has an odd, hence nonzero, integer determinant. Thus exact rational algebra on that saved matrix could propose 16 independent sample-null directions. This is a mathematical inference from the saved result, not a new nullspace computation.

Every proposed direction is only a candidate identity. The complete B functions could still be linearly independent, with all sample relations failing at assignments absent from the fixed pool. Conversely, some or all relations might be valid. The recorded sample does not decide between these possibilities.

If a later producer picks 19 sample pivot columns and proposes expressions for the other 16 columns, the proof artifact should contain those explicit coefficients and the original full guarded-view identifiers. The checker does not need to repeat rational Gaussian elimination. It only needs to certify the resulting equalities of complete functions. Proving an upper-dimensional representation is sufficient for a contraction rewrite; proving that the selected basis is minimal is unnecessary.

The present rank evidence also limits what should be promised: the sampled B functions already exhibit 19 independent directions. The possible reduction suggested at this one cut is from 35 terms toward 19, not a collapse to a constant number of terms. Its effect on downstream contractions, other cuts and size sixteen remains unknown.

## A small generic soundness core

Reuse the existing assignment and update convention: `Assignment := Nat → Bool`, with `setVar σ v b` changing exactly one Boolean variable. Interpret each original guarded view as a natural-valued function, then embed its value into `Int`.

A relation state is a finite sparse list of pairs `(integer coefficient, complete guarded view)`. Its meaning is

\[
  L_s(\sigma)=\sum_{(c,V)\in s}c\,\bigl\langle V(\sigma)\bigr\rangle_{\mathbb Z}.
\]

The desired conclusion is `∀ σ, L_s σ = 0`. This quantifies over complete assignments, not over the saved sample. Coefficients multiply values; they do not count distinct set members.

The following generic lemmas are enough for a first checker design. These are mathematical interface specifications, not compiled Lean declarations.

1. **Exact collection preserves meaning.** Reordering terms, adding integer coefficients of the same complete view, and removing a zero coefficient preserve `L_s`. Duplicate occurrences are collected by arithmetic, never silently deduplicated.
2. **Restriction transfers through a signed sum.** If each referenced local cofactor is checked, the corresponding cofactor state denotes `σ ↦ L_s (setVar σ v b)`.
3. **Both Boolean cofactors establish an identity.** If the false and true cofactor states are identically zero, then so is the parent. For any `σ`, choose `b = σ v` and use `setVar σ v (σ v) = σ`.
4. **A constant terminal is exact.** Once every remaining view is a checked constant, accept only when the exact integer sum of coefficient times constant is zero. An empty state is the special case zero.
5. **Earlier complete dependencies compose.** A finite certificate DAG lists its states and local rules. Every referenced zero-state proof has a strictly earlier completed index. Induction on that index establishes every accepted state, including the exact candidate root state.

A simple certificate can therefore have terminal, normalization and binary-split rules. A split carries the variable, both exact normalized cofactor states, and their earlier proof IDs. If the two child states are exactly identical, both premises can reference the same already proved child. This shares a proof without changing the parent equation. A hash can accelerate a producer's lookup, but acceptance must compare exact states or an exact proved normalization; hash equality is not a premise.

The semantic part of the split lemma is small. The full concrete checker also needs a formally checked interpretation of the old guarded descriptors, validity of the selected node table, sound local cofactor rules, exact integer/state checking, and binding of the candidate to the 35 original views. Those obligations should not be hidden inside the phrase “small core.”

## Local cofactor rules and guard obligations

Choose the least remaining supported variable across the current terms under one fixed policy. Every term must then justify one of these local operations:

- A required positive or negative guard literal either becomes satisfied and is removed, or makes the term zero.
- A branch at that variable selects its actual low or high child. Its child's flat guard is combined with the remaining guard, with exact contradiction and support checks.
- A term absent from the variable is unchanged, using a checked rank or support independence fact.
- A genuine zero term disappears; a constant retains its actual integer value after the natural-to-integer embedding.

The atoms must remain full views: positive mask, negative mask and bare-core ID. Bare-core equality alone does not identify two guarded functions. Ignoring a negative mask or a residual guard can turn a relation on a region into a false global identity.

The original ordered-ADD structure makes minimum-variable restriction a plausible local operation. Arbitrary variable selection can require recursively rebuilding cofactors beneath earlier branches; that work cannot be hidden in an unmetered normalization helper. Rank bounds are sufficient for an absence rule only when they actually imply independence from the chosen variable. Source IDs and descriptor fields must be bound, child IDs earlier, masks within the fixed variable range, and guard/core conditions checked.

This identity proof uses **case distinction**, not summation over a variable. An absent variable leaves the cofactor state unchanged. There is no factor of two in the zero-identity split rule. In a later count projection, summing an absent variable still contributes the original factor of two. These operations must have separate statements and certificate tags.

Both Boolean cases remain required. A zero false cofactor does not permit skipping a live true cofactor. Likewise, negative coefficients do not justify treating a positive-valued branch as impossible. Cancellation occurs only in the exact integer relation state or its terminal arithmetic.

## Signed arithmetic and rational denominators

It is cleaner to certify integer identities than to perform rational arithmetic inside every proof step. An external calculation can clear denominators and submit, for example,

\[
 D\,B_j=\sum_{k\in P} a_{jk} B_k,
 \qquad D\in\mathbb Z_{>0},\quad a_{jk}\in\mathbb Z.
\]

The exact signed relation state represents the left side minus the right side. Checking that state identically zero is sufficient. The checker need not trust how `D` or the coefficients were obtained. If all target relations use a common denominator, that denominator and all coefficients must be exact data, not floating-point approximations.

One can state the certified result as an equality of two nonnegative weighted natural sums by moving negative terms across the equality. That may reduce the amount of generic signed-function infrastructure needed for the relation theorem itself. It does not make subsequent rational basis substitution a natural-valued operation.

For the contraction

\[
 F(x,y)=\sum_j A'_j(x) B_j(y),
\]

the explicit identities imply

\[
 D F(x,y)=\sum_{k\in P}
   \left(\sum_j a_{jk} A'_j(x)\right) B_k(y).
\]

The new coefficient functions can be negative. They cannot be silently stored in the existing natural-valued ADD semantics, and natural subtraction would truncate rather than express the required identity. Exact signed functions or an explicitly scaled positive-minus-negative representation are needed for subsequent arithmetic. Pointwise valid identities can be multiplied by other functions and summed exactly, but the representation and every denominator must survive those operations.

At a final scalar, one may prove `D * Int.ofNat Z = D * m` and cancel a checked nonzero `D`. There is no need to trust a rounded quotient. With multiple compression steps, denominator products and integer coefficient bit lengths may grow; a small number of certificate records does not itself guarantee the memory or kernel-time bound.

The integer embedding is faithful for the original natural count. That fact does not authorize assuming that every signed intermediate is nonnegative. No expected queens answer should occur among the identity premises.

## Comparison with dense multilinear expansion

Dense Boolean multilinear expansion expresses a function of the 16 B-side variables using up to `2^16 = 65,536` monomial positions. A guard containing negative literals contributes factors such as `(1-x_v)`, which can expand into many signed terms. A dense representation across all 35 B functions can expose far more coefficient entries than the single 50,000-request allowance. This is a structural upper-size observation, not a computation of the actual expansions.

Moreover, equality on Boolean inputs is equality in the Boolean-function algebra. Polynomial rewrites that use `x_v^2 = x_v` must justify that Boolean interpretation; they cannot be presented as identities of unrestricted real or rational variables.

The proposed Shannon certificate can retain the original ADD sharing and guard structure. It may close a branch early when exact coefficient collection cancels every term, or reuse a previously proved identical residual state. It never needs to materialize every monomial of each input function first.

That advantage is conditional. A relation state contains a whole coefficient vector over residual views. Two paths reaching shared source nodes may still produce different coefficient vectors. The number of distinct relation states can approach an exhaustive split tree even when the input ADDs are small. Coefficient normalization, local cofactors, state comparisons, terminal arithmetic and repeated references all require explicit work accounting. Calling an entire large normalization “one rule” would hide the computation the existing cap is meant to expose.

The saved probe validated 1,767 distinct source ancestors for its two roots, but that does not bound the number of simultaneous relation states or prove a cheap identity certificate. No certificate-size or performance claim follows from this assessment.

## A concrete future milestone, if selected

A bounded first experiment could choose one candidate deterministically from exact rational elimination of the saved 19-by-35 natural matrix—for example the first non-pivot-column relation under fixed column order, with fixed denominator clearing and sign normalization. Its target coefficients and full original views would be frozen before identity verification.

The separate identity producer would then use one ascending-variable, false-before-true Shannon policy, exact coefficient collection and memoization by full state. Every local cofactor, coefficient accumulation and proof dependency would count under a declared single budget. A nonzero terminal rejects that candidate; it must not be fed back as a new sample to select another candidate during the same fixed variant. A cap stop remains a partial attempt, not an identity.

The useful milestone is one explicit globally valid relation with a small, independently checkable certificate. It is not another sampled nullspace or a claim of rank compression inferred from 19 rows. Only after such a certificate exists should the signed/scaled contraction rewrite and its full original-source closure be considered for integration.

No such experiment is authorized or performed by this review. Checkpoint 175 control review remains the assigned priority when its files arrive.

## Local evidence used

`review.json` binds the completed cut probe's accepted replay and post-run audit, the generic assignment/cofactor definitions, and the existing lazy-node component inspected for reusable patterns. The latter supports constants, branches, sums and products; it is not already a checked interpretation of the historical guarded descriptor format. This note proposes that missing bridge explicitly and does not claim it was previously proved.
