# Hoisted expansion in the complete n6 source-count proof

24 October 2026. This candidate is prepared, not yet accepted. It applies a
new proved-checker proposal to the complete source-count route already retained
for n6. It performs no new external counting computation, changes no board
size, and does not resume the paused projected-context experiment.

## Exact accepted input

The canonical historical input is
`../../project/experiments/chapter15-queens-model-counting/packed-add-size-six-complete/packed-consolidated/`.
Its three source bundles contain 58 original source bodies. Their accepted
Lean-4.33.0-rc1 gate checked all three together in 27.329427591 seconds;
that is historical evidence, not acceptance under the current toolchain.

| Original bundle | SHA256 |
| --- | --- |
| `ConsolidatedGeneric.lean` | `ce7c3006fdfb13c2ca81e0a5f047895d74ce93844019143f3db040e327faa605` |
| `ConsolidatedArithmetic.lean` | `28ae100810acdda04cb096141f9bfa789e1e820e8affa061c9e94942b3b083f1` |
| `ConsolidatedSource.lean` | `36ac16affeffcd1b5a10e6ad793925ccb56e03b033e0356ba1dbfe6cdfcc6a4e` |

The historical gate report SHA256 is
`116f4005f8dfd6ee8d51794b27fdfb7f8c9cf33b48fc16e6fcb221c70c745e55`.
The generator verifies all four pins before producing candidate copies. It
does not overwrite any original bundle or historical report.

## Operation and proof contract

The original `checkExpansion` validates the global node bound at every
constant/branch and the two strict child bounds at every branch. These facts
already follow from the genuine table's `NodesValid` theorem. The retained
738-entry prefix cache agrees with that table at every bounded ID.

`source/HoistedExpansion.lean` adds:

- `nodesValid_prefix`: transport global descriptor validity to an exact
  smaller prefix. The branch proof checks that both child IDs remain inside
  that prefix before rewriting their descriptors.
- `checkExpansionBody_eq`: under table validity and a bounded root, expansion
  with recursive node/child guards omitted equals the original check.
- `checkExpansionHoisted_eq`: put one root-bound check around that body and
  obtain equality for **every natural root ID**, including rejected roots.

The inner body retains rank equality, the branch variable bound, the constant
value comparison, and both recursive child checks. In particular, the
`v < variableLimit` test is essential: without it, a constant descriptor could
be misinterpreted as a branch. The original source checker and its soundness
theorems remain present and unchanged.

## Concrete source use

The candidate adds `SitesPacked.fastNodes_valid` using the actual
`RealSix.nodes_valid`, `fastNodes_eq`, and the prefix bound. Each of the
36 original `expansionN_fast_checked` propositions is unchanged. Its proof
rewrites the original checker through the total equality theorem, then checks
the new Boolean by ordinary kernel reduction. Every other concrete arithmetic,
factor-plan, site-tensor, wire-coverage, and source correspondence proof is
retained apart from the explicit compatibility replacements below.

The final theorem and statement remain:

```lean
ADWH.Experiments.Chapter15.BulkADD.RealSix.OptimizedSource.source_cqueens_six
-- BitRepresentation.cqueens 6 = 4
```

All 9,454 node descriptors, 11,956 claims, packed payloads and routing masks,
36 literal local trees, original source IDs, constant arithmetic, factors,
clauses and coverage data remain fixed. No check result supplied by the
generator is used as a theorem premise.

The syntax-only count is 1,394 branches and 1,430 constants across 36 trees.
Retaining 36 root guards instead of one guard per tree node removes 2,788
recursive node-bound occurrences; dropping the two child-order guards removes
another 2,788 occurrences. These counts are not measured execution costs.
The existing prefix cache is retained, so this is an additional invariant
refinement, not a reimplementation of that cache.

## Lean 4.35 preparation

The known migration maps give 15 deprecated proof-alias replacements in the
generic bundle (`if_neg` nine and `if_pos` six), none in the arithmetic bundle,
and eight in the source bundle (`List.getElem_inj` two, `dif_pos` one, `if_neg`
two, `if_pos` three). They use the same pinned-release replacements as the
integrated migration. The two `List.getElem_inj` uses supply only the Nodup
argument and use `.mp`; the new `List.Nodup.getElem_inj` API retains that use.

`generate_expansion.py` excludes nested comments and string literals, records
exact character positions and old/new tokens, and verifies an inverse to the
original bytes. These known alias replacements do not assert full 4.35
compatibility. Any actual remaining failure must receive a specific,
reviewed proof-only repair; warnings and resource limits remain enforced.

The concrete transformation adds one import, one prefix-validity theorem and
its axiom print, and exactly 36 proof-body rewrite steps. Its inverse recovers
the canonical arithmetic bundle exactly. All existing definition lines remain
unchanged, and the complete source bridge reverses exactly after alias edits.
`generation.json` records source bindings, all changes and the static counts.

## Fresh gate and import boundary

The candidate has four experimental compilation units in dependency order:
`ConsolidatedGeneric`, `HoistedExpansion`, `ConsolidatedArithmetic`, and
`ConsolidatedSource`. This is all 58 retained bodies plus the new helper.
All four must be compiled fresh under one cumulative 30-second gate, one CPU,
one Lean thread, `-j1 -M1024`, the separate 1-GiB RSS policy, and unchanged
default recursion/heartbeat settings. No compiled experimental helper or
bundle may be reused in that full gate.

The generic development closure contains the first two modules only and
requires 227 axiom reports. It is not acceptance of the count. The complete
gate requires **338 actual accepted reports**: all original 334, the three
new generic lemmas and the new concrete prefix-validity theorem. The final
source count must be printed by the designated source module.

The source module's ADWH dependencies remain the exact historical ten-module
closure. Its current source hashes match the accepted integrated 4.35 gate;
preparation of compatible objects is a separate, disclosed step. The
`import-preparation/` directory records that work. The prepared import path
must expose only that exact accepted closure and toolchain modules. It must
not expose old experimental bundles or substitute a prior numerical answer.

`generate_expansion.py --verify` is source-only: it runs no Lean process or
checker function. Generic and full acceptance, source preservation review,
axiom audit and input/control binding checks are separate obligations.

## Interpretation

The proposal reaches a complete bounded count with its original source
connection. Successful checking would establish this representation under
Lean 4.35; comparison with a historical 4.33 timing would not establish a
causal speedup. The extra proof/module overhead may exceed the saved guard
work. Reject a failed full candidate under the fixed gate rather than raising
limits or retrying unchanged. Even a successful n6 result does not establish
scaling to n16 or close `cqueens 16 = 14772512`.
