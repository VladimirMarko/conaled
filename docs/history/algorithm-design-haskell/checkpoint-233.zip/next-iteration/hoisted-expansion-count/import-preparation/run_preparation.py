#!/usr/bin/env python3
"""Fixed bounded rebuild of accepted original ADWH imports; --run executes Lean."""
from __future__ import annotations
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import shutil
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
HELPER = ROOT / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
LOCK = ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
MANIFEST = HERE / 'dependency-manifest.json'
MARKER = HERE / 'EXECUTION-STARTED.json'


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--toolchain', type=Path, required=True)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    toolchain = args.toolchain.resolve()
    h = load(HELPER, 'adwh_preparation_resource_helper')
    generator = load(HERE / 'prepare_manifest.py', 'adwh_import_manifest_generator')
    manifest = generator.generate()
    h.require(MANIFEST.read_text() == json.dumps(manifest, indent=2, sort_keys=True) + '\n',
              'dependency manifest did not reproduce')
    h.require(h.sha(HELPER) == manifest['resource_helper']['sha256'], 'resource helper changed')
    sources = [{**h.binding(ROOT / row['source']['path']), 'module': row['module'],
                'imports': row['imports'], 'original_resource_options': row['unchanged_original_resource_options']}
               for row in manifest['modules']]
    control_paths = [HERE / 'run_preparation.py', HERE / 'prepare_manifest.py', HERE / 'PROTOCOL.md', MANIFEST,
                     HELPER, ROOT / manifest['source_guard']['path'], ROOT / manifest['current_gate']['path'],
                     ROOT / manifest['historical_bundle_manifest']['path'], ROOT / manifest['historical_n6_gate']['path'],
                     ROOT / manifest['historical_source_bundle']['path'], ROOT / manifest['runtime_pin_source']['path']]
    control_paths += [ROOT / row['path'] for row in manifest['accepted_control_bindings']]
    controls = [h.binding(path) for path in dict.fromkeys(control_paths)]
    runtime = []
    for relative, expected in manifest['runtime_files'].items():
        binding = h.binding(toolchain / relative)
        h.require(binding['bytes'] == expected['bytes'] and binding['sha256'] == expected['sha256'],
                  'compiler/shared runtime pin differs: ' + relative)
        runtime.append(binding)
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed',
                          'original_modules': len(sources), 'runtime_bindings': len(runtime),
                          'manifest_sha256': h.sha(MANIFEST)}))
        return 0

    target = HERE / 'attempts/imports-01'
    with LOCK.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        h.require(Path('/proc/self/status').is_file(), 'RSS enforcement requires normal /proc visibility')
        h.require(not target.exists() and not MARKER.exists(), 'fixed preparation already started')
        frozen, build = target / 'source', target / 'build'
        frozen.mkdir(parents=True); build.mkdir()
        for row in sources:
            rel = Path(*row['module'].split('.')).with_suffix('.lean')
            snapshot = frozen / rel
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(Path(row['path']), snapshot)
            snapshot.chmod(0o444)
            row['snapshot'] = h.binding(snapshot)
            h.require(row['snapshot']['sha256'] == row['sha256'], 'snapshot differs')
            (build / rel).parent.mkdir(parents=True, exist_ok=True)
        with MARKER.open('x') as stream:
            stream.write(json.dumps({'attempt': 'imports-01', 'manifest': h.binding(MANIFEST),
                                    'runner': h.binding(HERE / 'run_preparation.py'),
                                    'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())},
                                   indent=2, sort_keys=True) + '\n')
        cpu = min(os.sched_getaffinity(0))
        os.sched_setaffinity(0, {cpu})
        h.TOOLCHAIN = toolchain
        env = h.clean_environment(build)
        for key in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'):
            env.pop(key, None)
        report = {'kind': 'accepted_original_import_preparation', 'status': 'prepared',
                  'new_experimental_mathematical_gate': False, 'new_count_proved': False,
                  'compiled_experimental_imports_reused': False, 'historical_ADWH_objects_reused': False,
                  'current_integrated_gate_run_id': manifest['current_gate']['run_id'],
                  'current_integrated_gate': h.binding(ROOT / manifest['current_gate']['path']),
                  'original_source_bindings': sources, 'controls': controls, 'runtime': runtime,
                  'marker': h.binding(MARKER), 'cpu_affinity': [cpu], 'limits': manifest['limits'],
                  'object_search_path': str(build), 'standard_library': 'Pinned Lean 4.35 release distribution',
                  'axiom_audit_rerun': False, 'axiom_audit_boundary': 'Accepted full integrated source audit; later experimental roots must audit actual transitive dependencies.',
                  'modules': [], 'artifacts': []}
        report_path = target / 'report.json'
        save = lambda: h.save(report_path, report)
        save()
        began = time.monotonic()
        deadline = began + manifest['limits']['cumulative_wall_seconds']
        try:
            report['status'] = 'compiling_original_imports'
            for source in sources:
                module = source['module']
                relative = Path(*module.split('.'))
                command = [str(toolchain / 'bin/lean'), '-j1', '-M1024', '-DautoImplicit=false', '-DwarningAsError=true',
                           '-o', str((build / relative).with_suffix('.olean')),
                           '-i', str((build / relative).with_suffix('.ilean')),
                           str(relative.with_suffix('.lean'))]
                row = h.child(command, frozen, env, target / (module + '.stdout.log'),
                              target / (module + '.stderr.log'), cpu, deadline)
                row.update(module=module, status='passed' if row['exit_code'] == 0 and row['within_limits'] else 'failed')
                report['modules'].append(row)
                save()
                h.require(row['status'] == 'passed', 'original import preparation failed: ' + module)
            report['cumulative_seconds'] = time.monotonic() - began
            h.require(report['cumulative_seconds'] <= manifest['limits']['cumulative_wall_seconds'], 'preparation deadline exceeded')
            h.verify_bindings(sources + controls + runtime + [report['marker']])
            h.verify_bindings([row['snapshot'] for row in sources])
            report['all_sources_snapshots_controls_runtime_unchanged'] = True
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            h.require(all((build / Path(*row['module'].split('.')).with_suffix('.olean')).is_file()
                          for row in sources), 'required object missing after successful compile')
            report.update(status='passed', all_10_original_imports_freshly_compiled=True,
                          peak_child_rss_kib=max(row['sampled_tree_and_wait4_peak_rss_kib'] for row in report['modules']))
            save()
        except BaseException as error:
            report.update(status='failed', cumulative_seconds=time.monotonic() - began,
                          all_10_original_imports_freshly_compiled=False,
                          peak_child_rss_kib=max((row['sampled_tree_and_wait4_peak_rss_kib'] for row in report['modules']), default=0),
                          exception={'type': type(error).__name__, 'message': str(error)})
            save()
            raise
    print(json.dumps({'status': report['status'], 'cumulative_seconds': report['cumulative_seconds'],
                      'peak_child_rss_kib': report['peak_child_rss_kib'], 'original_modules': len(report['modules']),
                      'report': str(report_path), 'report_sha256': h.sha(report_path),
                      'build': str(build)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
