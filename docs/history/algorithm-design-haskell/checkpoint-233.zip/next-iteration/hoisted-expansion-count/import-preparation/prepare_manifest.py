#!/usr/bin/env python3
"""Bind exact accepted ADWH imports for a later experimental source gate.

This reads sources and reports only; it never invokes Lean or another checker.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PROJECT = ROOT / 'project/adwh-lean'
OLD = ROOT / 'project/experiments/chapter15-queens-model-counting/packed-add-size-six-complete/packed-consolidated'
GATE = PROJECT / 'reports/verification.json'
GATE_SHA = 'f7f000482a7a655e092fb30b2969302cdf2b037f8c08b3b1f15a6d85e46e9c5f'
GATE_ID = '6e376337ca5b4b34a679cd9588e3bfc1'
GUARD = PROJECT / 'scripts/check.py'
HELPER = ROOT / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
ENTRY_MODULES = ['ADWH.Chapter15.Queens', 'ADWH.Chapter15.QueensBitCounting']


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def bind(path):
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def generate():
    assert sha(GATE) == GATE_SHA, 'integrated gate report changed'
    gate = json.loads(GATE.read_text())
    assert gate['run_id'] == GATE_ID and gate['status'] == 'passed'
    assert '4.35.0' in gate['lean_version'] and 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc' in gate['lean_version']
    accepted = {row['module']: row for row in gate['files']}
    controls = []
    for row in gate['verification_controls']:
        path = PROJECT / row['path']
        assert sha(path) == row['sha256'], 'accepted control changed: ' + row['path']
        controls.append(bind(path))
    guard = load(GUARD, 'adwh_existing_source_guard')
    old_manifest = json.loads((OLD / 'bundle-manifest.json').read_text())
    old_report = json.loads((OLD / 'kernel/packed-six-01/report.json').read_text())
    assert old_report['status'] == 'passed'
    historical = {row['module']: row for row in old_manifest['original_ADWH_imports']}
    historical_gate = {row['module']: row for row in old_report['reused_old_imports']}
    modules, visiting, order = {}, set(), []

    def visit(module):
        if module in modules: return
        assert module not in visiting, 'cyclic import'
        visiting.add(module)
        relative = Path(*module.split('.')).with_suffix('.lean')
        path = PROJECT / relative
        text = path.read_text()
        code = guard.check_lean_source(path, text)
        imports = [name for line in re.findall(r'^\s*(?:public\s+|private\s+)?import[ \t]+([^\n]+)$', code, re.M)
                   for name in line.split()]
        assert all(re.fullmatch(r'[A-Za-z][A-Za-z0-9_.]*', name) for name in imports)
        assert all(name.startswith(('ADWH.', 'Init.', 'Std.')) or name in {'Init', 'Std'} for name in imports)
        current = bind(path)
        assert current['sha256'] == accepted[module]['sha256'], 'source differs from accepted current gate'
        assert current['sha256'] == historical[module]['source_sha256'] == historical_gate[module]['source_sha256'], \
            'source differs from historical original import'
        assert imports == historical[module]['imports'] == historical_gate[module]['imports'], 'import graph changed'
        for dep in imports:
            if dep.startswith('ADWH.'): visit(dep)
        for option, value in [('autoImplicit', 'false'), ('warningAsError', 'true')]:
            values = re.findall(r'\bset_option\s+' + option + r'\s+(\S+)', code)
            assert values and set(values) == {value}, 'original strict source option changed'
        resource_options = [{'name': m[1], 'value': m[2]} for m in re.finditer(
            r'\bset_option\s+(maxRecDepth|maxHeartbeats|maxMemory)\s+(\S+)', code)]
        object_path = PROJECT / '.lake/build/lib/lean' / relative.with_suffix('.olean')
        modules[module] = {'module': module, 'source': current, 'imports': imports,
            'matches_accepted_current_gate': True, 'matches_historical_n6_source': True,
            'historical_source_sha256': historical[module]['source_sha256'],
            'unchanged_original_resource_options': resource_options,
            'canonical_compiled_object_available': object_path.is_file(),
            'canonical_compiled_object': str(object_path.relative_to(ROOT))}
        visiting.remove(module)
        order.append(module)

    for module in ENTRY_MODULES: visit(module)
    assert set(modules) == set(historical) == set(historical_gate) and len(modules) == 10
    runtime_source = ROOT / 'next-iteration/lean435-kernel-comparison/attempts/comparison-01/report.json'
    runtime_report = json.loads(runtime_source.read_text())
    runtime = {}
    for row in runtime_report['controls']:
        split = row['path'].split('/runtime-restore/lean-4.35.0-linux/')
        if len(split) == 2 and (split[1] == 'bin/lean' or split[1].startswith('lib/lean/')):
            runtime[split[1]] = {key: row[key] for key in ['bytes', 'sha256']}
    assert len(runtime) == 6
    return {'kind': 'accepted_original_ADWH_import_preparation', 'status': 'source_bound_not_compiled',
        'entry_modules': ENTRY_MODULES, 'module_order': order, 'modules': [modules[m] for m in order],
        'current_gate': {**bind(GATE), 'run_id': GATE_ID, 'lean_version': gate['lean_version']},
        'accepted_control_bindings': controls,
        'historical_bundle_manifest': bind(OLD / 'bundle-manifest.json'),
        'historical_n6_gate': {**bind(OLD / 'kernel/packed-six-01/report.json'), 'lean_version': old_report['lean_version']},
        'historical_source_bundle': bind(OLD / 'ConsolidatedSource.lean'),
        'runtime_pin_source': bind(runtime_source), 'runtime_files': runtime,
        'resource_helper': bind(HELPER), 'source_guard': bind(GUARD),
        'allowed_axioms_in_referenced_integrated_gate': gate['allowed_axioms'],
        'all_10_sources_and_5_controls_match_current_gate': True,
        'all_10_sources_and_import_lists_match_historical_n6_gate': True,
        'compiler_executed': False, 'full_project_gate_rerun': False,
        'limits': {'cumulative_wall_seconds': 30, 'compiler_threads': 1, 'compiler_memory_mib': 1024,
                   'resident_memory_kib': 1048576, 'cpu_affinity_count': 1, 'automatic_retries': 0},
        'original_source_option_qualification': 'Two unchanged accepted original modules retain maxRecDepth 1000000 and maxHeartbeats 0; fixed wall/RSS limits still apply. No source option is raised.',
        'experimental_freshness_boundary': 'Only these original ADWH imports may be prepared and reused; every new experimental bundle and helper must later compile fresh in one separate cumulative gate.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    result = generate()
    text = json.dumps(result, indent=2, sort_keys=True) + '\n'
    target = HERE / 'dependency-manifest.json'
    if args.check: assert target.read_text() == text, 'dependency manifest differs'
    else: target.write_text(text)
    print(json.dumps({'status': 'verified' if args.check else 'prepared', 'modules': len(result['modules']),
                      'all_original_sources_unchanged': True, 'compiler_executed': False,
                      'canonical_compiled_objects_available': sum(row['canonical_compiled_object_available'] for row in result['modules']),
                      'manifest_sha256': sha(target)}))


if __name__ == '__main__':
    main()
