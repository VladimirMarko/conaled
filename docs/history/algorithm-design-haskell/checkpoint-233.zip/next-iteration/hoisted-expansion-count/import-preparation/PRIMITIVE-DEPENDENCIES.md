# The costly primitive proof is an actual dependency

The retained **checked-environment** audit of the accepted historical
`source_cqueens_six` theorem confirms the source-level dependency diagnosis.
This is stronger evidence than the mere presence of an import statement.

`FinalDependencyAudit.log` has SHA256
`d496468807b86660e7f26ee59f441717f1d05c6dc319c11b0be32a5ff4d23c81`,
which matches the accepted dependency-audit report. Its record for
`ADWH.Experiments.Chapter15.BulkADD.RealSix.OptimizedSource.source_cqueens_six`
visited 5,284 declarations and lists 1,956 project dependencies and 387
required dependency paths.

The actual project-dependency list contains all **64** named
`primitive_chunk_N` roots for `N = 0, ..., 63`, plus **64** generated chunk
auxiliaries. It also contains `primitive_certificate`, `low_decreases`,
`bits_eq_bits2`, `bits_eq_candidates`, and `cqueens_eq_queens_count`.
It contains neither `queens3_eight_count` nor `queens3_nine_count`.

The relevant original ADWH source files are byte-identical between that
historical Lean 4.33 source environment and the accepted current Lean 4.35
sources, as independently checked in `dependency-manifest.json`. This does
not amount to a fresh current-toolchain dependency audit; it is the exact
retained historical evidence, extracted without running Lean.

The result supports removing unrelated example imports only as a separately
reviewed source organization change. It does **not** support removing the
primitive chunk proofs from the current literal `cqueens` dependency chain.
A successful symbolic replacement would be a substantive proof improvement;
deleting the dependencies or bypassing their proof would change the claim.

`PRIMITIVE-DEPENDENCIES.json` binds the source reports and records all 64 chunk
names, the key dependencies, the absent examples and this precise scope.
