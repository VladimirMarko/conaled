# Exact original-import boundary for the n6 source bridge

24 October 2026. This review is source-only. No compiler was run while
preparing the dependency manifest and runner.

## Finding

The current original ADWH import closure is **exactly the same ten modules**
as the historical complete n6 bundle. Every one of the ten current source
files is byte-identical both to the accepted integrated Lean 4.35 source and
to the historical n6 import recorded under Lean 4.33.0-rc1. Their explicit
import lists are also unchanged. No ADWH compatibility edit is needed for
this boundary.

The current accepted integrated gate is
`6e376337ca5b4b34a679cd9588e3bfc1`; its immutable report hash is
`f7f000482a7a655e092fb30b2969302cdf2b037f8c08b3b1f15a6d85e46e9c5f`.
All ten selected source hashes and all five recorded source/control hashes
match that report. The historical comparison checks both
`packed-consolidated/bundle-manifest.json` and the accepted
`kernel/packed-six-01/report.json`, without editing either.

## Exact graph

| Module suffix under `ADWH` | Direct project imports |
| --- | --- |
| `Chapter01.Lists` | None; imports release `Std` |
| `Chapter01.Permutations` | `Chapter01.Lists` |
| `Chapter15.Queens` | `Chapter01.Permutations` |
| `Chapter15.QueensVariants` | `Chapter15.Queens` |
| `Chapter15.QueensSearch` | `Chapter15.QueensVariants` |
| `Chapter15.QueensBitsPrimitives` | `Chapter15.QueensSearch` |
| `Chapter15.QueensBitRepresentation` | `Chapter15.QueensSearch` |
| `Chapter15.QueensBitMoves` | `Chapter15.QueensBitRepresentation` |
| `Chapter15.QueensExamples` | `Chapter15.QueensSearch` |
| `Chapter15.QueensBitCounting` | `Chapter15.QueensBitsPrimitives`, `Chapter15.QueensBitMoves`, `Chapter15.QueensExamples` |

The two bit-representation/primitives files also explicitly import release
`Init.Data.BitVec.Bitblast`. The original experimental source bundle imports
`Queens` and `QueensBitCounting`, plus its own experimental bundles and the
release modules `Std.Sat.CNF.Basic`, `Init.Data.List.FinRange`, and
`Init.Data.List.OfFn`. No additional project import enters through that list.

## Available objects and preparation

None of the ten canonical project `.olean` paths exists. A workspace
`rg --files --hidden -g '*.olean'` inventory found no ADWH object paths
elsewhere under the restored work tree. Historical compiled-object hashes
describe past Lean 4.33 artifacts; they are not used as Lean 4.35 artifacts.

`run_preparation.py` therefore proposes an empty-build, exact-source rebuild
under a single 30-second cumulative limit, one CPU and Lean thread,
`-M1024`, and the unchanged 1 GiB resident watchdog. It exposes only its new
build directory and the pinned compiler's standard library. Preflight has
passed against six compiler/runtime bindings and the deterministic manifest.
Execution requires the explicit `--run` flag and a previously absent attempt
directory and marker. `PROTOCOL.md` gives all commands and failure behavior.

Two original files already use `maxRecDepth 1000000` and `maxHeartbeats 0`:
`QueensBitsPrimitives` and `QueensExamples`. Those options are part of both
historically accepted and currently accepted identical source bytes. They
are disclosed and unchanged. The new fixed external wall and RSS limits
apply regardless; no option is raised or introduced into a new source file.

## Mathematical scope

This preparation may recover the exact original imported environment used
by the proposed source bridge. It does not check the new hoisted expansion
helper, the migrated experimental bundles, or a new count theorem. All new
experimental modules must still compile freshly in one complete cumulative
gate, using these imports only as disclosed previously accepted originals.

The original whole-project gate includes the three-axiom audit; preparation
does not claim to rerun that full audit. The later experimental gate must
inspect the actual transitive axioms of its required theorem roots. The
historical n6 source result remains valid historical evidence but is not
automatically a passing current experimental gate merely because these ten
imports are unchanged.

`dependency-manifest.json` records all exact file hashes, current/historical
gate identities, source/control equality checks, imports, source options,
runtime pins and preparation limits. `prepare_manifest.py --check` reproduces
the manifest without executing Lean.
