# Original-import preparation failed within the fixed limits

24 October 2026. The single `imports-01` attempt did not produce the complete
ten-module import environment. The first five original modules compiled;
`QueensBitsPrimitives` was killed with exit **-9**. The recorded cumulative
time is **30.042108718 seconds**, peak child RSS **1,168,564 KiB**, and the
failed child's limit label is **`resident_memory`**. Both the recorded memory
peak and cumulative time exceed their fixed allowances. No retry or increase
was made, and the failed report and execution marker remain unchanged.

The report SHA256 is
`eef68bd929984099ca1956326c0341a7577930e7745f6d8bef7cf279cdf1901e`.

| Module | Seconds | Exit | Result |
| --- | ---: | ---: | --- |
| `Chapter01.Lists` | 1.522773 | 0 | Passed |
| `Chapter01.Permutations` | 1.135318 | 0 | Passed |
| `Chapter15.Queens` | 1.098955 | 0 | Passed |
| `Chapter15.QueensVariants` | 1.303157 | 0 | Passed |
| `Chapter15.QueensSearch` | 0.656494 | 0 | Passed |
| `Chapter15.QueensBitsPrimitives` | 24.316156 | -9 | Resource failure |
| `Chapter15.QueensBitRepresentation` | — | — | Not attempted |
| `Chapter15.QueensBitMoves` | — | — | Not attempted |
| `Chapter15.QueensExamples` | — | — | Not attempted |
| `Chapter15.QueensBitCounting` | — | — | Not attempted |

The failed module's stdout and stderr are empty. The result identifies no
particular theorem at which checking stopped, and establishes no logical
rejection. The resource helper can replace its limit label after the final
`wait4` high-water check; the record does not establish which resource bound
first triggered. The table reports interrupted process time, not the time
required to finish that module.

## Source dependency explains why the module matters

The unchanged `QueensBitsPrimitives.lean` contains 64 private theorems named
`primitive_chunk_0` through `primitive_chunk_63`. Each uses ordinary
`decide +kernel` to prove `PrimitiveCertificate` for 1,024 values. Together
they cover all 65,536 `Word16` values. The certificate combines strict descent
of `v - low v` with the equation for `bits2` after removing the least set bit.
This is an inspection of the source workload, not a measurement attributing
the observed failure to any particular chunk.

The exact logical chain is:

- The chunk proofs supply `primitive_certificate`.
- That theorem supplies `low_decreases` and `bits2_equation`.
- `low_decreases` is the termination argument for the literal recursive
  definition `Bits.bits`, and is also used by `bits_eq_bits2`.
- `QueensBitCounting.bits_eq_candidates` uses `bits_eq_bits2`; subsequent
  literal-successor/count bridges lead to `cqueens_eq_queens_count`.
- The historical complete source bundle's final `source_cqueens_six` theorem
  explicitly rewrites by `cqueens_eq_queens_count`.

Merely omitting unused example theorems therefore does not remove this actual
dependency while preserving the literal original `cqueens`. An algebraic
replacement for the primitive certificate would be a substantive new proof
proposal. No such replacement, source edit or imported declaration deletion
has been made here.

## Saved-result audit and downstream boundary

A source-only post-run audit verified all **54 distinct recorded file
bindings** (55 occurrences), including the ten source snapshots, controls,
compiler/runtime, marker and output logs. All matched. Five `.olean` and five
`.ilean` files exist from passing modules; their current hashes are recorded
as partial artifacts in `RESULTS.json`. They do not satisfy the complete
preparation contract and are not accepted as a substitute import pool.

The full four-module hoisted-expansion gate must fail preflight until its exact
complete original-import preparation requirement is satisfied. It must not
silently reuse these partial objects, ignore missing imports or relabel the
incomplete preparation. The independent generic refinement gate needs only
the pinned standard library and its two freshly rebuilt experimental sources,
so this failure does not prevent that separately scoped proof attempt.

Retain the concise failed report, marker, logs, protocol, sources' manifest,
runner and this analysis. Omit reproduced source snapshots and partial
compiled objects from durability archives. The original project sources and
historical accepted n6 result remain unchanged.
