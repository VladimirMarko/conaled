# Fixed preparation of previously accepted ADWH imports

Prepared 24 October 2026, before compilation in this continuation.

This step rebuilds only the ten original ADWH modules required by the unchanged
`ConsolidatedSource` import boundary. Every source and import list is byte-bound
both to the historical complete n6 source proof and to the accepted integrated
Lean 4.35 gate `6e376337ca5b4b34a679cd9588e3bfc1`. This is disclosed original
import preparation, not acceptance of a new experimental mathematical route.

## Fixed module order

1. `ADWH.Chapter01.Lists`
2. `ADWH.Chapter01.Permutations`
3. `ADWH.Chapter15.Queens`
4. `ADWH.Chapter15.QueensVariants`
5. `ADWH.Chapter15.QueensSearch`
6. `ADWH.Chapter15.QueensBitsPrimitives`
7. `ADWH.Chapter15.QueensBitRepresentation`
8. `ADWH.Chapter15.QueensBitMoves`
9. `ADWH.Chapter15.QueensExamples`
10. `ADWH.Chapter15.QueensBitCounting`

The transitive external imports named by these files are `Std` and
`Init.Data.BitVec.Bitblast`; their precompiled dependencies come from the pinned
release distribution. The original experimental source bundle additionally
imports `Std.Sat.CNF.Basic`, `Init.Data.List.FinRange`, and `Init.Data.List.OfFn`;
they also belong to that distribution. No other project import pool is exposed.

## Source and control checks

`prepare_manifest.py --check` reconstructs the exact local import graph using
the existing source guard, verifies all ten current source hashes against the
accepted integrated gate and both retained historical n6 import inventories,
checks the five original integrated controls, and compares deterministic JSON
bytes with `dependency-manifest.json`.

The accepted integrated report itself is bound by SHA256
`f7f000482a7a655e092fb30b2969302cdf2b037f8c08b3b1f15a6d85e46e9c5f`.
The compiler and five shared-runtime libraries use the already accepted Lean
4.35 release pins. No compiler is invoked by manifest generation or preflight.

No current canonical `.lake/build/lib/lean/ADWH/...` object is available for
these modules; a source-only workspace inventory found no other ADWH `.olean`
objects. The preparation therefore starts from an empty local build directory.

## One bounded execution

The fixed attempt is `attempts/imports-01`, with an exclusive execution marker.
The runner acquires the existing shared compiler lock without waiting, snapshots
the ten canonical sources, and builds them in the above dependency order. Each
invocation uses the pinned compiler with:

```text
lean -j1 -M1024 -DautoImplicit=false -DwarningAsError=true
     -o BUILD/ADWH/...olean -i BUILD/ADWH/...ilean ADWH/...lean
```

`LEAN_PATH` contains only the new import build directory, in addition to the
compiler's own standard-library search path. No compiled experimental helper,
old ADWH object or `.lake` import pool is used. Each child and the runner use
one CPU affinity. Lean is restricted to one thread.

The complete ten-module compilation and interleaved recording share one fixed
**30-second cumulative deadline**. The unchanged resource helper adds the
**1,048,576 KiB resident-memory** policy, sampled every 10 ms and checked against
`wait4` high water. Brief between-sample overshoot is possible. Core dumps are
disabled and each output file is capped at 128 MiB. The first failed module or
resource violation stops preparation. There is no retry or budget increase.

The unchanged original files `QueensBitsPrimitives` and `QueensExamples` retain
their already accepted `maxRecDepth 1000000` and `maxHeartbeats 0` source options.
They are not newly raised or copied into experimental sources. The fixed
external wall-time and resident-memory limits still apply to their compilation.

Source/control/runtime hashes are checked before execution and after the gate;
source snapshots and every produced object are bound in the result. These static
audits are separate from the compiler execution budget. Compiled artifacts stay
in scratch and are omitted from durability archives; exact sources and the
rebuild recipe remain recoverable.

## Acceptance boundary

A successful result establishes that these unchanged original sources were
rebuilt with the pinned current compiler within this preparation gate. Their
previous complete integrated axiom audit remains explicitly referenced; this
preparation does not rerun that audit or claim a new transitive axiom census.
The later experimental gate must audit its selected theorem roots including
their actual imported dependencies.

The hoisted-expansion experiment must subsequently compile **every selected new
generic helper and experimental bundle fresh together** under its own cumulative
30-second gate. This preparation is not permission to reuse any experimental
objects, split a new route across gates, count historical n6 objects as current,
or claim an accepted n6/n16 result before that complete gate passes.
