#!/usr/bin/env python3
"""Fresh bounded hoisted-expansion proof checks; --run is required for Lean."""
from __future__ import annotations
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = HERE / 'source'
CANONICAL = ROOT / 'project/experiments/chapter15-queens-model-counting/packed-add-size-six-complete/packed-consolidated'
HELPER = ROOT / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
GUARD = ROOT / 'project/adwh-lean/scripts/check.py'
LOCK = ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
PREPARATION = HERE / 'import-preparation'
PREP_REPORT = PREPARATION / 'attempts/imports-01/report.json'
PREP_BUILD = PREPARATION / 'attempts/imports-01/build'
FULL_MARKER = HERE / 'FULL-EXECUTION-STARTED.json'
FULL = ['ConsolidatedGeneric', 'HoistedExpansion', 'ConsolidatedArithmetic', 'ConsolidatedSource']
GENERIC = FULL[:2]
COUNTS = {'ConsolidatedGeneric': 224, 'HoistedExpansion': 3, 'ConsolidatedArithmetic': 87, 'ConsolidatedSource': 24}
BASELINE_PINS = {
    'ConsolidatedGeneric': 'ce7c3006fdfb13c2ca81e0a5f047895d74ce93844019143f3db040e327faa605',
    'ConsolidatedArithmetic': '28ae100810acdda04cb096141f9bfa789e1e820e8affa061c9e94942b3b083f1',
    'ConsolidatedSource': '36ac16affeffcd1b5a10e6ad793925ccb56e03b033e0356ba1dbfe6cdfcc6a4e',
}
HELPER_SHA = '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0'
GUARD_SHA = 'a5f7fa502f8c19609b73cf0e59a5fa9f98a5c0c533ae9e181d6dab8f733cf2ae'
HISTORICAL_REPORT_SHA = '116f4005f8dfd6ee8d51794b27fdfb7f8c9cf33b48fc16e6fcb221c70c745e55'
FINAL_ROOT = 'ADWH.Experiments.Chapter15.BulkADD.RealSix.OptimizedSource.source_cqueens_six'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def prepared_imports(h, current_runtime):
    """Require complete success; partial or historical objects are never a fallback."""
    h.require(PREP_REPORT.is_file(), 'Complete original-import preparation report is missing')
    report = json.loads(PREP_REPORT.read_text())
    h.require(report.get('status') == 'passed' and report.get('all_10_original_imports_freshly_compiled') is True,
              'Full gate blocked: exact ten-module original-import preparation did not pass')
    h.require(report.get('historical_ADWH_objects_reused') is False and
              report.get('compiled_experimental_imports_reused') is False,
              'Preparation reused disallowed objects')
    h.require(report.get('all_sources_snapshots_controls_runtime_unchanged') is True,
              'Preparation bindings were not verified')
    h.require(report.get('current_integrated_gate_run_id') == '6e376337ca5b4b34a679cd9588e3bfc1',
              'Preparation uses another integrated source gate')
    generator = load(PREPARATION / 'prepare_manifest.py', 'hoisted_original_import_manifest')
    manifest = generator.generate()
    h.require((PREPARATION / 'dependency-manifest.json').read_text() ==
              json.dumps(manifest, indent=2, sort_keys=True) + '\n', 'Original-import manifest changed')
    h.require([row['module'] for row in report['modules']] == manifest['module_order'] and
              len(report['modules']) == 10 and all(row['status'] == 'passed' and row['exit_code'] == 0
              and row['within_limits'] and row['limit_exceeded'] is None for row in report['modules']),
              'Preparation module coverage or outcome differs')
    h.require(report['limits'] == manifest['limits'] and report['cumulative_seconds'] <= 30 and
              report['peak_child_rss_kib'] <= 1048576, 'Preparation resource gate did not pass')
    h.require(Path(report['object_search_path']).resolve() == PREP_BUILD.resolve(),
              'Unexpected original import directory')
    expected_sources = {row['module']: row for row in manifest['modules']}
    h.require(len(report['original_source_bindings']) == 10, 'Original source inventory differs')
    for row in report['original_source_bindings']:
        expected = expected_sources[row['module']]
        h.require(Path(row['path']).resolve() == (ROOT / expected['source']['path']).resolve() and
                  row['sha256'] == expected['source']['sha256'] and
                  row['imports'] == expected['imports'] and
                  row['snapshot']['sha256'] == row['sha256'], 'Prepared original source identity differs')
    runtime_by_name = {Path(row['path']).name: (row['bytes'], row['sha256']) for row in current_runtime}
    h.require({Path(row['path']).name: (row['bytes'], row['sha256']) for row in report['runtime']}
              == runtime_by_name, 'Preparation compiler/runtime differs from this gate')

    # Recheck every actual recorded binding, including controls, frozen sources,
    # compiler/runtime, logs, marker and objects; do not trust success flags alone.
    bindings = {}
    def collect(value):
        if isinstance(value, dict):
            if {'path', 'bytes', 'sha256'} <= value.keys():
                path = Path(value['path'])
                h.require(path.is_file() and path.stat().st_size == value['bytes'] and h.sha(path) == value['sha256'],
                          'Preparation bound file differs: ' + str(path))
                bindings[str(path.resolve())] = {key: value[key] for key in ['path', 'bytes', 'sha256']}
            for child in value.values(): collect(child)
        elif isinstance(value, list):
            for child in value: collect(child)
    collect(report)
    object_bindings = {str(Path(row['path']).resolve()): row for row in report['artifacts']}
    actual_objects = {str(path.resolve()) for path in PREP_BUILD.rglob('*') if path.is_file()}
    h.require(set(object_bindings) == actual_objects, 'Prepared build membership changed')
    for module in manifest['module_order']:
        path = (PREP_BUILD / Path(*module.split('.'))).with_suffix('.olean').resolve()
        h.require(str(path) in object_bindings, 'Prepared original object missing: ' + module)
    bindings[str(PREP_REPORT.resolve())] = h.binding(PREP_REPORT)
    return {'report': h.binding(PREP_REPORT), 'build': str(PREP_BUILD.resolve()),
            'modules': manifest['module_order'], 'verified_binding_count': len(bindings),
            'verified_bindings': list(bindings.values()), 'objects': list(object_bindings.values()),
            'all_10_original_sources_and_objects_verified': True,
            'qualification': manifest['original_source_option_qualification']}


def preflight(args, h, guard):
    lean = args.lean.resolve()
    h.TOOLCHAIN = lean.parent.parent
    modules = FULL if args.stage == 'full' else GENERIC
    root_module = 'ConsolidatedSource' if args.stage == 'full' else 'HoistedExpansion'
    pin_path = ROOT / 'next-iteration/lean435-migration/toolchain.json'
    pins = json.loads(pin_path.read_text())
    h.require(lean.name == 'lean' and h.sha(lean) == pins['binaries']['lean']['sha256'], 'Compiler differs from pinned release')
    compiler = h.binding(lean)
    reference_path = ROOT / 'next-iteration/lean435-kernel-comparison/attempts/comparison-01/report.json'
    reference = json.loads(reference_path.read_text())
    runtime_pins = {Path(row['path']).name: (row['bytes'], row['sha256'])
                    for row in reference['controls'] if row['path'].endswith('.so')}
    runtime = [h.binding(path) for path in sorted((lean.parent.parent / 'lib/lean').glob('*.so'))]
    h.require({Path(row['path']).name: (row['bytes'], row['sha256']) for row in runtime} == runtime_pins,
              'Shared runtime differs from accepted release')
    old_report = CANONICAL / 'kernel/packed-six-01/report.json'
    h.require(h.sha(old_report) == HISTORICAL_REPORT_SHA, 'Historical complete n6 gate changed')
    for module, digest in BASELINE_PINS.items():
        h.require(h.sha(CANONICAL / (module + '.lean')) == digest, 'Historical bundle changed: ' + module)
    verified = subprocess.run([sys.executable, str(HERE / 'generate_expansion.py'), '--verify'],
                              cwd=HERE, capture_output=True, text=True, timeout=10, check=False)
    h.require(verified.returncode == 0, 'Source generation verification failed: ' + verified.stdout + verified.stderr)
    generation = json.loads((HERE / 'generation.json').read_text())
    h.require(generation['modules'] == FULL and generation['required_axiom_report_count'] == 338,
              'Fixed source/axiom inventory differs')
    h.require(generation['final_source_count_theorem'] == FINAL_ROOT, 'Final source theorem differs')
    by_path = {row['path']: row for row in generation['sources']}
    h.require(set(by_path) == {str((SOURCE / (m + '.lean')).relative_to(ROOT)) for m in FULL},
              'Generated source set differs')
    seen, sources, imports_by_module, required = set(), [], {}, {}
    allowed_ADWH = {'ADWH.Chapter15.Queens', 'ADWH.Chapter15.QueensBitCounting'} if args.stage == 'full' else set()
    for module in modules:
        path = SOURCE / (module + '.lean')
        expected = by_path[str(path.relative_to(ROOT))]
        h.require(path.stat().st_size == expected['bytes'] and h.sha(path) == expected['sha256'], 'Candidate source differs: ' + module)
        code = guard.check_lean_source(path, path.read_text())
        for option, value in [('autoImplicit', 'false'), ('warningAsError', 'true'), ('Elab.async', 'false')]:
            values = re.findall(r'\bset_option\s+' + re.escape(option) + r'\s+(\S+)', code)
            h.require(values and set(values) == {value}, 'Experimental strict option differs: ' + module)
        h.require(not re.search(r'\bset_option\s+(maxRecDepth|maxHeartbeats|maxMemory)\b', code),
                  'Experimental resource option override: ' + module)
        imports = [name for line in re.findall(r'^\s*import[ \t]+([^\n]+)$', code, re.M) for name in line.split()]
        h.require(all(name in seen or name in allowed_ADWH or name.split('.')[0] in {'Std', 'Init'} for name in imports),
                  'Unlisted or out-of-order project import: ' + module)
        h.require(not any(name in allowed_ADWH for name in imports) or module == 'ConsolidatedSource',
                  'Original ADWH dependency added to another experimental module')
        identifiers = re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M)
        h.require(identifiers == generation['source_print_identifiers'][module], 'Raw axiom-print commands changed: ' + module)
        roots = generation['axiom_roots'][module]
        h.require(len(roots) == COUNTS[module] and len(roots) == len(identifiers) and len(set(roots)) == len(roots),
                  'Fixed expected axiom-root count differs: ' + module)
        required[module] = roots
        sources.append({**h.binding(path), 'module': module, 'imports': imports,
                        'source_print_identifiers': identifiers, 'required_axiom_roots': roots})
        imports_by_module[module] = imports
        seen.add(module)
    reached = set()
    def visit(module):
        if module in reached: return
        reached.add(module)
        for dep in imports_by_module[module]:
            if dep in imports_by_module: visit(dep)
    visit(root_module)
    h.require(reached == set(modules), 'Selected fresh experimental closure is not exact')
    required_count = sum(map(len, required.values()))
    h.require(required_count == (338 if args.stage == 'full' else 227), 'Selected print inventory differs')
    all_roots = [root for roots in required.values() for root in roots]
    h.require(len(set(all_roots)) == required_count, 'Repeated required root across modules')
    controls = [Path(__file__).resolve(), HERE / 'PROTOCOL.md', HELPER, GUARD, pin_path, reference_path,
                HERE / 'generate_expansion.py', HERE / 'generation.json', old_report,
                *[CANONICAL / (module + '.lean') for module in BASELINE_PINS]]
    prepared = prepared_imports(h, [compiler, *runtime]) if args.stage == 'full' else None
    return {'stage': args.stage, 'modules': modules, 'root_module': root_module, 'sources': sources,
            'required_prints': required, 'required_axiom_report_count': required_count,
            'compiler': compiler, 'runtime_libraries': runtime, 'compiler_commit': pins['commit'],
            'compiler_release': pins['version'], 'controls': [h.binding(path) for path in controls],
            'generation_verification': verified.stdout, 'original_import_preparation': prepared}


def update_counts(report):
    report['observed_axiom_report_count'] = sum(row['observed_report_occurrences'] for row in report['modules'])
    report['observed_unique_axiom_root_count'] = sum(len(row['axiom_audit']['reports']) for row in report['modules'])
    report['accepted_axiom_report_count'] = sum(row['observed_report_occurrences'] for row in report['modules']
                                               if row['status'] == 'passed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', type=Path, required=True)
    parser.add_argument('--stage', choices=['generic', 'full'], required=True)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]*', args.attempt): parser.error('Invalid attempt name')
    if sha(HELPER) != HELPER_SHA or sha(GUARD) != GUARD_SHA: raise ValueError('Pinned resource helper/source guard changed')
    h = load(HELPER, 'hoisted_expansion_unchanged_resource_helper')
    guard = load(GUARD, 'hoisted_expansion_unchanged_source_guard')
    plan = preflight(args, h, guard)
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed', 'stage': args.stage,
                          'modules': plan['modules'], 'required_axiom_report_count': plan['required_axiom_report_count'],
                          'original_imports_needed': args.stage == 'full'}))
        return 0
    target = HERE / 'attempts' / args.attempt
    with LOCK.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        h.require(Path('/proc/self/status').is_file(), 'RSS enforcement requires normal /proc visibility')
        h.require(not target.exists(), 'Attempt already exists; no overwrite/retry')
        if args.stage == 'full': h.require(not FULL_MARKER.exists(), 'Fixed full experiment already started')
        frozen, build = target / 'source', target / 'build'
        frozen.mkdir(parents=True); build.mkdir()
        for row in plan['sources']:
            path = Path(row['path'])
            snapshot = frozen / path.name
            shutil.copyfile(path, snapshot); snapshot.chmod(0o444)
            row['snapshot'] = h.binding(snapshot)
            h.require(row['snapshot']['sha256'] == row['sha256'], 'Fresh source snapshot differs')
        report = {'format': 'adwh-hoisted-expansion-count-fresh-gate-v1', 'status': 'prepared',
                  'stage': args.stage, 'attempt': args.attempt, 'root_module': plan['root_module'],
                  'scope': 'Hoisted expansion refinement' if args.stage == 'generic' else 'Complete existing n6 source proof plus hoisted expansion refinement',
                  'new_count_proved': False, 'n16_target_proved': False, 'kernel_modified': False,
                  'existing_n6_source_count_rechecked': False, 'compiled_experimental_imports_reused': False,
                  'constraints': {'cumulative_wall_seconds': 30, 'threads': 1, 'lean_memory_mib': 1024,
                                  'resident_memory_kib': 1048576, 'default_experimental_heartbeats_and_recursion': True},
                  'source_bindings': plan['sources'], 'controls': plan['controls'],
                  'compiler': plan['compiler'], 'compiler_commit': plan['compiler_commit'],
                  'compiler_release': plan['compiler_release'], 'runtime_libraries': plan['runtime_libraries'],
                  'generation_verification': plan['generation_verification'],
                  'required_prints': plan['required_prints'], 'required_axiom_report_count': plan['required_axiom_report_count'],
                  'original_import_preparation': plan['original_import_preparation'],
                  'modules': [], 'observed_axiom_report_count': 0, 'observed_unique_axiom_root_count': 0,
                  'accepted_axiom_report_count': 0, 'artifacts': []}
        cpu = min(os.sched_getaffinity(0)); os.sched_setaffinity(0, {cpu})
        report['constraints']['cpu_affinity'] = [cpu]
        env = h.clean_environment(build)
        search_paths = [str(build)]
        if args.stage == 'full': search_paths.append(plan['original_import_preparation']['build'])
        env['LEAN_PATH'] = os.pathsep.join(search_paths)
        for key in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'): env.pop(key, None)
        report['experimental_search_paths'] = search_paths
        if args.stage == 'full':
            with FULL_MARKER.open('x') as stream:
                stream.write(json.dumps({'attempt': args.attempt, 'protocol': h.binding(HERE / 'PROTOCOL.md'),
                                        'runner': h.binding(Path(__file__).resolve()), 'source_bindings': plan['sources'],
                                        'generation_manifest': h.binding(HERE / 'generation.json'),
                                        'original_import_report': plan['original_import_preparation']['report'],
                                        'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())},
                                       indent=2, sort_keys=True) + '\n')
            report['controls'].append(h.binding(FULL_MARKER))
        report_path = target / 'report.json'
        save = lambda: h.save(report_path, report)
        save()
        began = time.monotonic(); deadline = began + 30.0
        try:
            report['status'] = 'running'
            good = True
            for module in plan['modules']:
                if time.monotonic() >= deadline:
                    good = False
                    break
                command = [str(args.lean.resolve()), '-j1', '-M1024', '-o', str(build / (module + '.olean')),
                           '-i', str(build / (module + '.ilean')), module + '.lean']
                item = h.child(command, frozen, env, target / (module + '.stdout.log'),
                               target / (module + '.stderr.log'), cpu, deadline)
                output = Path(item['stdout']['path']).read_text() + '\n' + Path(item['stderr']['path']).read_text()
                audit = h.axiom_reports(output, plan['required_prints'][module])
                observed = len(re.findall(r"'([^']+)' (?:depends on axioms:|does not depend on any axioms)", output))
                item.update(module=module, axiom_audit=audit, observed_report_occurrences=observed,
                            status='passed' if item['exit_code'] == 0 and item['within_limits'] and audit['passed'] else 'failed')
                report['modules'].append(item); update_counts(report); save()
                if item['status'] != 'passed':
                    good = False
                    break
            report['seconds'] = time.monotonic() - began
            report['peak_child_rss_kib'] = max((row['sampled_tree_and_wait4_peak_rss_kib'] for row in report['modules']), default=0)
            bindings = report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']]
            if args.stage == 'full': bindings += plan['original_import_preparation']['verified_bindings']
            h.verify_bindings(bindings)
            h.verify_bindings([row['snapshot'] for row in report['source_bindings']])
            report['all_input_snapshot_control_runtime_and_import_bindings_unchanged'] = True
            update_counts(report)
            report['all_selected_experimental_sources_freshly_checked'] = (
                good and len(report['modules']) == len(plan['modules']) and report['seconds'] <= 30
                and report['accepted_axiom_report_count'] == report['required_axiom_report_count'])
            report['status'] = 'passed' if report['all_selected_experimental_sources_freshly_checked'] else 'failed'
            report['existing_n6_source_count_rechecked'] = bool(args.stage == 'full' and report['status'] == 'passed'
                and report['modules'][-1]['module'] == 'ConsolidatedSource'
                and FINAL_ROOT in report['modules'][-1]['axiom_audit']['reports'])
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            save()
        except BaseException as error:
            report.update(status='failed', seconds=time.monotonic() - began,
                          all_selected_experimental_sources_freshly_checked=False,
                          existing_n6_source_count_rechecked=False,
                          exception={'type': type(error).__name__, 'message': str(error)})
            update_counts(report); save()
            raise
    print(json.dumps({'status': report['status'], 'stage': args.stage, 'seconds': report.get('seconds'),
                      'peak_child_rss_kib': report.get('peak_child_rss_kib'),
                      'required_axiom_report_count': report['required_axiom_report_count'],
                      'observed_axiom_report_count': report['observed_axiom_report_count'],
                      'accepted_axiom_report_count': report['accepted_axiom_report_count'],
                      'existing_n6_source_count_rechecked': report['existing_n6_source_count_rechecked'],
                      'report': str(report_path), 'report_sha256': h.sha(report_path)}))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
