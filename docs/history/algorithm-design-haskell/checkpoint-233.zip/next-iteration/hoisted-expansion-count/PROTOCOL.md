# Fixed hoisted-expansion proof gate

Prepared 24 October 2026 before either experimental stage executes. Read
`PLAN.md` for the mathematical proposal and `generation.json` for exact
source transformation, theorem-root and data bindings.

## Scope and preservation

The proposal preserves the complete historical n6 source-count certificate,
migrates known deprecated proof aliases for Lean 4.35, and changes the 36
expansion-check proof bodies to use one proved descriptor invariant. The
new generic helper proves transport of `NodesValid` through a prefix-equal
lookup and equality between the original and hoisted expansion checks under
that invariant. Existing executable definitions, data, theorem statements and
the final original `cqueens 6 = 4` target remain fixed by the generator's
inverse transformations. No larger board, kernel modification, alternative
axiom, imported external observation or unproved execution result is added.

All three historical bundles and their accepted gate are checked by their
fixed SHA256 bindings. `generate_expansion.py --verify` is run before either
stage. It performs source-only reconstruction and exact manifest comparison;
it does not run Lean or a counting algorithm. Source alias compatibility is
not assumed to establish successful compilation before the fresh gate.

The manifest records raw `source_print_identifiers` separately from fully
qualified `axiom_roots`. Fourteen old generic `#print` commands use abbreviated
identifiers. Their expected full output names are bound positionally to the
immutable historical gate, with suffix/context preservation checks in the
generator. The runner checks the raw commands against source and matches
actual output against the full names. It does not accept names by suffix at
runtime or silently drop unmatched reports.

## Two precisely scoped stages

| Stage | Exact fresh module order | Required axiom reports |
| --- | --- | ---: |
| `generic` | `ConsolidatedGeneric`, `HoistedExpansion` | 224 + 3 = **227** |
| `full` | `ConsolidatedGeneric`, `HoistedExpansion`, `ConsolidatedArithmetic`, `ConsolidatedSource` | 224 + 3 + 87 + 24 = **338** |

The generic stage's root is `HoistedExpansion`. The full stage's root is
`ConsolidatedSource`, including the designated final theorem
`ADWH.Experiments.Chapter15.BulkADD.RealSix.OptimizedSource.source_cqueens_six`.
The runner requires each stage's selected experimental import closure to be
exact. A generic success does not establish the concrete full source result.
All generic sources must be rebuilt again in the full gate; their earlier
objects cannot be reused to satisfy freshness.

## Original ADWH imports: complete preparation required for full stage

The full stage also imports the exact original `ADWH.Chapter15.Queens` and
`ADWH.Chapter15.QueensBitCounting` closure. These ten previously accepted
original modules are separately specified in `import-preparation/`.

The full stage must verify a **successful complete** `imports-01` preparation
report. It checks all ten source identities, import lists, frozen snapshots,
compiler/runtime identities, recorded controls, raw logs and produced objects,
and checks the complete prepared build-directory membership. It additionally
rechecks the accepted integrated gate and historical original-import bindings.
The prepared compiler/runtime must match those used for the new proof gate.

The actual `imports-01` attempt has failed. Consequently the full stage is
currently **blocked at preflight**. The runner deliberately refuses partial
objects and has no fallback to historical objects, arbitrary search paths or
an incomplete import pool. No full execution marker is created and no new
experimental compiler process starts when this preflight fails. No unchanged
retry or increase of the failed preparation's limits is permitted.

The generic stage does not depend on original ADWH imports or a successful
preparation report, and remains separately available. A substantively new
source-bridge proposal would require explicit source/theorem review and a
new fixed protocol; this runner does not preauthorize such a change.

## Source policy and execution bounds

Every selected new experimental source must pass the existing source guard,
use `autoImplicit false`, `warningAsError true` and `Elab.async false`, and
contain no `maxRecDepth`, `maxHeartbeats` or `maxMemory` override. The only
permitted transitive axioms are `propext`, `Quot.sound`, and `Classical.choice`.
The originally accepted ADWH resource options are confined to the disclosed
preparation; no such option is introduced in these experimental modules.

Each stage starts with an empty experimental build directory and fresh
read-only source snapshots. Each module is invoked as:

```text
PINNED_LEAN -j1 -M1024 -o BUILD/Module.olean -i BUILD/Module.ilean Module.lean
```

The entire selected stage, including interleaved result recording and axiom-log
checks, shares **one cumulative 30-second wall deadline**. The runner and all
children use one CPU affinity; Lean uses one thread. The unchanged resource
helper applies the **1,048,576 KiB** process-tree RSS policy, 10 ms sampling,
and final `wait4` high-water rejection. Brief between-sample overshoot is
possible. Core dumps are disabled and each output file is capped at 128 MiB.
Source generation, static preflight and final binding audits are separate
from this compiler execution window.

The shared compiler/check lock excludes overlapping work. `LEAN_PATH` is only
the fresh experimental build directory for the generic stage. For the full
stage it additionally contains only the exact validated original-import build
directory. The pinned compiler's own standard library remains available.
No other compiled experimental module or project import pool is exposed.

The runner requires `--run` to execute Lean. Without it the command performs
preflight only. Every attempt directory is exclusive. The full stage also
requires a previously absent `FULL-EXECUTION-STARTED.json`, written before the
first compiler launch. It is immutable evidence of the fixed attempt, never
reset to obtain a better run. There is no unchanged full rerun, automatic
retry, source sharding, count amplification or resource-limit increase.

## Results and acceptance

Each module must finish with exit zero, remain within limits, and print
exactly its required axiom-root multiset with only the three permitted axioms.
Admissions/compiler-trust output is rejected. The first failed module stops
the stage. Raw stdout/stderr, commands, process outcomes, source snapshots,
controls, compiler/runtime and artifacts are bound in the report.

The report distinguishes **required** reports from **observed** log occurrences
and **accepted** reports belonging to fully passing modules. A failed module's
partial logs never become accepted roots. Its observed occurrences may still
be reported as diagnostic evidence. Resource failure is not a logical
refutation of a theorem, and an interrupted stage is never a complete proof.

Only a successful full gate with all 338 roots and the designated final source
theorem may set `existing_n6_source_count_rechecked = true`. It remains an n6
recheck with new refinement infrastructure, not a new numerical count or an
n16 result. The generic stage never sets that field. No performance improvement
is inferred from comparisons with historical 4.33 workloads or from partial
proof times. Preserve the accepted old certificate independently.
