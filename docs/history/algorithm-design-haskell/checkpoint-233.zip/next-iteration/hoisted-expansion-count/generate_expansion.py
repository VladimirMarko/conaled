#!/usr/bin/env python3
"""Prepare an exact n6 source-count refinement without executing Lean or a counter.

Preserve the three accepted historical bundles; migrate only known deprecated
proof aliases in copies. Add a separately proved expansion helper and consume
the existing descriptor invariant in all 36 site-expansion proofs. Exact
inverse transformations reconstruct every original bundle byte for byte.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CANONICAL = ROOT / ("project/experiments/chapter15-queens-model-counting/"
                    "packed-add-size-six-complete/packed-consolidated")
OUT = HERE / "source"
HELPER = OUT / "HoistedExpansion.lean"
MANIFEST = HERE / "generation.json"
MODULES = ["ConsolidatedGeneric", "HoistedExpansion", "ConsolidatedArithmetic", "ConsolidatedSource"]
ORIGINAL_MODULES = [m for m in MODULES if m != "HoistedExpansion"]
PINS = {
    "ConsolidatedGeneric": "ce7c3006fdfb13c2ca81e0a5f047895d74ce93844019143f3db040e327faa605",
    "ConsolidatedArithmetic": "28ae100810acdda04cb096141f9bfa789e1e820e8affa061c9e94942b3b083f1",
    "ConsolidatedSource": "36ac16affeffcd1b5a10e6ad793925ccb56e03b033e0356ba1dbfe6cdfcc6a4e",
}
ACCEPTED_REPORT = CANONICAL / "kernel/packed-six-01/report.json"
ACCEPTED_REPORT_SHA = "116f4005f8dfd6ee8d51794b27fdfb7f8c9cf33b48fc16e6fcb221c70c745e55"
ALIASES = {
    "if_pos": "ite_eq_left", "if_neg": "ite_eq_right",
    "dif_pos": "dite_eq_left", "dif_neg": "dite_eq_right",
    "if_false": "ite_false", "if_true": "ite_true",
    "Std.min_eq_if": "Std.min_eq_ite",
    "List.getElem_inj": "List.Nodup.getElem_inj",
    "List.getElem?_inj": "List.Nodup.getElem?_inj",
}
EXPECTED_ALIASES = {
    "ConsolidatedGeneric": {"if_neg": 9, "if_pos": 6},
    "ConsolidatedArithmetic": {},
    "ConsolidatedSource": {"List.getElem_inj": 2, "dif_pos": 1, "if_neg": 2, "if_pos": 3},
}
IDENTIFIER = re.compile(r"[\w][\w.'?]*")
PRINT = re.compile(r"^#print axioms ([\w.']+)\s*$", re.M)
PREFIX_ANCHOR = (
    "theorem fastNodes_eq (i : Nat) (hi : i < 738) : fastNodes i = nodes i :=\n"
    "  (checkNodePlanePrefix_sound cache_planes_checked i hi).trans (selfNodes_at i)\n"
)
PREFIX_ADDITION = (
    "\ntheorem fastNodes_valid : NodesValid 110 738 fastNodes :=\n"
    "  HoistedExpansion.nodesValid_prefix (by decide +kernel) fastNodes_eq nodes_valid\n"
)
PRINT_ANCHOR = "#print axioms ADWH.Experiments.Chapter15.BulkADD.RealSix.SitesPacked.fastNodes_eq\n"
PRINT_ADDITION = "#print axioms ADWH.Experiments.Chapter15.BulkADD.RealSix.SitesPacked.fastNodes_valid\n"
CONCRETE_ROOT = "ADWH.Experiments.Chapter15.BulkADD.RealSix.SitesPacked.fastNodes_valid"
EXPANSION = re.compile(
    r"theorem expansion(?P<site>\d+)_fast_checked : checkExpansion 110 738 fastNodes "
    r"(?P<root>\d+) tree(?P=site) = true := by\n  decide \+kernel\n")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def binding(path: Path, raw: bytes | None = None) -> dict:
    if raw is None:
        raw = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(raw), "sha256": digest(raw)}


def encode_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def mask_noncode(text: str) -> str:
    """Preserve character offsets while excluding nested comments and strings."""
    out = list(text)
    i, depth = 0, 0
    while i < len(text):
        if depth:
            if text.startswith("/-", i):
                out[i:i + 2] = "  "
                depth += 1
                i += 2
            elif text.startswith("-/", i):
                out[i:i + 2] = "  "
                depth -= 1
                i += 2
            else:
                if text[i] != "\n":
                    out[i] = " "
                i += 1
        elif text.startswith("/-", i):
            out[i:i + 2] = "  "
            depth = 1
            i += 2
        elif text.startswith("--", i):
            end = text.find("\n", i)
            if end < 0:
                end = len(text)
            out[i:end] = " " * (end - i)
            i = end
        elif text[i] == '"':
            end = i + 1
            while end < len(text):
                if text[end] == "\\":
                    end += 2
                elif text[end] == '"':
                    end += 1
                    break
                else:
                    end += 1
            require(end <= len(text) and text[end - 1] == '"', "unterminated string")
            out[i:end] = ["\n" if c == "\n" else " " for c in text[i:end]]
            i = end
        else:
            i += 1
    require(depth == 0, "unterminated block comment")
    return "".join(out)


def undo_aliases(text: str, edits: list[dict]) -> str:
    restored = text
    for edit in reversed(edits):
        start, end = edit["new_character_start"], edit["new_character_end"]
        require(restored[start:end] == edit["new"], "alias inverse mismatch")
        restored = restored[:start] + edit["old"] + restored[end:]
    return restored


def migrate(text: str, module: str) -> tuple[str, list[dict]]:
    masked = mask_noncode(text)
    fragments, edits, cursor, delta = [], [], 0, 0
    counts: Counter[str] = Counter()
    for match in IDENTIFIER.finditer(masked):
        token = match.group()
        replacement, alias = None, None
        for old, new in ALIASES.items():
            if token == old or token.startswith(old + "."):
                replacement, alias = new + token[len(old):], old
                break
        if replacement is None:
            continue
        require(text[match.start():match.end()] == token, "masked token differs from source")
        fragments.extend((text[cursor:match.start()], replacement))
        edits.append({"old": token, "new": replacement,
                      "original_character_start": match.start(),
                      "original_character_end": match.end(),
                      "new_character_start": match.start() + delta,
                      "new_character_end": match.start() + delta + len(replacement),
                      "line": text.count("\n", 0, match.start()) + 1})
        cursor = match.end()
        delta += len(replacement) - len(token)
        counts[alias] += 1
    fragments.append(text[cursor:])
    migrated = "".join(fragments)
    require(dict(counts) == EXPECTED_ALIASES[module], f"unexpected proof alias count in {module}")
    require(undo_aliases(migrated, edits) == text, "proof alias inverse is not exact")
    return migrated, edits


def transform_arithmetic(text: str) -> tuple[str, list[dict]]:
    require(text.count("import ConsolidatedGeneric\n") == 1, "import boundary changed")
    require(text.count(PREFIX_ANCHOR) == 1 and text.count(PRINT_ANCHOR) == 1,
            "prefix proof boundary changed")
    require("HoistedExpansion" not in text and "fastNodes_valid" not in text,
            "canonical source already contains new declarations")
    matches = list(EXPANSION.finditer(text))
    require([int(m["site"]) for m in matches] == list(range(36)),
            "all 36 exact expansion proofs must be present")
    edits = []
    changed = text.replace("import ConsolidatedGeneric\n",
                           "import ConsolidatedGeneric\nimport HoistedExpansion\n")
    changed = changed.replace(PREFIX_ANCHOR, PREFIX_ANCHOR + PREFIX_ADDITION)
    changed = changed.replace(PRINT_ANCHOR, PRINT_ANCHOR + PRINT_ADDITION)
    for match in matches:
        old = match.group()
        new = old.replace("  decide +kernel\n",
            f"  rw [← HoistedExpansion.checkExpansionHoisted_eq fastNodes_valid tree{match['site']} {match['root']}]\n"
            "  decide +kernel\n")
        require(changed.count(old) == 1, "expansion proof boundary duplicated")
        changed = changed.replace(old, new)
        edits.append({"site": int(match["site"]), "root": int(match["root"]),
                      "old": old, "new": new})
    restored = changed
    for edit in reversed(edits):
        require(restored.count(edit["new"]) == 1, "concrete proof inverse mismatch")
        restored = restored.replace(edit["new"], edit["old"])
    restored = restored.replace(PRINT_ANCHOR + PRINT_ADDITION, PRINT_ANCHOR)
    restored = restored.replace(PREFIX_ANCHOR + PREFIX_ADDITION, PREFIX_ANCHOR)
    restored = restored.replace("import ConsolidatedGeneric\nimport HoistedExpansion\n",
                                "import ConsolidatedGeneric\n")
    require(restored == text, "concrete transformation inverse is not exact")
    return changed, edits


def build() -> tuple[dict[str, bytes], dict]:
    require(digest(ACCEPTED_REPORT.read_bytes()) == ACCEPTED_REPORT_SHA,
            "historical accepted report changed")
    accepted_report = json.loads(ACCEPTED_REPORT.read_text())
    originals = {module: (CANONICAL / f"{module}.lean").read_bytes() for module in ORIGINAL_MODULES}
    outputs, alias_edits = {}, {}
    for module, raw in originals.items():
        require(digest(raw) == PINS[module], f"historical source changed: {module}")
        migrated, alias_edits[module] = migrate(raw.decode(), module)
        outputs[module] = migrated.encode()
    arithmetic, concrete_edits = transform_arithmetic(outputs["ConsolidatedArithmetic"].decode())
    outputs["ConsolidatedArithmetic"] = arithmetic.encode()
    outputs["HoistedExpansion"] = HELPER.read_bytes()
    old_roots = {m: PRINT.findall(originals[m].decode()) for m in ORIGINAL_MODULES}
    raw_roots = {m: PRINT.findall(outputs[m].decode()) for m in MODULES}
    # Some unchanged historical print commands use names relative to their
    # surrounding namespace. Bind the actual fully qualified output names to
    # the immutable accepted report, preserving the original positional order.
    roots = {"HoistedExpansion": raw_roots["HoistedExpansion"]}
    for module in ORIGINAL_MODULES:
        expected = accepted_report["required_theorem_prints"][module]
        require(len(old_roots[module]) == len(expected), "historical print count differs")
        for raw_name, full_name in zip(old_roots[module], expected):
            require(full_name == raw_name or full_name.endswith("." + raw_name),
                    f"historical namespace resolution does not match source: {raw_name}")
        position = 0
        resolved = []
        for raw_name in raw_roots[module]:
            if raw_name == CONCRETE_ROOT:
                require(module == "ConsolidatedArithmetic", "new concrete print in wrong bundle")
                resolved.append(CONCRETE_ROOT)
            else:
                require(position < len(old_roots[module]) and
                        raw_name == old_roots[module][position], "original print order/context changed")
                resolved.append(expected[position])
                position += 1
        require(position == len(old_roots[module]), "original prints not completely covered")
        roots[module] = resolved
    require(sum(map(len, old_roots.values())) == 334, "historical print inventory changed")
    all_roots = [root for m in MODULES for root in roots[m]]
    require(len(all_roots) == len(set(all_roots)) == 338, "candidate print inventory changed")
    require(all(root.startswith("ADWH.Experiments.Chapter15.") for root in all_roots),
            "an expected output root is not fully qualified")
    for module in ORIGINAL_MODULES:
        require(set(old_roots[module]).issubset(raw_roots[module]), "an original print was removed")
    # Exact source statement/source body preservation after undoing the known aliases.
    require(undo_aliases(outputs["ConsolidatedSource"].decode(), alias_edits["ConsolidatedSource"])
            .encode() == originals["ConsolidatedSource"], "source correspondence changed")
    original_data_defs = re.findall(r"^def .*$", originals["ConsolidatedArithmetic"].decode(), re.M)
    candidate_data_defs = re.findall(r"^def .*$", arithmetic, re.M)
    require(original_data_defs == candidate_data_defs, "a concrete data definition line changed")
    trees = re.findall(r"^def tree(\d+) : NodeTree := (.*)$", arithmetic, re.M)
    require([int(i) for i, _ in trees] == list(range(36)), "tree syntax inventory changed")
    branches = sum(text.count(".branch ") for _, text in trees)
    constants = sum(text.count(".constant ") for _, text in trees)
    require((branches, constants) == (1394, 1430), "tree occurrence inventory changed")
    manifest = {
        "format": "hoisted-expansion-complete-n6-source-v1",
        "semantic_evaluation": False, "lean_executed": False,
        "status": "prepared_requires_fresh_complete_gate",
        "scope": "Complete existing n6 source proof plus expansion refinement; no new count or larger board.",
        "generator": binding(Path(__file__).resolve()),
        "historical_accepted_gate": binding(ACCEPTED_REPORT),
        "historical_toolchain": "Lean 4.33.0-rc1",
        "candidate_toolchain": "Lean 4.35.0",
        "original_sources": [binding(CANONICAL / f"{m}.lean", originals[m]) for m in ORIGINAL_MODULES],
        "sources": [binding(OUT / f"{m}.lean", outputs[m]) for m in MODULES],
        "modules": MODULES,
        "original_print_occurrences": 334,
        "required_axiom_report_count": 338,
        "axiom_roots": roots,
        "source_print_identifiers": raw_roots,
        "original_axiom_root_resolution": "Exact ordered mapping from the immutable historical gate; every source name equals or is a dot-suffix of its recorded full name.",
        "proof_alias_edits": alias_edits,
        "proof_alias_counts": EXPECTED_ALIASES,
        "proof_alias_scan_excludes_comments_and_strings": True,
        "complete_435_compatibility_not_yet_established": True,
        "concrete_proof_edits": concrete_edits,
        "added_concrete_theorem": CONCRETE_ROOT,
        "inverse_recovers_all_historical_bundles": True,
        "all_existing_executable_definitions_and_data_preserved": True,
        "all_existing_theorem_statements_preserved": True,
        "final_source_count_theorem": "ADWH.Experiments.Chapter15.BulkADD.RealSix.OptimizedSource.source_cqueens_six",
        "final_source_count_statement": "BitRepresentation.cqueens 6 = 4",
        "source_bridge_unchanged_except_known_proof_aliases": True,
        "source_bridge_ADWH_import_preparation": "Separate disclosed preparation from exact current accepted integrated sources; no experimental objects reused.",
        "static_occurrence_count": {"kind": "Literal source syntax; no runtime/speed claim",
            "trees": 36, "branches": branches, "constants": constants,
            "retained_root_bounds": 36,
            "removed_recursive_node_bounds": branches + constants - 36,
            "removed_child_order_checks": 2 * branches},
    }
    return outputs, manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    outputs, manifest = build()
    serialized = encode_json(manifest)
    if args.verify:
        for module in MODULES:
            require((OUT / f"{module}.lean").read_bytes() == outputs[module],
                    f"generated source differs: {module}")
        require(MANIFEST.read_bytes() == serialized, "generation manifest differs")
    else:
        OUT.mkdir(parents=True, exist_ok=True)
        for module in ORIGINAL_MODULES:
            (OUT / f"{module}.lean").write_bytes(outputs[module])
        MANIFEST.write_bytes(serialized)
    print(json.dumps({"status": "verified" if args.verify else "generated", "modules": len(MODULES),
                      "required_axiom_reports": manifest["required_axiom_report_count"],
                      "changed_expansion_proofs": len(manifest["concrete_proof_edits"]),
                      "known_proof_alias_counts": EXPECTED_ALIASES,
                      "inverse_recovers_all_historical_bundles": True,
                      "lean_executed": False, "semantic_evaluation": False}, sort_keys=True))


if __name__ == "__main__":
    main()
