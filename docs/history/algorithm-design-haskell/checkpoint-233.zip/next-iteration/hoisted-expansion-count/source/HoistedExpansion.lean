import ConsolidatedGeneric

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
The complete descriptor-table proof already supplies the recursive bounds
needed by expansion. Keep a root guard and every rank/value comparison, then
consume that invariant in the refinement theorem instead of rechecking the
node and child-order bounds at every occurrence of a local expansion tree.
-/
namespace ADWH.Experiments.Chapter15.BulkADD.HoistedExpansion

theorem nodesValid_prefix {variableLimit small large : Nat}
    {cache original : Nat → NodeDesc} (hbound : small ≤ large)
    (hagree : ∀ i, i < small → cache i = original i)
    (hvalid : NodesValid variableLimit large original) :
    NodesValid variableLimit small cache := by
  intro i hi
  have hv := hvalid i (Nat.lt_of_lt_of_le hi hbound)
  refine ⟨hi, ?_⟩
  rw [hagree i hi]
  rcases hv.2 with hconstant | hbranch
  · exact Or.inl hconstant
  · rcases hbranch with ⟨hrank, hvalue, hlow, hhigh, hlowRank, hhighRank⟩
    refine Or.inr ⟨hrank, hvalue, hlow, hhigh, ?_, ?_⟩
    · rw [hagree (original i).low (Nat.lt_trans hlow hi)]
      exact hlowRank
    · rw [hagree (original i).high (Nat.lt_trans hhigh hi)]
      exact hhighRank

def checkExpansionBody (variableLimit : Nat) (nodes : Nat → NodeDesc) :
    Nat → NodeTree → Bool
  | i, .constant n =>
      ((nodes i).rank == variableLimit) && ((nodes i).value == n)
  | i, .branch v low high =>
      ((nodes i).rank == v) && decide (v < variableLimit) &&
        checkExpansionBody variableLimit nodes (nodes i).low low &&
        checkExpansionBody variableLimit nodes (nodes i).high high

theorem checkExpansionBody_eq {variableLimit nodeCount : Nat}
    {nodes : Nat → NodeDesc} (hvalid : NodesValid variableLimit nodeCount nodes)
    (tree : NodeTree) : ∀ i, i < nodeCount →
    checkExpansionBody variableLimit nodes i tree =
      checkExpansion variableLimit nodeCount nodes i tree := by
  induction tree with
  | constant n =>
    intro i hi
    have hib : decide (i < nodeCount) = true := by
      simpa only [decide_eq_true_eq] using hi
    simp only [checkExpansionBody, checkExpansion, hib, Bool.true_and]
  | branch v low high ihlow ihhigh =>
    intro i hi
    have hib : decide (i < nodeCount) = true := by
      simpa only [decide_eq_true_eq] using hi
    cases hrank : ((nodes i).rank == v) with
    | false =>
      simp only [checkExpansionBody, checkExpansion, hrank, Bool.false_and,
        Bool.and_false]
    | true =>
      cases hvar : decide (v < variableLimit) with
      | false =>
        simp only [checkExpansionBody, checkExpansion, hrank, hvar,
          Bool.true_and, Bool.false_and, Bool.and_false]
      | true =>
        have hr : (nodes i).rank = v := by
          simpa only [beq_iff_eq] using hrank
        have hv : v < variableLimit := of_decide_eq_true hvar
        have hchildren : (nodes i).low < i ∧ (nodes i).high < i := by
          rcases (hvalid i hi).2 with ⟨hconstant, _, _⟩ | ⟨_, _, hlow, hhigh, _, _⟩
          · omega
          · exact ⟨hlow, hhigh⟩
        have hlb : decide ((nodes i).low < i) = true := by
          simpa only [decide_eq_true_eq] using hchildren.1
        have hhb : decide ((nodes i).high < i) = true := by
          simpa only [decide_eq_true_eq] using hchildren.2
        simp only [checkExpansionBody, checkExpansion, hrank, hvar, hib,
          hlb, hhb, Bool.true_and,
          ihlow (nodes i).low (Nat.lt_trans hchildren.1 hi),
          ihhigh (nodes i).high (Nat.lt_trans hchildren.2 hi)]

def checkExpansionHoisted (variableLimit nodeCount : Nat) (nodes : Nat → NodeDesc)
    (i : Nat) (tree : NodeTree) : Bool :=
  decide (i < nodeCount) && checkExpansionBody variableLimit nodes i tree

theorem checkExpansionHoisted_eq {variableLimit nodeCount : Nat}
    {nodes : Nat → NodeDesc} (hvalid : NodesValid variableLimit nodeCount nodes)
    (tree : NodeTree) (i : Nat) :
    checkExpansionHoisted variableLimit nodeCount nodes i tree =
      checkExpansion variableLimit nodeCount nodes i tree := by
  by_cases hi : i < nodeCount
  · have hib : decide (i < nodeCount) = true := by
      simpa only [decide_eq_true_eq] using hi
    simp only [checkExpansionHoisted, hib, Bool.true_and,
      checkExpansionBody_eq hvalid tree i hi]
  · have hib : decide (i < nodeCount) = false := by
      exact decide_eq_false hi
    cases tree <;>
      simp only [checkExpansionHoisted, checkExpansion, hib, Bool.false_and]

end ADWH.Experiments.Chapter15.BulkADD.HoistedExpansion

#print axioms ADWH.Experiments.Chapter15.BulkADD.HoistedExpansion.nodesValid_prefix
#print axioms ADWH.Experiments.Chapter15.BulkADD.HoistedExpansion.checkExpansionBody_eq
#print axioms ADWH.Experiments.Chapter15.BulkADD.HoistedExpansion.checkExpansionHoisted_eq
