# Independent review of the complete-count expansion refinement

24 October 2026. Reviewer: the `validity_contracts` agent, independent of the
helper and generator author. This review inspected the original node
invariant, expansion checker, exact prefix cache, concrete applications and
the proposed source. It performed source-only comparisons and generator
verification. It did not run Lean, a counter or any checker computation.

**Source-review decision:** the proposal has the required mathematical
boundary and is suitable for the planned generic development gate. This is
not acceptance of the generic proof, the complete n6 count, import-object
preparation, or the yet-to-be-executed full gate.

## Why the removed checks are justified

The original `NodeValid` distinguishes constants from genuine branch nodes.
Its branch case contains both strict child inequalities and the ordering of
child ranks. `NodesValid` supplies that fact at every bounded table index.
The proposed body retains rank equality and `v < variableLimit`; those tests
identify the branch case before the proof uses its child inequalities.
In particular, keeping the variable bound prevents a constant descriptor at
rank `variableLimit` from being accepted as a branch.

The helper's contracts have the necessary scope:

- `nodesValid_prefix` assumes an actual larger-table invariant, a numerical
  prefix bound and exact descriptor equality throughout the prefix. It
  rewrites the current descriptor, then separately rewrites both child
  descriptors using `low/high < i < small`. Equality at the parent alone
  would not justify the child-rank clauses; the implementation includes both
  required steps.
- `checkExpansionBody_eq` assumes table validity and an in-range root. Its
  constant case retains the exact rank/value comparisons. Its branch case
  preserves false rank or variable tests, and uses the invariant only in the
  matching in-range branch. The derived child bounds justify both induction
  hypotheses. Both recursive subtree checks remain.
- `checkExpansionHoisted_eq` retains one outer root-bound test and proves
  equality for **every natural-number root**. Out-of-range roots yield false
  on both sides, including zero-sized tables. Thus the complete interface
  does not assume that an arbitrary caller or generator supplied a valid ID.

The body remains structurally recursive over the supplied finite `NodeTree`.
No assertion about unchecked node semantics is introduced, and no termination
assumption is substituted for the removed runtime guards.

## Actual use in the complete certificate

The concrete source proves `fastNodes_valid` from the existing
`RealSix.nodes_valid`, the already checked `fastNodes_eq`, and `738 ≤ 9454`.
This uses the genuine packed descriptor proof and exact clipped-plane cache;
the validity statement is not supplied by Python or inferred from a hash.

Each of the 36 original `expansionN_fast_checked` theorem statements still
names the original `checkExpansion`. Its new proof rewrites through
`checkExpansionHoisted_eq fastNodes_valid` and applies `decide +kernel` to the
new Boolean. The original `checkExpansion_prefix`, `checkExpansion_sound`,
site-tensor proofs, arithmetic claims, factor plan and final source bridge
remain in use. The unchanged final theorem is
`RealSix.OptimizedSource.source_cqueens_six : BitRepresentation.cqueens 6 = 4`.

The existing prefix cache was already an accepted optimization. This proposal
adds reuse of its transported validity facts; it does not claim to invent
that cache or prove a new numerical answer.

## Independent preservation audit

`EXPANSION-SOURCE-AUDIT.json` records the source-only checks and all four
candidate hashes. They establish:

1. The generic bundle differs from its historical source only at 15 reviewed
   proof-alias occurrences. The source bundle differs only at eight such
   occurrences. Independently reversing the recorded positions reconstructs
   both original files exactly. Inspection of the actual diffs confirms these
   are theorem-proof expressions, not executable definitions or statements.
2. A separate reversal of the arithmetic module's added import, prefix-validity
   theorem/print and 36 rewrite lines reconstructs that entire original bundle
   exactly. This check did not call the generator's transformation routine.
   Hence all existing concrete data and other arithmetic/source proof text
   are preserved.
3. All 36 original expansion statements are byte-identical. The final
   `source_cqueens_six` statement and proof suffix are byte-identical.
4. All 334 original axiom-print roots remain, with exactly four new roots:
   three helper lemmas and `fastNodes_valid`, giving 338 distinct required
   reports. A required print inventory is not yet an observed successful audit.
5. The 36 literal trees contain 1,394 branch occurrences and 1,430 constants.
   The source transformation removes 2,788 repeated node-bound occurrences
   and 2,788 child-order occurrences while retaining 36 root guards. These
   are syntax counts, not measured reductions or a speedup estimate.

The generator's `--verify` passed after these independent checks. The
reviewed helper SHA-256 is
`7ad7e7622d19fc07e3368eb130e2f5b23ed6e8e5ea2971065d683425d891f671`.

## Lean version and acceptance boundary

The historical complete n6 gate used Lean 4.33.0-rc1. Replacing deprecated
aliases in copies is necessary preparation for 4.35, but it does not prove
complete compatibility. Any additional elaboration failure requires a
specific reviewed correction; it must not be hidden by disabling strict
warnings or changing theorem statements.

The source module retains its original ADWH imports. Their current accepted
4.35 source closure and any separately prepared objects must be bound by the
gate. This source review does not independently certify those objects or their
preparation. Experimental modules must all be freshly compiled together.

`PLAN.md` fixes four experimental compilation units, all 58 retained source
bodies plus the new helper, under one cumulative 30-second, one-CPU/thread,
`-j1 -M1024`, 1 GiB RSS gate. The two-module generic stage is development
evidence only. Successful checking of the four-module closure would establish
the complete n6 workflow with this refinement under 4.35; comparison with the
old 4.33 run would not isolate its performance effect.

No source defect or unproved new assumption was found in this review. Actual
Lean acceptance and resource behavior remain to be measured. This candidate
does not establish larger-board scaling or discharge `cqueens 16 = 14772512`.

## Pre-execution report-name correction

The runner author identified 14 historical generic `#print axioms` commands
whose identifiers are relative to their surrounding namespace. The generator
and manifest were corrected to distinguish those literal source identifiers
from the fully qualified names Lean reports. The mapping is taken in exact
order from the immutable historical accepted gate, with equality or an exact
dot-suffix relation checked for every spelling. The original print order and
coverage remain fixed; the complete expected inventory still has 338 distinct
full names.

Independent reinspection verified all 14 qualifications, the exact historical
name sequence and every unchanged Lean-source hash. The current generator's
`--verify` passes. This is a metadata correction before the relevant execution;
it changes no mathematical statement, proof or executable definition.
`EXPANSION-SOURCE-AUDIT.json` records the revised generator and manifest hashes.
