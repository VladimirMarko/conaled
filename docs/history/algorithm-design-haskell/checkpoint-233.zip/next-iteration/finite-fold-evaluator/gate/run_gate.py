#!/usr/bin/env python3
"""Fresh one-module FiniteFold proof gate; only --run invokes Lean."""
from __future__ import annotations

import argparse
from collections import Counter
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent
ROOT = HERE.parents[2]
SOURCE = CANDIDATE / 'source/FiniteFold.lean'
MANIFEST = HERE / 'source-manifest.json'
HELPER = ROOT / 'next-iteration/lean435-kernel-comparison/run_comparison.py'
GUARD = ROOT / 'project/adwh-lean/scripts/check.py'
PIN = ROOT / 'next-iteration/lean435-migration/toolchain.json'
RUNTIME_REFERENCE = ROOT / 'next-iteration/lean435-kernel-comparison/attempts/comparison-01/report.json'
LOCK = ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock'
FIXED = {
    HELPER: '2871916b1d6bb70042e9468ec236472f0d05cf065bc5b1d1fe75f3c6bf9bd8d0',
    GUARD: 'a5f7fa502f8c19609b73cf0e59a5fa9f98a5c0c533ae9e181d6dab8f733cf2ae',
    PIN: 'dbf68a7f5bb746f10563ffc332956a9d85958bc1d41cc68dea69233e7a0d795c',
    RUNTIME_REFERENCE: 'c9eafecf26a3d682c8a10232ac512eef45ebdde35e73e3a06f5fd652a94741c2',
}
MODULE = 'FiniteFold'
RAW_ROOTS = [
    'loop_zero', 'loop_succ', 'fold_zero', 'fold_succ', 'canonical_equations',
    'loop_unique_of_equations', 'fold_unique_of_equations',
    'branches_unique_of_equations', 'implementations_agree',
]
ROOTS = ['ADWH.Experiments.Chapter15.FiniteFold.' + name for name in RAW_ROOTS]
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
FORMAT = 'adwh-finite-fold-fresh-proof-gate-v1'
MANIFEST_FORMAT = 'adwh-finite-fold-proof-manifest-v1'
CURRENT = [
    ('runner', HERE / 'run_gate.py'),
    ('protocol', HERE / 'PROTOCOL.md'),
    ('source_manifest', MANIFEST),
    ('mathematical_design', CANDIDATE / 'DESIGN.md'),
    ('author_source_inventory', CANDIDATE / 'SOURCE-INVENTORY.json'),
    ('independent_source_review', CANDIDATE / 'SOURCE-REVIEW.md'),
    ('independent_source_audit', CANDIDATE / 'SOURCE-AUDIT.json'),
]
CONTEXT = [
    ('mapping_natural_counter', ROOT / 'project/adwh-lean/ADWH/Chapter15/QueensNatCounting.lean'),
    ('mapping_word_counter', ROOT / 'project/adwh-lean/ADWH/Chapter15/QueensFastCounting.lean'),
    ('mapping_source_counter', ROOT / 'project/adwh-lean/ADWH/Chapter15/QueensBitCounting.lean'),
    ('integration_contract', ROOT / 'next-iteration/reusable-evaluator-direction/INTEGRATION-CONTRACT.md'),
]
HISTORICAL = [
    ('resource_helper', HELPER), ('source_guard', GUARD), ('toolchain_pin', PIN),
    ('pinned_runtime_reference_report', RUNTIME_REFERENCE), *CONTEXT,
]


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify(rows, h, readonly=False):
    for row in rows:
        path = Path(row['path'])
        h.require(path.is_file() and not path.is_symlink()
                  and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'],
                  'Evidence binding differs: ' + str(path))
        if readonly:
            h.require(path.stat().st_mode & 0o222 == 0, 'Writable snapshot/marker: ' + str(path))


def resolved_binding(row, expected_path, h):
    path = (ROOT / row['path']).resolve()
    h.require(path == expected_path.resolve(), 'Evidence has the wrong path/role: ' + str(expected_path))
    actual = h.binding(path)
    h.require(all(actual[key] == row[key] for key in ('bytes', 'sha256')),
              'Declared source/control binding differs: ' + str(path))
    verify([actual], h)
    return actual


def source_fingerprint(source):
    identity = {'stage': 'complete', 'sources': [{'module': MODULE, 'sha256': source['sha256']}]}
    return hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def control_role(controls, role, expected_path, h, snapshot=False):
    expected = h.binding(expected_path.resolve())
    rows = [row for row in controls if row['role'] == role]
    h.require(len(rows) == 1 and {key: rows[0][key] for key in ('path', 'bytes', 'sha256')} == expected,
              'Missing or substituted control role: ' + role)
    if snapshot:
        frozen = rows[0].get('snapshot')
        h.require(rows[0]['snapshot_required'] and frozen is not None
                  and all(frozen[key] == expected[key] for key in ('bytes', 'sha256')),
                  'Current control has no matching snapshot: ' + role)
        verify([frozen], h, readonly=True)
    return expected


def preflight(args, h, guard):
    for path, expected in FIXED.items():
        h.require(path.is_file() and sha(path) == expected, 'Pinned historical input differs: ' + str(path))
    read = lambda path: json.loads(path.read_text(), object_pairs_hook=h.strict_object)
    manifest = read(MANIFEST)
    h.require(manifest['format'] == MANIFEST_FORMAT and manifest['module_order'] == [MODULE]
              and manifest['root_module'] == MODULE and manifest['required_axiom_report_count'] == 9
              and manifest['required_prints'] == {MODULE: ROOTS}
              and manifest['raw_source_print_identifiers'] == {MODULE: RAW_ROOTS}
              and manifest['imports'] == ['Init'] and manifest['prepared_objects'] == [],
              'Single-module source/root/import manifest differs')
    source = {**resolved_binding(manifest['source'], SOURCE, h), 'module': MODULE, 'imports': ['Init']}
    expected_review_paths = [path for role, path in CURRENT if role not in {'runner', 'protocol', 'source_manifest'}]
    h.require(len(manifest['review_controls']) == 4, 'Review-control inventory differs')
    for row, path in zip(manifest['review_controls'], expected_review_paths):
        resolved_binding(row, path, h)
    h.require(len(manifest['context_references']) == 4, 'Context reference inventory differs')
    context_rows = [resolved_binding(row, path, h)
                    for row, (_, path) in zip(manifest['context_references'], CONTEXT)]

    inventory = read(CANDIDATE / 'SOURCE-INVENTORY.json')
    independent = read(CANDIDATE / 'SOURCE-AUDIT.json')
    h.require(inventory['format'] == 'adwh-finite-fold-evaluator-mathematical-source-inventory-v1'
              and inventory['ordered_axiom_roots'] == ROOTS and inventory['raw_axiom_roots'] == RAW_ROOTS
              and inventory['imports'] == ['Init'] and inventory['proposed_fresh_gate']['modules'] == [MODULE]
              and inventory['proposed_fresh_gate']['total_roots'] == 9,
              'Authored source inventory describes a different contract')
    resolved_binding(inventory['source'], SOURCE, h)
    resolved_binding(inventory['design'], CANDIDATE / 'DESIGN.md', h)
    h.require(inventory['design_dependencies'] == manifest['context_references'],
              'Source-mapping provenance differs')
    h.require(independent['format'] == 'adwh-finite-fold-independent-source-audit-v1'
              and independent['status'] == 'passed_source_only_review_not_compiled'
              and independent['fully_qualified_roots'] == ROOTS
              and independent['raw_print_roots'] == RAW_ROOTS
              and independent['imports'] == ['Init'] and independent['resource_overrides'] == []
              and independent['exact_statement_inventory_independently_matched'] == inventory['theorems'],
              'Independent source audit describes a different contract')
    expected_audit_inputs = [h.binding(SOURCE), h.binding(CANDIDATE / 'DESIGN.md'),
                             h.binding(CANDIDATE / 'SOURCE-INVENTORY.json'), *context_rows]
    h.require(len(independent['inputs']) == len(expected_audit_inputs) == 7,
              'Independent source audit input count differs')
    for row, expected in zip(independent['inputs'], expected_audit_inputs):
        h.require(resolved_binding(row, Path(expected['path']), h) == expected,
                  'Independent source audit input identity differs')

    code = guard.check_lean_source(SOURCE, SOURCE.read_text())
    imports = [name for line in re.findall(r'^\s*import[ \t]+([^\n]+)$', code, re.M) for name in line.split()]
    h.require(imports == ['Init'], 'Unexpected import in the single-module closure')
    options = [('autoImplicit', 'false'), ('warningAsError', 'true'), ('Elab.async', 'false')]
    for option, value in options:
        found = re.findall(r'\bset_option\s+' + re.escape(option) + r'\s+(\S+)', code)
        h.require(found and set(found) == {value}, 'Strict source option differs: ' + option)
    h.require(not re.search(r'\bset_option\s+(maxHeartbeats|maxRecDepth|maxMemory)\b', code),
              'Source resource override is forbidden')
    raw_roots = re.findall(r'^\s*#print\s+axioms\s+(\S+)', code, re.M)
    theorem_names = re.findall(r'^\s*theorem\s+(\S+)', code, re.M)
    h.require(raw_roots == RAW_ROOTS and theorem_names == RAW_ROOTS,
              'Exact theorem declaration/print inventory differs')
    h.require(re.findall(r'^\s*namespace\s+(\S+)', code, re.M)
              == ['ADWH.Experiments.Chapter15.FiniteFold'], 'Source namespace differs')
    for item in inventory['theorems']:
        h.require(SOURCE.read_text().splitlines()[item['line'] - 1].startswith('theorem ' + item['name'])
                  and item['statement'] in SOURCE.read_text(), 'Theorem statement inventory differs')

    compiler_path = args.lean.resolve()
    h.TOOLCHAIN = compiler_path.parent.parent
    pins = read(PIN)
    compiler = h.binding(compiler_path)
    h.require(compiler_path.name == 'lean' and pins['version'] == '4.35.0'
              and pins['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
              and all(compiler[key] == pins['binaries']['lean'][key] for key in ('bytes', 'sha256')),
              'Pinned compiler identity differs')
    reference = read(RUNTIME_REFERENCE)
    expected_runtime = {Path(row['path']).name: (row['bytes'], row['sha256'])
                        for row in reference['controls'] if row['path'].endswith('.so')}
    runtime = [h.binding(path) for path in sorted((h.TOOLCHAIN / 'lib/lean').glob('*.so'))]
    h.require(len(runtime) == 5
              and {Path(row['path']).name: (row['bytes'], row['sha256']) for row in runtime} == expected_runtime,
              'Pinned shared runtime inventory differs')

    controls = [{**h.binding(path), 'role': role, 'snapshot_required': True,
                 'retained_historical_reference': False} for role, path in CURRENT]
    controls += [{**h.binding(path), 'role': role, 'snapshot_required': False,
                  'retained_historical_reference': True} for role, path in HISTORICAL]
    h.require(len(controls) == 15 and len({row['role'] for row in controls}) == 15
              and len({row['path'] for row in controls}) == 15, 'Duplicate control identity or role')
    for role, path in CURRENT + HISTORICAL:
        control_role(controls, role, path, h)
    verify([source, compiler, *runtime, *controls], h)
    return {'source': source, 'source_fingerprint': source_fingerprint(source),
            'controls': controls, 'compiler': compiler, 'runtime_libraries': runtime,
            'compiler_release': pins['version'], 'compiler_commit': pins['commit']}


def audit_logs(stdout, stderr):
    out, err = Path(stdout['path']).read_text(), Path(stderr['path']).read_text()
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    raw = [{'root': root, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
           for root, axes in pattern.findall(out + err)]
    names = [row['root'] for row in raw]
    permitted = all(set(row['axioms']) <= ALLOWED for row in raw)
    return {'passed': names == ROOTS and permitted and not err and not pattern.sub('', out).strip(),
            'required_count': 9, 'observed_count': len(raw), 'observed_unique_count': len(set(names)),
            'exact_ordered_names': names == ROOTS, 'all_raw_axiom_names_permitted': permitted,
            'duplicate_names': [name for name, n in Counter(names).items() if n > 1],
            'reports': {row['root']: row['axioms'] for row in raw}, 'raw_reports': raw,
            'stderr_empty': not err, 'unparsed_stdout': pattern.sub('', out).strip()}


def run(args, plan, h):
    attempt = HERE / 'attempts' / args.attempt
    marker_path = HERE / 'execution-markers' / ('complete-' + plan['source_fingerprint'] + '.json')
    h.require(not attempt.exists() and not marker_path.exists(), 'Attempt or unchanged source already executed')
    h.require(Path('/proc/self/status').is_file(), 'RSS enforcement requires /proc')
    frozen, build, input_copies = attempt / 'source', attempt / 'build', attempt / 'inputs'
    frozen.mkdir(parents=True)
    build.mkdir()
    input_copies.mkdir()
    report_path = attempt / 'report.json'
    report = {'format': FORMAT, 'status': 'preparing', 'attempt': args.attempt, 'stage': 'complete',
              'module_order': [MODULE], 'root_module': MODULE,
              'source_fingerprint': plan['source_fingerprint'], 'source_manifest': h.binding(MANIFEST),
              'source_bindings': [plan['source']], 'controls': plan['controls'],
              'compiler': plan['compiler'], 'compiler_release': plan['compiler_release'],
              'compiler_commit': plan['compiler_commit'], 'runtime_libraries': plan['runtime_libraries'],
              'execution_marker': None, 'current_control_snapshot_count': 7, 'historical_reference_count': 8,
              'modules': [], 'required_prints': {MODULE: ROOTS},
              'raw_source_print_identifiers': {MODULE: RAW_ROOTS}, 'required_axiom_report_count': 9,
              'observed_axiom_report_count': 0, 'observed_unique_axiom_root_count': 0,
              'accepted_axiom_report_count': 0, 'seconds': None, 'peak_child_rss_kib': 0,
              'artifacts': [], 'prepared_objects': [], 'object_search_path': str(build),
              'standard_library': 'Pinned Lean 4.35 release Init distribution',
              'constraints': {'cumulative_wall_seconds': 30, 'resident_memory_kib': 1048576,
                  'lean_memory_mib': 1024, 'compiler_threads': 1, 'cpu_affinity': [],
                  'default_heartbeats_and_recursion': True},
              'exact_build_artifact_inventory': False,
              'all_sources_snapshots_controls_runtime_unchanged': False,
              'all_selected_mathematical_sources_freshly_checked': False,
              'complete_finite_fold_proof_checked': False,
              'compiled_experimental_imports_reused': False, 'original_ADWH_imports_used': False,
              'source_count_proved': False, 'n16_target_proved': False,
              'native_evaluator_or_counter_executed': False, 'kernel_integration_implemented': False,
              'integrated_project_modified': False,
              'authorship': {'source_and_runner_author': 'validity_contracts',
                            'independent_source_reviewer': 'regression_audit', 'execution_owner': 'root'}}
    h.save(report_path, report)
    began = None
    original_cpus = os.sched_getaffinity(0)
    try:
        for row in report['source_bindings']:
            path = frozen / (MODULE + '.lean')
            with path.open('xb') as stream:
                stream.write(Path(row['path']).read_bytes())
            path.chmod(0o444)
            row['snapshot'] = h.binding(path)
            h.require(all(row['snapshot'][key] == row[key] for key in ('bytes', 'sha256')),
                      'Source snapshot differs')
        for control in report['controls']:
            if control['snapshot_required']:
                control_path = Path(control['path'])
                target = input_copies / control_path.relative_to(ROOT)
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as stream:
                    stream.write(control_path.read_bytes())
                target.chmod(0o444)
                control['snapshot'] = h.binding(target)
        verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']], h)
        verify([row['snapshot'] for row in report['source_bindings']], h, readonly=True)
        for role, path in CURRENT + HISTORICAL:
            control_role(report['controls'], role, path, h, snapshot=(role in {x[0] for x in CURRENT}))
        marker_path.parent.mkdir(exist_ok=True)
        marker_body = {'format': FORMAT, 'attempt': args.attempt, 'stage': 'complete',
                       'source_fingerprint': plan['source_fingerprint'],
                       'source_manifest': report['source_manifest'],
                       'source_bindings': report['source_bindings'], 'controls': report['controls'],
                       'compiler': report['compiler'], 'runtime_libraries': report['runtime_libraries'],
                       'utc_started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
        with marker_path.open('x') as stream:
            stream.write(json.dumps(marker_body, indent=2, sort_keys=True) + '\n')
        marker_path.chmod(0o444)
        report['execution_marker'] = h.binding(marker_path)
        cpu = min(original_cpus)
        os.sched_setaffinity(0, {cpu})
        report['constraints']['cpu_affinity'] = [cpu]
        env = h.clean_environment(build)
        for key in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'):
            env.pop(key, None)
        command = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
                   '-DwarningAsError=true', '-DElab.async=false',
                   '-o', str(build / (MODULE + '.olean')), '-i', str(build / (MODULE + '.ilean')),
                   MODULE + '.lean']
        report['status'] = 'running'
        h.save(report_path, report)
        began = time.monotonic()
        deadline = began + 30
        result = h.child(command, frozen, env, attempt / (MODULE + '.stdout.log'),
                         attempt / (MODULE + '.stderr.log'), cpu, deadline)
        audit = audit_logs(result['stdout'], result['stderr'])
        objects = all((build / (MODULE + suffix)).is_file() for suffix in ('.olean', '.ilean'))
        good = result['exit_code'] == 0 and result['within_limits'] and audit['passed'] and objects
        report['modules'].append({'module': MODULE, **result, 'axiom_audit': audit,
                                  'observed_report_occurrences': audit['observed_count'],
                                  'required_objects_present': objects, 'status': 'passed' if good else 'failed'})
        report['observed_axiom_report_count'] = audit['observed_count']
        report['observed_unique_axiom_root_count'] = audit['observed_unique_count']
        report['accepted_axiom_report_count'] = audit['observed_count'] if good else 0
        h.save(report_path, report)
        h.require(good, 'Fresh compiler module, exact axiom reports, or resource check failed')
    except BaseException as exc:
        report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        try:
            verify(report['source_bindings'] + report['controls'] + report['runtime_libraries'] + [report['compiler']], h)
            snapshots = [row['snapshot'] for row in report['source_bindings'] + report['controls'] if 'snapshot' in row]
            h.require(len(snapshots) == 8, 'Incomplete source/control snapshots')
            verify(snapshots, h, readonly=True)
            verify([row[key] for row in report['modules'] for key in ('stdout', 'stderr')], h)
            for row in report['source_bindings']:
                h.require(all(row['snapshot'][key] == row[key] for key in ('bytes', 'sha256')),
                          'Source snapshot identity changed')
            for role, path in CURRENT + HISTORICAL:
                control_role(report['controls'], role, path, h, snapshot=(role in {x[0] for x in CURRENT}))
            h.require(report['execution_marker'] is not None, 'Execution marker was not reserved')
            verify([report['execution_marker']], h, readonly=True)
            report['all_sources_snapshots_controls_runtime_unchanged'] = True
            report['artifacts'] = [h.binding(path) for path in sorted(build.rglob('*')) if path.is_file()]
            expected_objects = {str(build / (MODULE + suffix)) for suffix in ('.olean', '.ilean')}
            report['exact_build_artifact_inventory'] = {row['path'] for row in report['artifacts']} == expected_objects
        except BaseException as exc:
            report['postcheck_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        try:
            os.sched_setaffinity(0, original_cpus)
        except BaseException as exc:
            report['affinity_restore_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        report['seconds'] = None if began is None else time.monotonic() - began
        report['peak_child_rss_kib'] = max((row['sampled_tree_and_wait4_peak_rss_kib'] for row in report['modules']), default=0)
        passed = (not any(key in report for key in ('failure', 'postcheck_failure', 'affinity_restore_failure'))
                  and len(report['modules']) == 1 and report['modules'][0]['status'] == 'passed'
                  and report['accepted_axiom_report_count'] == 9
                  and report['seconds'] is not None and report['seconds'] <= 30
                  and report['peak_child_rss_kib'] <= 1048576
                  and report['exact_build_artifact_inventory']
                  and report['all_sources_snapshots_controls_runtime_unchanged'])
        report['status'] = 'passed' if passed else 'failed'
        report['all_selected_mathematical_sources_freshly_checked'] = passed
        report['complete_finite_fold_proof_checked'] = passed
        h.save(report_path, report)
    print(json.dumps({'status': report['status'], 'report': h.binding(report_path),
                      'seconds': report['seconds'], 'peak_rss_kib': report['peak_child_rss_kib'],
                      'observed_roots': report['observed_axiom_report_count'],
                      'accepted_roots': report['accepted_axiom_report_count']}, sort_keys=True))
    return 0 if report['status'] == 'passed' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', type=Path,
                        default=ROOT.parent / 'toolchains/lean-4.35.0-linux/bin/lean')
    parser.add_argument('--attempt', default='complete-01')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'complete-(?:0[1-9]|[1-9][0-9])', args.attempt):
        raise ValueError('Attempt must be complete-01 through complete-99')
    for path, expected in FIXED.items():
        if sha(path) != expected:
            raise ValueError('Pinned code/evidence differs before loading: ' + str(path))
    h = load(HELPER, 'finite_fold_resource_helper')
    guard = load(GUARD, 'finite_fold_source_guard')
    h.require(h.MEMORY_KIB == 1048576 and set(h.ALLOWED) == ALLOWED, 'Pinned helper contract differs')
    plan = preflight(args, h, guard)
    if not args.run:
        print(json.dumps({'status': 'preflight_passed_no_compiler_executed', 'module_order': [MODULE],
                          'required_axiom_report_count': 9, 'prepared_objects': 0,
                          'current_controls_to_snapshot': 7, 'historical_references_bound_in_place': 8,
                          'source_fingerprint': plan['source_fingerprint'],
                          'source_manifest': h.binding(MANIFEST)}, sort_keys=True))
        return 0
    with LOCK.open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return run(args, plan, h)


if __name__ == '__main__':
    raise SystemExit(main())
