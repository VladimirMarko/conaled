# One fresh ordinary-kernel check of FiniteFold

## Selected mathematical boundary

The sole new mathematical module is `source/FiniteFold.lean`, imported as `FiniteFold`. Its only import is the pinned Lean distribution's `Init`. There are **nine exact theorem roots**, listed in `source-manifest.json`; all nine must actually appear in the compiler's axiom reports. The experiment proves the finite-fold equations and their uniqueness contract. It computes no queen count, invokes no native evaluator, implements no kernel hook, and does not change the integrated project.

The helper, design, author inventory, and independent source review/audit are frozen before execution. The runner's author also authored the helper; `regression_audit` independently reviewed the mathematical source. The parent agent owns execution. This protocol and runner require independent review before use. Their existence is not a gate outcome.

The source manifest is data prepared from those exact files. The runner checks its source/import/root lists, all four review-control identities, author inventory, independent audit status and complete seven-input map, exact theorem declarations/statements/prints, and four contextual references. It does not execute a manifest generator. Any changed source requires an updated, reviewed manifest and reviews before another attempt.

## Command and one-use attempt

From this gate directory, the parent may first inspect the no-run mode and then dispatch the one run:

```sh
python3 -I run_gate.py
python3 -I run_gate.py --run --attempt complete-01
```

Without `--run`, the runner performs read-only source/control/runtime checks and creates no attempt, marker, or compiled artifact. The author has not run either mode. The default compiler is the workspace's Lean 4.35.0 distribution; `--lean` may point to the exact same pinned binary at a restored location. An alternate version or runtime is rejected.

Before any compiler process starts, the runner obtains the existing nonblocking project compile lock and exclusively reserves a read-only marker:

```text
execution-markers/complete-<source-fingerprint>.json
```

The fingerprint covers the `complete` stage and the exact ordered module/source hash. It excludes attempt labels and control metadata. Both the requested attempt directory and the source-keyed marker must be absent. They remain after failure; changing a label or documentation cannot authorize a second unchanged execution. There is no overwrite, delete, skip-check, or limit override switch. A genuinely corrected, independently reviewed source may use the next `complete-NN` label and a different source fingerprint; the failed evidence remains untouched.

## Freshness and resource limits

The runner creates a fresh empty build directory and copies the one source to a read-only snapshot. `LEAN_PATH` is exactly that fresh build directory. No experimental objects, original ADWH object pool, or earlier result are reused. The already installed `Init` distribution is the only compiled mathematical dependency.

The single compiler command is structurally fixed:

```text
<pinned lean> -j1 -M1024
  -DautoImplicit=false -DwarningAsError=true -DElab.async=false
  -o <fresh build>/FiniteFold.olean
  -i <fresh build>/FiniteFold.ilean
  FiniteFold.lean
```

The existing pinned `lean435-kernel-comparison/run_comparison.py` supplies `h.child`, unchanged. It enforces one selected CPU, process-group isolation, cumulative deadline handling, aggregate descendant RSS sampling, exit high-water RSS checks, and its existing CPU/file/core safeguards. The limit is **30 cumulative seconds**, **one CPU/thread**, **1,024 MiB Lean memory**, and **1,048,576 KiB observed resident memory**. The helper does not impose an address-space limit; sampled RSS is not described as one.

The timer begins immediately before the compiler call, and final elapsed checking includes raw-log analysis, post-execution source/control/runtime/log/marker checks, and artifact hashing. Source checks and snapshot preparation happen before that interval. The compiler receives the remaining shared deadline, rather than a reset timeout. The gate rejects a final elapsed or RSS breach even if the compiler already returned zero. Default heartbeat and recursion settings remain unchanged; source options overriding these limits are forbidden.

The environment is the pinned helper's clean environment, with `LEAN_NUM_THREADS=1`, numerical-library thread counts one, and all Lean/Lake/comparator overrides removed. Loader injection variables are also removed. The compiler and all five shared runtime libraries are size/hash-checked before and after execution. No upstream metatheory source is imported or built by this gate.

## Explicit evidence roles

Seven current controls are snapshotted read-only, retaining their paths relative to `work/`:

| Role | Input |
| --- | --- |
| `runner` | `gate/run_gate.py` |
| `protocol` | `gate/PROTOCOL.md` |
| `source_manifest` | `gate/source-manifest.json` |
| `mathematical_design` | `DESIGN.md` |
| `author_source_inventory` | `SOURCE-INVENTORY.json` |
| `independent_source_review` | `SOURCE-REVIEW.md` |
| `independent_source_audit` | `SOURCE-AUDIT.json` |

Together with the one mathematical source, this makes eight source/control snapshots. Each snapshot must have the exact original size/hash and read-only mode.

Eight historical/contextual references are bound in place: the exact resource helper, source guard, toolchain pin, and pinned runtime reference report; plus the three original counting sources and integration note referenced by the independent source review. The latter four establish the provenance of the design mapping; they are **not imports, numeric premises, executed programs, or compiled objects** in this experiment.

The runtime comparison report is used only in its explicit `pinned_runtime_reference_report` role to identify the five distribution shared libraries. This gate has no baseline-count report, prior generic acceptance premise, generic/full split, or inherited generic-report pointer. Every role is checked by exact path/size/hash before execution and again afterward. The permanent marker binds the exact sources, current snapshots, control roles, compiler, runtime, and source fingerprint.

## Acceptance and failure reporting

The source guard rejects admissions, unsafe/native proof shortcuts, kernel bypasses, and unsupported options. The source's one namespace, nine theorem declaration names, exact statement inventory and nine `#print axioms` names must match the reviewed lists. The import closure must remain exactly the one local module plus `Init`.

Compiler acceptance requires zero exit, no resource event, both required fresh object files, and exactly the nine fully qualified axiom reports in the reviewed order. The parser retains each raw occurrence; duplicates or substituted names cannot be hidden by a dictionary. Every raw axiom name must be in `propext`, `Quot.sound`, `Classical.choice`. Empty axiom lists are valid. No expected axiom list is inferred merely from the source proof style. Stderr and all stdout outside the nine report records must be empty.

Observed reports from an unsuccessful module are retained but contribute zero to the accepted report count. Final gate success additionally requires exactly the two `.olean`/`.ilean` files in the fresh build directory, complete immutable snapshots, unchanged original sources/controls/runtime/logs/marker, and the final time/RSS bounds. The source/axiom checks are not skipped because an earlier experiment passed.

`attempts/complete-01/report.json` records the actual source/control/snapshot bindings, compiler/runtime, command, stdout/stderr hashes, exit status, axiom occurrences, resource observations, permanent marker and artifact identities. It is saved before execution and after the child; exceptions produce a failed report and preserve prior evidence. The compiler artifacts are current verification evidence and should not be included in source-only durability checkpoints.

Passing this gate establishes the nine universal finite-fold theorem roots under the existing ordinary-kernel trust boundary. It does not establish the proposed NatCounting adapter, a native compiled executor's result, a custom checker implementation, or `cqueens 16`.
