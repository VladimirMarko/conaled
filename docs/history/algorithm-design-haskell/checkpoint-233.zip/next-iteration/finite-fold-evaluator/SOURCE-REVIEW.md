# Independent review of the finite-fold equations

25 October 2026. Reviewer: `/root/regression_audit`.

**No mathematical source blocker found.** The four candidate equations determine
both functions pointwise by the two stated inductions. The helper preserves
terminal behavior, both fuel/depth boundaries and every additive occurrence.
It is a reusable finite semantics and uniqueness result, not an executed
evaluator, a complete-search theorem, or a native proof of a queen count.

I did not author the helper, design or inventory. I authored the separate
kernel-operation assessment. This review read the full source and design,
independently matched every theorem header and print command, and verified
all recorded file hashes. It ran no Lean, compiler, generator, checker or
counter. Actual elaboration and the axiom census await the parent's gate.

## Mathematical contract

`Spec` has exactly the eight documented fields over arbitrary state, cursor
and choice types in three universes. There is no board width, expected count,
lookup table, ordering invariant or hidden reachability assumption.

The two explicit natural parameters provide total finite behavior. `loop`
recurses on its fuel, retaining the parent state and continuation while updating
the cursor. `fold` recurses on outer depth and supplies the smaller-depth fold
as that continuation. No decrease property of `rest` is needed. A budget can
therefore be too short for a client's intended unbounded problem; the helper
correctly makes no completeness claim for that problem.

The boundary cases agree in definitions and candidate equations:

| Case | Required result |
| --- | --- |
| Inner fuel zero, for any cursor | Zero. |
| Positive inner fuel and empty cursor | Zero. |
| Positive inner fuel and nonempty cursor | One child contribution plus the loop with smaller fuel and the next cursor. |
| Outer depth zero and nonterminal state | Zero. |
| Terminal state at any depth, including zero | Exactly `terminalValue state`. |
| Positive outer depth and nonterminal state | Inner candidate at the predecessor depth, with that state's exact budget and initial cursor. |

In particular, the same child reached by two cursor occurrences contributes
twice. There is no deduplication, omitted branch or aggregation of unverified
candidate values. Terminal values are arbitrary natural values supplied by
the specification; clients must justify their interpretation separately.

`Equations` is a genuine explicit premise. It requires all four recurrences
for all states/cursors/depths/fuels of the candidate functions. Merely proposing
a function or obtaining an output from a native program does not supply this
premise. Conversely, its universal equations are strong enough for the stated
uniqueness results; no numeral equality is smuggled into the assumptions.

## Proof review and elaboration risks

The four canonical equation lemmas and `canonical_equations` use definitional
equality. The lambda in the canonical `fold` definition and its partially
applied form in `fold_succ` have the intended eta-equivalent continuation.

`loop_unique_of_equations` fixes one outer depth and assumes candidate equality
at every state at that depth. It inducts on inner fuel while generalizing the
cursor. The successor proof rewrites the candidate loop equation, then uses
congruence of the unchanged Boolean guard and each addition argument. The
first congruence consumes equality of the child outer result; the second
consumes the induction hypothesis at `rest cursor`. Both are available with
the exact arguments used.

`fold_unique_of_equations` inducts on depth while generalizing state. In the
successor case its induction hypothesis is precisely the all-state equality
required by the preceding loop theorem. Its branch congruence preserves the
same terminal test and terminal value. The separate branch-uniqueness theorem
then supplies that hypothesis from the proved outer uniqueness result.
`implementations_agree` composes the two pointwise equalities through the same
canonical fold.

The scripts use reflexivity, induction, explicit `change`, field-equation
rewriting and `congrArg`. There are no unverified library lemma-name guesses,
large simplifier calls, concrete evaluation or resource overrides. I found no
specific unification or structural-recursion obstacle by inspection. This is
not a substitute for compilation: the actual compiler must still validate
the recursive definitions, proof scripts and permitted axioms. No exact axiom
set is claimed before observing the gate.

## Correct prospective mapping to NatCounting

The design's proposed client is faithful to the current accepted definitions.
For a fixed mask, use `Masks` as state and `Nat` as both cursor and choice;
terminal means the occupied component equals the mask, terminal value is 1,
start is `available`, empty means zero, head is `low`, rest subtracts `low`,
next is the existing `next`, and budget is 16. The candidate inner function is
the original `sumBits` with the original captured `count`/`next` callback.
Its predecessor-depth argument matches the outer successor equation exactly.

The necessary Boolean-guard simplifications are ordinary bridges from
`decide (p)` to the original conditionals. The modulo 65,536 operations,
subtraction from 65,535, source depth 16 and loop budget 16 remain properties
of that client; they are not altered or assumed away by the generic helper.
An actual adapter theorem still needs to be added and checked. The final
source connection still uses `NatCounting.cqueensNat_eq`; board correctness
retains the original `n ≤ 16` scope.

## Scope and gate requirements

The only import is `Init`. The two definitions, two structures, nine theorem
headers and nine raw print identifiers exactly match the author inventory.
All prints occur inside the declared namespace, giving nine distinct fully
qualified roots. Only the three strict source options are present. There are
no custom axioms, admitted proofs, unsafe/partial implementations,
`implemented_by`, `native_decide`, code execution commands or kernel bypass.
There is no function-extensionality call or concrete queen parameter in the
helper.

The fresh gate must check this source once under the pinned toolchain with
one CPU/thread, `-j1 -M1024`, default recursion/heartbeat settings and the
unchanged cumulative 30-second/1,048,576-KiB limits. Require zero exit, nine
actual expected axiom reports, both fresh objects and unchanged source/control/
runtime bindings. Preserve any failed attempt before a source correction.

A successful helper gate would establish an equation-uniqueness foundation.
It would still leave the source adapter, compiled-executor refinement,
machine-word overflow/fallback, runtime space bound, program installation,
actual reducer case and cached/driver integration unproved. A custom validating
execution and a stock Lean accepted numerical theorem remain distinct evidence.

## Frozen identities

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `source/FiniteFold.lean` |8,612|`25d84a52adca5f4c60163640aee8f31ded88322b8bd98c27f96d1aeb0c8b5d4e`|
| `DESIGN.md` |8,914|`801b55e872d9a6a0b2560c978a4ae703ba1b33ef5171d78ed984c9672f865450`|
| `SOURCE-INVENTORY.json` |8,224|`95516c6c940181c104b178edc23cf59a7d07bb92159e8f8aa542f5c026c14f38`|
| `SOURCE-AUDIT.json` |9,161|`f24ccd9bde591edcbd7e58a5fa81f663a3ef2b1fa3069505368dda9866f10360`|

The audit also binds the four design references independently, including the
exact original natural-mask source and current integration contract. None of
these referenced ADWH modules is an import dependency of this helper gate.
