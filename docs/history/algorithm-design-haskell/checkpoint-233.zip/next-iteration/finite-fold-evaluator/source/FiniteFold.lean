import Init

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# A finite additive fold determined by its equations

The outer depth and inner loop fuel make this semantics total, for arbitrary
states, cursors, choices, and cursor operations. No decrease property of a
cursor, machine-word bound, or expected numerical result is assumed.

`Equations` is a contract for another implementation of the same two-level
computation. Its uniqueness theorem is an ordinary equality theorem. It does
not certify an external executable or install a native kernel reduction.
-/

namespace ADWH.Experiments.Chapter15.FiniteFold

universe u v w

/-- Data controlling a finite additive search. A terminal state may return an
arbitrary natural value; every nonterminal state at depth zero returns zero.
Repeated cursor updates need not approach an empty cursor: the explicit loop
fuel bounds their number. -/
structure Spec (State : Type u) (Cursor : Type v) (Choice : Type w) where
  terminal : State → Bool
  terminalValue : State → Nat
  start : State → Cursor
  empty : Cursor → Bool
  head : Cursor → Choice
  rest : Cursor → Cursor
  next : State → Choice → State
  budget : State → Nat

variable {State : Type u} {Cursor : Type v} {Choice : Type w}

/-- Add one contribution per cursor occurrence, stopping on an empty cursor
or exhausted loop fuel. Repeated successor states retain their multiplicity. -/
def loop (spec : Spec State Cursor Choice) (f : State → Nat) (state : State) :
    Nat → Cursor → Nat
  | 0, _ => 0
  | fuel + 1, cursor =>
      if spec.empty cursor then 0 else
        f (spec.next state (spec.head cursor)) +
          loop spec f state fuel (spec.rest cursor)

/-- A structurally finite outer fold. A terminal value is returned at every
depth, including zero. -/
def fold (spec : Spec State Cursor Choice) : Nat → State → Nat
  | 0, state =>
      if spec.terminal state then spec.terminalValue state else 0
  | depth + 1, state =>
      if spec.terminal state then spec.terminalValue state else
        loop spec (fun child => fold spec depth child) state
          (spec.budget state) (spec.start state)

theorem loop_zero (spec : Spec State Cursor Choice) (f : State → Nat)
    (state : State) (cursor : Cursor) :
    loop spec f state 0 cursor = 0 := rfl

theorem loop_succ (spec : Spec State Cursor Choice) (f : State → Nat)
    (state : State) (fuel : Nat) (cursor : Cursor) :
    loop spec f state (fuel + 1) cursor =
      if spec.empty cursor then 0 else
        f (spec.next state (spec.head cursor)) +
          loop spec f state fuel (spec.rest cursor) := rfl

theorem fold_zero (spec : Spec State Cursor Choice) (state : State) :
    fold spec 0 state =
      if spec.terminal state then spec.terminalValue state else 0 := rfl

theorem fold_succ (spec : Spec State Cursor Choice) (depth : Nat)
    (state : State) :
    fold spec (depth + 1) state =
      if spec.terminal state then spec.terminalValue state else
        loop spec (fold spec depth) state
          (spec.budget state) (spec.start state) := rfl

/-- The exact equations required of an outer function `F` and an inner
function `B`. The inner function's depth selects the already smaller outer
depth; its separate fuel controls the remaining cursor occurrences. -/
structure Equations (spec : Spec State Cursor Choice)
    (F : Nat → State → Nat) (B : Nat → State → Nat → Cursor → Nat) : Prop where
  fold_zero : ∀ state,
    F 0 state =
      if spec.terminal state then spec.terminalValue state else 0
  fold_succ : ∀ depth state,
    F (depth + 1) state =
      if spec.terminal state then spec.terminalValue state else
        B depth state (spec.budget state) (spec.start state)
  loop_zero : ∀ depth state cursor,
    B depth state 0 cursor = 0
  loop_succ : ∀ depth state fuel cursor,
    B depth state (fuel + 1) cursor =
      if spec.empty cursor then 0 else
        F depth (spec.next state (spec.head cursor)) +
          B depth state fuel (spec.rest cursor)

theorem canonical_equations (spec : Spec State Cursor Choice) :
    Equations spec (fold spec)
      (fun depth state fuel cursor =>
        loop spec (fold spec depth) state fuel cursor) :=
  { fold_zero := fun _ => rfl
    fold_succ := fun _ _ => rfl
    loop_zero := fun _ _ _ => rfl
    loop_succ := fun _ _ _ _ => rfl }

/-- Once the candidate outer values at one depth are known, its inner loop
is uniquely determined at that depth by the base and successor equations. -/
theorem loop_unique_of_equations (spec : Spec State Cursor Choice)
    (F : Nat → State → Nat) (B : Nat → State → Nat → Cursor → Nat)
    (h : Equations spec F B) (depth : Nat)
    (hF : ∀ state, F depth state = fold spec depth state)
    (state : State) (fuel : Nat) (cursor : Cursor) :
    B depth state fuel cursor =
      loop spec (fold spec depth) state fuel cursor := by
  induction fuel generalizing cursor with
  | zero =>
      change B depth state 0 cursor = 0
      exact h.loop_zero depth state cursor
  | succ fuel ih =>
      change B depth state (fuel + 1) cursor =
        if spec.empty cursor then 0 else
          fold spec depth (spec.next state (spec.head cursor)) +
            loop spec (fold spec depth) state fuel (spec.rest cursor)
      rw [h.loop_succ]
      apply congrArg (fun value : Nat => if spec.empty cursor then 0 else value)
      calc
        F depth (spec.next state (spec.head cursor)) +
            B depth state fuel (spec.rest cursor) =
          fold spec depth (spec.next state (spec.head cursor)) +
            B depth state fuel (spec.rest cursor) :=
          congrArg (fun value : Nat =>
            value + B depth state fuel (spec.rest cursor))
            (hF (spec.next state (spec.head cursor)))
        _ = fold spec depth (spec.next state (spec.head cursor)) +
            loop spec (fold spec depth) state fuel (spec.rest cursor) :=
          congrArg (fun value : Nat =>
            fold spec depth (spec.next state (spec.head cursor)) + value)
            (ih (spec.rest cursor))

/-- Any candidate satisfying the four equations equals the canonical finite
fold at every depth and state. The equations, rather than a computed answer,
are the entire premise. -/
theorem fold_unique_of_equations (spec : Spec State Cursor Choice)
    (F : Nat → State → Nat) (B : Nat → State → Nat → Cursor → Nat)
    (h : Equations spec F B) (depth : Nat) (state : State) :
    F depth state = fold spec depth state := by
  induction depth generalizing state with
  | zero =>
      change F 0 state =
        if spec.terminal state then spec.terminalValue state else 0
      exact h.fold_zero state
  | succ depth ih =>
      change F (depth + 1) state =
        if spec.terminal state then spec.terminalValue state else
          loop spec (fold spec depth) state
            (spec.budget state) (spec.start state)
      rw [h.fold_succ]
      exact congrArg (fun value : Nat =>
        if spec.terminal state then spec.terminalValue state else value)
        (loop_unique_of_equations spec F B h depth ih state
          (spec.budget state) (spec.start state))

theorem branches_unique_of_equations (spec : Spec State Cursor Choice)
    (F : Nat → State → Nat) (B : Nat → State → Nat → Cursor → Nat)
    (h : Equations spec F B) (depth : Nat) (state : State)
    (fuel : Nat) (cursor : Cursor) :
    B depth state fuel cursor =
      loop spec (fold spec depth) state fuel cursor :=
  loop_unique_of_equations spec F B h depth
    (fun child => fold_unique_of_equations spec F B h depth child)
    state fuel cursor

/-- Two implementations satisfying the same specification's equations agree
on all outer results. No function extensionality or concrete evaluation is
needed: the conclusion is pointwise. -/
theorem implementations_agree (spec : Spec State Cursor Choice)
    (F₁ F₂ : Nat → State → Nat)
    (B₁ B₂ : Nat → State → Nat → Cursor → Nat)
    (h₁ : Equations spec F₁ B₁) (h₂ : Equations spec F₂ B₂)
    (depth : Nat) (state : State) :
    F₁ depth state = F₂ depth state :=
  (fold_unique_of_equations spec F₁ B₁ h₁ depth state).trans
    (fold_unique_of_equations spec F₂ B₂ h₂ depth state).symm

#print axioms loop_zero
#print axioms loop_succ
#print axioms fold_zero
#print axioms fold_succ
#print axioms canonical_equations
#print axioms loop_unique_of_equations
#print axioms fold_unique_of_equations
#print axioms branches_unique_of_equations
#print axioms implementations_agree

end ADWH.Experiments.Chapter15.FiniteFold
