# Independent source review of the FiniteFold gate

**No source-level blocker found.** The reviewed gate is suitable for the parent's
single fresh ordinary-kernel attempt after the parent's no-run preflight. This
review is not a compiler outcome. The reviewer did not import the runner, invoke
its preflight, execute the source guard, run a generator or start Lean.

The helper and runner were authored by `validity_contracts`.
`regression_audit` independently reviewed both the mathematical source and this
gate. `root` owns dispatch and final acceptance. This file is a separate,
unbound review; it does not introduce a circular manifest dependency or alter
any reviewed input.

## Exact reviewed files

| File | Bytes | SHA256 |
|---|---:|---|
| `gate/run_gate.py` | 24,018 | `79895f291d79df4a66beab4db2a9388dd1350edfddc99e0ca8c7dd1cf38cbeb3` |
| `gate/PROTOCOL.md` | 8,344 | `5b4d766753869a8a0d29d6eeaa60ec105fae8b911630258c15fcf65fe69f0a94` |
| `gate/source-manifest.json` | 3,357 | `16e4d9f19f5cd351520830fac0b5d6719e161317bec64033ef9396df8f75a7bf` |
| `source/FiniteFold.lean` | 8,612 | `25d84a52adca5f4c60163640aee8f31ded88322b8bd98c27f96d1aeb0c8b5d4e` |

All identities were independently hashed. The manifest's source, four review
controls and four contextual references were checked against their actual
files. The independent statement inventory equals the author inventory and the
manifest's ordered root list. The runner was read in full and parsed as Python
syntax without execution. The four fixed historical helper/guard/toolchain/
runtime-reference hashes also match their retained files.

The source-only computation of the selected stage/source fingerprint is
`82bc2585533fd8c956432fba443a699d29b6e00c5d9fb1aa2eea88d0a30c88bb`.
This is an independently derived identity, not a claim that the gate's preflight
or compiler has already passed.

## Source closure and evidence roles

There is one new module, `FiniteFold`, with the sole import `Init`. No prepared
objects, ADWH imports, old experimental objects, numerical baseline, generic
acceptance result or native counter output is a mathematical dependency.

The nine required roots, in order, are `loop_zero`, `loop_succ`, `fold_zero`,
`fold_succ`, `canonical_equations`, `loop_unique_of_equations`,
`fold_unique_of_equations`, `branches_unique_of_equations`, and
`implementations_agree`, all in
`ADWH.Experiments.Chapter15.FiniteFold`. The manifest, author inventory,
independent source audit, actual theorem declarations, raw print identifiers
and fully qualified compiler reports are checked through distinct identities.
Acceptance cannot be satisfied merely by nine unrelated prints.

The current snapshot set has exactly seven controls: runner, protocol, manifest,
design, author source inventory and the two independent source-review files.
Together with the one mathematical source this produces eight read-only
snapshots before compiler dispatch. The eight retained references are the four
fixed enforcement/compiler/runtime controls and four mapping-context files.
The context files are bound provenance, not imports or executed programs.

The historical comparison report has only the explicit
`pinned_runtime_reference_report` role. The old generic-report path-shadowing
defect is inapplicable here: this gate has no prior generic acceptance input or
generic/full branch. `control_role` requires one exact path/size/hash for each
named role and checks each required current snapshot separately.

## Freshness, one-use marker and resource enforcement

The nonblocking shared compile lock encloses execution. The attempt path and
source-keyed marker must both be absent. The fresh source/build/input directories
are created without overwrite; source and current controls are copied and
hashed, made read-only, and rechecked before the marker is exclusively created.
The marker binds source, manifest, controls and snapshots, compiler/runtime,
attempt and stage. Its fingerprint ignores labels and documentation, so a new
attempt label or changed commentary cannot repeat unchanged mathematics.

The compiler receives only the fresh build directory as experimental
`LEAN_PATH`. Its command is fixed to `-j1 -M1024`, strict warnings,
`autoImplicit=false`, synchronous elaboration, fresh `.olean`/`.ilean` outputs
and the frozen local source. All source default heartbeat/recursion settings
remain unchanged. Source guards and the explicit option/import checks run before
dispatch. There is no overwrite, skip, limit increase or arbitrary compiler
argument flag.

The gate invokes the unchanged pinned `h.child` once with a single 30-second
deadline. That helper establishes one CPU, a process group, CPU/file/core
safeguards, sampled descendant RSS monitoring and exit high-water RSS checking.
The runner additionally checks the final cumulative elapsed time and one-GiB
RSS ceiling after source/control/runtime/log/marker and artifact postchecks.
It does not substitute an address-space restriction for the established RSS
policy. The source-side Lean memory limit is 1,024 MiB.

The inherited environment removes Lean/Lake/comparator overrides, forces the
standard one-thread settings and then removes loader injection variables. The
compiler identity must match the pinned 4.35.0 binary and commit; all five
recorded shared libraries must match the retained reference before and after
execution. This retains the existing trust in the installed pinned standard
library distribution. It is not a hermetic operating-system proof or an
independent hash census of every `Init` object.

## Result parsing and failure preservation

The axiom parser retains every occurrence in order. Exact root order, no
duplicates or substitutions, all permitted axiom names, empty stderr and no
unparsed stdout are required. An empty axiom list is accepted when actually
reported; the runner does not assume it from the proofs' style. The only
permitted names are `propext`, `Quot.sound` and `Classical.choice`.

A module is accepted only after zero compiler exit, no resource event, the exact
axiom audit and both fresh objects. Failed-module prints remain observed evidence
and contribute zero accepted roots. Final success also requires exactly two
artifact files, eight complete matching read-only snapshots, unchanged sources/
controls/runtime/logs/marker, no exception and the cumulative limits. The runner
saves preparing/running/final evidence, preserves failed attempts and artifacts,
and restores CPU affinity. A genuine future source correction needs a new
reviewed source hash and leaves the original failed evidence intact.

No execution or outcome is asserted here. A successful gate would establish
the nine finite-fold equation/uniqueness roots at the ordinary-kernel boundary.
It would not prove the NatCounting adapter, native evaluation correctness, an
integrated kernel hook, or any concrete queen count.
