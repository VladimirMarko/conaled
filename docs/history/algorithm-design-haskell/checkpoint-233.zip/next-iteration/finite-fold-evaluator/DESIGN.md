# Finite-fold equations as a reusable evaluator contract

## Scope and status

This is the small mathematical step selected by the parent after the source-only [integration review](../reusable-evaluator-direction/INTEGRATION-CONTRACT.md). `source/FiniteFold.lean` defines a total finite additive computation and proves that its four equations uniquely determine every result. It imports only `Init`, uses strict source options, and introduces no resource override, unsafe/partial definition, native evaluation, axiom, or concrete queen-count result.

The source author has not compiled this file or run a checker. Independent review and the parent's fresh bounded mathematical gate must determine whether the proof scripts elaborate and which axioms the nine roots actually use. The inventory records prepared source, not a successful theorem check. No upstream checker, installed project module, or earlier evidence file is modified.

## Mathematical interface

Namespace: `ADWH.Experiments.Chapter15.FiniteFold`.

`Spec State Cursor Choice` has eight fields:

| Field | Meaning |
| --- | --- |
| `terminal : State → Bool` | Whether a state returns immediately. |
| `terminalValue : State → Nat` | The value returned by a terminal state. |
| `start : State → Cursor` | The initial cursor for a nonterminal state's choices. |
| `empty : Cursor → Bool` | Whether the inner loop has no further contribution. |
| `head : Cursor → Choice` | The next choice when the cursor is nonempty. |
| `rest : Cursor → Cursor` | The next cursor. |
| `next : State → Choice → State` | The child state for a choice. |
| `budget : State → Nat` | Maximum number of inner-loop iterations at that state. |

All three types have arbitrary universes. There is no built-in bit width, board size, order, equality test, hash, bound, reachability predicate, or expected answer. A client can instantiate the cursor with natural masks, bounded words of any width, a list, or another suitable type.

The canonical functions are:

```text
loop spec f state 0 cursor = 0
loop spec f state (fuel+1) cursor =
  if spec.empty cursor then 0 else
    f (spec.next state (spec.head cursor)) +
      loop spec f state fuel (spec.rest cursor)

fold spec 0 state =
  if spec.terminal state then spec.terminalValue state else 0
fold spec (depth+1) state =
  if spec.terminal state then spec.terminalValue state else
    loop spec (fold spec depth) state
      (spec.budget state) (spec.start state).
```

`loop` recurses only on its explicit fuel, and `fold` only on depth. Empty cursors stop without reading `head`, `rest`, or a child result. Terminal states return at every depth, including zero. At depth zero, a nonterminal state returns zero. Loop fuel zero returns zero even if the cursor is nonempty. Repeated occurrences of the same child state each contribute to the sum; the interface does not drop multiplicity.

These are finite semantics. The module does not assert that a chosen budget exhausts all possible choices, or that a chosen depth is sufficient for a different unbounded specification. Such a completeness argument belongs to the client. This distinction prevents an insufficient fuel choice from being mistaken for a complete search proof.

## Candidate implementations and uniqueness

`Equations spec F B` is a proposition about:

```text
F : Nat → State → Nat
B : Nat → State → Nat → Cursor → Nat.
```

Its four fields are exactly the outer zero/successor and inner zero/successor equations. The inner function at depth `d` calls `F d`; the outer successor at depth `d+1` calls that inner function. This is the crucial decreasing-depth relationship.

The theorem chain is:

1. Four named zero/successor equations expose the canonical functions.
2. `canonical_equations` supplies the contract for the canonical fold and loop.
3. `loop_unique_of_equations` assumes the candidate outer values equal the canonical values at one depth. Induction on the inner fuel then proves its loop equal at that depth.
4. `fold_unique_of_equations` uses depth induction and the preceding loop theorem to prove `F depth state = fold spec depth state` for all inputs.
5. `branches_unique_of_equations` removes the temporary outer-equality premise from the loop theorem by using the completed fold theorem.
6. `implementations_agree` composes the two uniqueness conclusions pointwise for any two candidates satisfying the same specification.

The proof uses equality congruence, transitivity, reflexivity, and structural induction. It does not need function extensionality: the public equality statements are pointwise. The source prints all nine theorem roots, including the four equation lemmas. Their exact statements and order appear in `SOURCE-INVENTORY.json`.

## Exact mapping to the existing natural-mask counter

The following is a design mapping, not an adapter theorem already added to ADWH. For a fixed natural mask `m`, instantiate:

| FiniteFold component | Existing `NatCounting` component |
| --- | --- |
| `State` | `Nat × Nat × Nat` (`Masks`) |
| `Cursor`, `Choice` | `Nat`, `Nat` |
| `terminal s` | `decide (s.2.1 = m)` |
| `terminalValue s` | `1` |
| `start s` | `available m s` |
| `empty v` | `decide (v = 0)` |
| `head v` | `low v` |
| `rest v` | `v - low v` |
| `next s b` | Existing `NatCounting.next s b` |
| `budget s` | `16` |
| Candidate outer `F d s` | `NatCounting.count m d s` |
| Candidate inner `B d s k v` | `NatCounting.sumBits (fun b => NatCounting.count m d (NatCounting.next s b)) k v` |

The callback in `loop` is applied after `next`; therefore this instantiation matches the existing captured callback in `sumBits`, rather than replacing it by an unrelated sum. The four candidate equations follow by unfolding the two existing definitions and simplifying the two `decide`-Boolean guards. `fold_unique_of_equations` then supplies the adapter. A separate small proof can expose the loop equality for an arbitrary continuation `f` if an executor needs that interface.

Preserve these source details:

- `low v = v &&& ((65536 - v) % 65536)`.
- The left component of `next` is reduced modulo 65536 after its shift.
- `available` uses natural subtraction from 65535.
- Both the root depth and the source bit-loop budget are 16.
- The original `count_refines` theorem is over all Word16 states and all depths; it must not be weakened silently to a reachable-state assumption.

The eventual source result still uses `NatCounting.cqueensNat_eq` to reach the original `BitRepresentation.cqueens`. Its unconditional executor equality is distinct from board correctness, whose source bridge assumes `n ≤ 16`. A new arbitrary-width board counter would need its own compatibility and completeness theorems. Nothing in this helper assumes the requested n16 numeral or derives widths from it.

## Use in a compiled-program checking path

A compiled safe-Lean evaluator satisfying `Equations` can use the uniqueness theorem as its functional contract. A checked-word implementation instead first needs a successful-result refinement to this Nat-valued semantics, with overflow/fallback accounted for. The helper does not supply either implementation automatically.

For a con-leche program hook, checked source recurrence certificates would establish the same equations for the interpreted source function. Uniqueness is then the mathematical step that identifies its values with the safe-Lean compiled function. The installer must still verify exact types/definitions/dependencies and check those certificates with the new fast path unavailable. The model's program-denotation invariant, its preservation, actual reducer case and complete cached/driver composition remain to be implemented and proved.

Likewise, compiled evaluation of this helper in an ordinary diagnostic produces a number, not a proof of the number. A custom validating replay and a stock Lean `.olean`/project build remain distinct results. This module neither modifies a kernel nor creates a route around validation. Its new theorem roots should be accepted by an ordinary fresh Lean gate before any larger integration claim is made.

## Proposed bounded gate

The parent should review the exact source and inventory, then freshly check this single module under Lean 4.35.0, default heartbeat/recursion settings, one CPU/thread, `-j1 -M1024`, the existing cumulative 30-second/1,048,576-KiB limits, strict warnings, and only the permitted three axioms. There are no experimental compiled imports to prepare or copy: the only import is the pinned distribution's `Init`.

Require nine actual named axiom reports, a zero compiler exit, the exact two fresh object files, frozen source/control snapshots, and the usual source/runtime/report bindings. Any development correction must preserve its failed source/logs and use a changed source fingerprint; no successful source result or new count is claimed in this proposal.
