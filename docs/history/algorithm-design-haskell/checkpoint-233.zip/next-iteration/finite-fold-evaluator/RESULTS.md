# FiniteFold: accepted ordinary-kernel result

The first `complete-01` attempt **passed all nine required theorem roots** under
the pinned Lean 4.35.0 ordinary kernel. All nine actually printed **empty axiom
lists**. The fresh one-module gate took **0.6231295749967103 seconds** cumulatively
and recorded **494,960 KiB** peak RSS. No limit event, diagnostic, retry or source
correction occurred.

The immutable [raw report](gate/attempts/complete-01/report.json) is 16,875 bytes,
SHA256 `b745a08c872b5d1afbf7773f013348592d348862d77d1a08161d109fadb2baab`.
The [raw stdout](gate/attempts/complete-01/FiniteFold.stdout.log) contains exactly
the nine ordered reports; stderr is empty. Required, observed, unique observed
and accepted counts are all **9**. The compiler itself took
0.4137375880018226 seconds of wall time and 0.395464 CPU seconds; the cumulative
gate also includes its execution-period checks.

## Mathematical result and scope

`FiniteFold` imports only `Init` and defines a total finite fold over arbitrary
state, cursor and choice types. The finite outer depth and inner cursor fuel are
explicit. The accepted contract covers terminal and zero-fuel cases and retains
branch multiplicity. It establishes the canonical equations and proves that
implementations satisfying the same four universal equations agree pointwise.

The exact accepted roots, all in
`ADWH.Experiments.Chapter15.FiniteFold`, are:

| Root | Role | Reported axioms |
|---|---|---|
| `loop_zero` | Inner zero-fuel equation | none |
| `loop_succ` | Inner successor equation | none |
| `fold_zero` | Outer zero-depth equation | none |
| `fold_succ` | Outer successor equation | none |
| `canonical_equations` | Canonical implementation satisfies the contract | none |
| `loop_unique_of_equations` | Inner uniqueness under the depth hypothesis | none |
| `fold_unique_of_equations` | Outer pointwise uniqueness | none |
| `branches_unique_of_equations` | Branch implementation agrees with the canonical loop | none |
| `implementations_agree` | Two implementations satisfying the contract agree | none |

The equations are explicit universal premises for a candidate implementation.
This gate does not establish those premises for a compiled native program,
implement a NatCounting adapter or kernel hook, prove coverage of an unbounded
search, or accept any concrete queen count. The separate native n8/n10/n12
diagnostics are not premises of these theorems. See
[SOURCE-REVIEW.md](SOURCE-REVIEW.md) for the mathematical boundary and
[DESIGN.md](DESIGN.md) for the proposed integration.

## Independent saved-evidence audit

[RESULTS.json](RESULTS.json) and
[audit_saved_result.py](audit_saved_result.py) record the independent audit.
Only saved JSON/text parsing and hashing were performed; no runner, source
guard, Lean process, generator, test or counter was executed by the auditor.

The audit checked 36 report binding occurrences representing 35 distinct
path/size/hash identities, and 31 marker occurrences representing 30 distinct
identities. The duplicate is the explicitly repeated source-manifest role.
All source/control references, eight read-only snapshots, the compiler and five
shared runtime libraries, two fresh objects and both raw logs match. The
source-manifest, source review, author inventory and actual ordered root reports
agree. The permanent marker agrees with the full selected plan and source
fingerprint:

`82bc2585533fd8c956432fba443a699d29b6e00c5d9fb1aa2eea88d0a30c88bb`

There was one freshly compiled mathematical module, no prepared object pool and
no experimental import reuse. The selected compiler used `-j1 -M1024`, strict
warnings, synchronous elaboration and default heartbeat/recursion settings.
The shared 30-second, one-CPU and one-GiB RSS constraints were satisfied. The
eight historical/contextual references establish enforcement/runtime and design
provenance; the original ADWH files were not imported or executed here.

The source and gate author was `validity_contracts`; the independent source,
gate and saved-result reviewer was `regression_audit`; `root` alone dispatched
the compiler. The separate [GATE-REVIEW.md](GATE-REVIEW.md) predates this result.
All previously frozen inputs and raw execution evidence remain unchanged.

## Checkpoint recovery

[SNAPSHOT-RECOVERY.json](SNAPSHOT-RECOVERY.json) maps all **eight snapshots**, a
total of **78,288 bytes**, to eight unchanged canonical files. There are **zero
unique superseded inputs**. It lists the 17 candidate evidence paths and eight
historical/contextual references required for this result's source-only
recovery, including the immutable marker, report and two logs.

The two `.olean`/`.ilean` objects and external Lean distribution may be omitted
from the durability archive. Their original accepted hashes remain recorded;
the retained compiler pin supplies the distribution identity. After extraction,
the auditor's `--source-only` mode checks canonical snapshot mappings and saved
evidence without requiring those compiled/runtime files. This restores the
source and accepted evidence, not a bit-identical running environment. Any
future authorized materialization must preserve the historical `complete-01`
record and must not reset its one-use marker.

## Recovery-mode correction after checkpoint 198

The published checkpoint preserves the original auditor. Its `--source-only`
mode incorrectly required extracted snapshots and markers to retain read-only
filesystem permissions, although ordinary ZIP extraction can preserve their
exact bytes without preserving those modes. The current auditor skips only that
permission requirement in source-only mode and explicitly reports that mode
checking is not required. Every content hash, role, marker and report identity
check remains mandatory. Full/live auditing and the historical execution gates
retain their read-only requirements. No mathematical source, execution report,
marker, result JSON or accepted outcome changed. See the separately retained
[correction record](../source-only-recovery-permissions/README.md) and exact
pre-fix auditor copies.
