#!/usr/bin/env python3
"""Read-only audit of the immutable FiniteFold complete-01 evidence."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
REPORT = HERE / 'gate/attempts/complete-01/report.json'
REPORT_SHA = 'b745a08c872b5d1afbf7773f013348592d348862d77d1a08161d109fadb2baab'
RAW = ['loop_zero', 'loop_succ', 'fold_zero', 'fold_succ', 'canonical_equations',
       'loop_unique_of_equations', 'fold_unique_of_equations',
       'branches_unique_of_equations', 'implementations_agree']
ROOTS = ['ADWH.Experiments.Chapter15.FiniteFold.' + name for name in RAW]
ALLOWED = {'propext', 'Quot.sound', 'Classical.choice'}
CURRENT = ['runner', 'protocol', 'source_manifest', 'mathematical_design',
           'author_source_inventory', 'independent_source_review', 'independent_source_audit']
HISTORICAL = ['resource_helper', 'source_guard', 'toolchain_pin', 'pinned_runtime_reference_report',
              'mapping_natural_counter', 'mapping_word_counter', 'mapping_source_counter', 'integration_contract']


def require(ok, message):
    if not ok:
        raise ValueError(message)


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=strict_object)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def binding(path):
    return {'path': path.relative_to(WORK).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def census(value):
    rows = []
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            rows.append(value)
        for child in value.values():
            rows.extend(census(child))
    elif isinstance(value, list):
        for child in value:
            rows.extend(census(child))
    return rows


def audit(source_only=False):
    require(REPORT.is_file() and REPORT.stat().st_size == 16875 and sha(REPORT) == REPORT_SHA,
            'Different historical report')
    report = read(REPORT)
    require(report['format'] == 'adwh-finite-fold-fresh-proof-gate-v1' and report['status'] == 'passed'
            and report['attempt'] == 'complete-01' and report['stage'] == 'complete', 'Gate scope differs')
    source, = report['source_bindings']
    old_work = Path(source['path']).parents[3]

    def local(path):
        path = Path(path)
        return WORK / path.relative_to(old_work) if path.is_relative_to(old_work) else path

    def verify(row, readonly=False):
        path = local(row['path'])
        require(path.is_file() and not path.is_symlink() and path.stat().st_size == row['bytes']
                and sha(path) == row['sha256'], 'Binding differs: ' + str(path))
        if readonly and not source_only:
            require(path.stat().st_mode & 0o222 == 0, 'Writable saved evidence: ' + str(path))

    require(local(source['path']) == HERE / 'source/FiniteFold.lean' and source['module'] == 'FiniteFold'
            and source['imports'] == ['Init'] and report['module_order'] == ['FiniteFold']
            and report['root_module'] == 'FiniteFold', 'Selected source closure differs')
    verify(source)
    controls = report['controls']
    require([row['role'] for row in controls] == CURRENT + HISTORICAL, 'Control roles differ')
    roles = {row['role']: row for row in controls}
    for row in controls:
        verify(row)
        current = row['role'] in CURRENT
        require(row['snapshot_required'] is current
                and row['retained_historical_reference'] is (not current), 'Control retention role differs')
    require(report['current_control_snapshot_count'] == 7 and report['historical_reference_count'] == 8,
            'Control counts differ')
    mappings = []
    physical_snapshots = 0
    for row in [source, *[roles[role] for role in CURRENT]]:
        snap = row['snapshot']
        require(all(snap[k] == row[k] for k in ['bytes', 'sha256']), 'Snapshot identity differs')
        canonical = local(row['path']).relative_to(WORK).as_posix()
        expected_path = (HERE / 'gate/attempts/complete-01/source/FiniteFold.lean' if row is source else
                         HERE / 'gate/attempts/complete-01/inputs' / canonical)
        require(local(snap['path']) == expected_path, 'Snapshot path/role differs')
        if local(snap['path']).is_file():
            verify(snap, readonly=True)
            physical_snapshots += 1
        else:
            require(source_only, 'Missing live snapshot: ' + snap['path'])
        mappings.append({'snapshot': local(snap['path']).relative_to(WORK).as_posix(),
                         'canonical': canonical, 'bytes': row['bytes'], 'sha256': row['sha256'],
                         'role': row.get('role', 'mathematical_source')})
    verify(report['source_manifest'])
    require({k: report['source_manifest'][k] for k in ['path', 'bytes', 'sha256']} ==
            {k: roles['source_manifest'][k] for k in ['path', 'bytes', 'sha256']}, 'Manifest role differs')
    manifest = read(local(report['source_manifest']['path']))
    require(manifest['source'] == {k: source[k] for k in ['bytes', 'sha256']} |
            {'path': local(source['path']).relative_to(WORK).as_posix()}, 'Manifest source differs')
    require(manifest['required_prints'] == report['required_prints'] == {'FiniteFold': ROOTS}
            and manifest['raw_source_print_identifiers'] == report['raw_source_print_identifiers'] == {'FiniteFold': RAW}
            and manifest['module_order'] == ['FiniteFold'] and manifest['imports'] == ['Init']
            and manifest['prepared_objects'] == report['prepared_objects'] == [], 'Manifest scope differs')
    for row in manifest['review_controls'] + manifest['context_references']:
        p = WORK / row['path']
        require(p.is_file() and p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], 'Manifest reference differs')
    inventory = read(local(roles['author_source_inventory']['path']))
    source_review = read(local(roles['independent_source_audit']['path']))
    require(inventory['ordered_axiom_roots'] == source_review['fully_qualified_roots'] == ROOTS
            and inventory['theorems'] == source_review['exact_statement_inventory_independently_matched'],
            'Reviewed source/root statement identity differs')
    for row in source_review['inputs']:
        p = WORK / row['path']
        require(p.is_file() and p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], 'Source-review input differs')

    marker_row = report['execution_marker']
    verify(marker_row, readonly=True)
    marker = read(local(marker_row['path']))
    for key in ['format', 'attempt', 'stage', 'source_fingerprint', 'source_manifest', 'source_bindings',
                'controls', 'compiler', 'runtime_libraries']:
        require(marker[key] == report[key], 'Marker/report role differs: ' + key)
    fingerprint = hashlib.sha256(json.dumps({'stage': 'complete', 'sources':
        [{'module': 'FiniteFold', 'sha256': source['sha256']}]}, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    require(report['source_fingerprint'] == fingerprint
            and Path(marker_row['path']).name == 'complete-' + fingerprint + '.json', 'Source marker identity differs')
    pin = read(local(roles['toolchain_pin']['path']))
    require(report['compiler_release'] == pin['version'] == '4.35.0'
            and report['compiler_commit'] == pin['commit'] == 'eb6cafb7290e8bd5f2937522d8d804f58f02bafc'
            and all(report['compiler'][k] == pin['binaries']['lean'][k] for k in ['bytes', 'sha256']),
            'Compiler pin differs')
    reference = read(local(roles['pinned_runtime_reference_report']['path']))
    expected_runtime = {Path(r['path']).name: (r['bytes'], r['sha256'])
                        for r in reference['controls'] if r['path'].endswith('.so')}
    require(len(report['runtime_libraries']) == 5 and
            {Path(r['path']).name: (r['bytes'], r['sha256']) for r in report['runtime_libraries']} == expected_runtime,
            'Runtime provenance role differs')
    if not source_only:
        for row in [report['compiler'], *report['runtime_libraries'], *report['artifacts']]:
            verify(row)

    module, = report['modules']
    old_build = str(old_work / HERE.relative_to(WORK) / 'gate/attempts/complete-01/build')
    require(report['object_search_path'] == old_build and module['module'] == 'FiniteFold', 'Build/module scope differs')
    expected_command = [report['compiler']['path'], '-j1', '-M1024', '-DautoImplicit=false',
        '-DwarningAsError=true', '-DElab.async=false', '-o', old_build + '/FiniteFold.olean',
        '-i', old_build + '/FiniteFold.ilean', 'FiniteFold.lean']
    require(module['command'] == expected_command and module['exit_code'] == 0
            and module['status'] == 'passed' and module['within_limits'] is True
            and module['limit_exceeded'] is None and module['required_objects_present'] is True,
            'Compiler command/outcome differs')
    verify(module['stdout']); verify(module['stderr'])
    out, err = local(module['stdout']['path']).read_text(), local(module['stderr']['path']).read_text()
    pattern = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
    raw = [{'root': root, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
           for root, axes in pattern.findall(out)]
    require(not err and not pattern.sub('', out).strip() and [r['root'] for r in raw] == ROOTS
            and all(set(r['axioms']) <= ALLOWED for r in raw), 'Raw root/axiom/diagnostic audit failed')
    require(raw == module['axiom_audit']['raw_reports'] and module['axiom_audit']['passed'] is True
            and module['axiom_audit']['reports'] == {r['root']: r['axioms'] for r in raw}, 'Saved axiom parser differs')
    require(all(report[key] == len(raw) == 9 for key in ['required_axiom_report_count',
            'observed_axiom_report_count', 'observed_unique_axiom_root_count', 'accepted_axiom_report_count']),
            'Required/observed/accepted root counts differ')
    require({r['path'] for r in report['artifacts']} == {old_build + '/FiniteFold.olean', old_build + '/FiniteFold.ilean'}
            and len(report['artifacts']) == 2 and report['exact_build_artifact_inventory'] is True,
            'Fresh object inventory differs')
    constraints = report['constraints']
    require(constraints['cumulative_wall_seconds'] == 30 and constraints['resident_memory_kib'] == 1048576
            and constraints['lean_memory_mib'] == 1024 and constraints['compiler_threads'] == 1
            and constraints['default_heartbeats_and_recursion'] is True and len(constraints['cpu_affinity']) == 1
            and 0 <= report['seconds'] <= 30
            and report['peak_child_rss_kib'] == module['sampled_tree_and_wait4_peak_rss_kib'] <= 1048576,
            'Resource contract differs')
    for key in ['all_selected_mathematical_sources_freshly_checked', 'all_sources_snapshots_controls_runtime_unchanged',
                'complete_finite_fold_proof_checked']:
        require(report[key] is True, 'Incomplete accepted gate: ' + key)
    for key in ['compiled_experimental_imports_reused', 'original_ADWH_imports_used', 'source_count_proved',
                'n16_target_proved', 'native_evaluator_or_counter_executed', 'kernel_integration_implemented',
                'integrated_project_modified']:
        require(report[key] is False, 'Scope unexpectedly enlarged: ' + key)
    report_rows, marker_rows = census(report), census(marker)
    distinct = lambda rows: len({(r['path'], r['bytes'], r['sha256']) for r in rows})
    return {'format': 'adwh-finite-fold-saved-result-audit-v1', 'status': 'passed_saved_evidence_audit',
        'audit_mode': 'source_only' if source_only else 'live_bindings',
        'audit_execution': 'Saved JSON/text parsing and hashing only; no runner, guard, Lean, generator or counter invoked.',
        'authorship': {**report['authorship'], 'independent_gate_and_saved_result_reviewer': 'regression_audit'},
        'report': binding(REPORT), 'source_fingerprint': fingerprint,
        'report_binding_occurrences': len(report_rows), 'report_distinct_binding_identities': distinct(report_rows),
        'marker_binding_occurrences': len(marker_rows), 'marker_distinct_binding_identities': distinct(marker_rows),
        'filesystem_readonly_mode_required': not source_only,
        'filesystem_readonly_mode_checked': not source_only,
        'source_count': 1, 'imports': ['Init'], 'current_controls': 7, 'historical_references': 8,
        'snapshot_count': 8, 'snapshot_bytes': sum(r['bytes'] for r in mappings),
        'physical_snapshots_verified': physical_snapshots, 'snapshot_mappings': mappings,
        'unique_superseded_inputs': 0, 'runtime_file_count': 6, 'runtime_files_rehashed': not source_only,
        'artifacts': report['artifacts'], 'compiled_artifacts_rehashed': not source_only,
        'raw_logs_verified': 2, 'required_roots': 9, 'observed_roots': len(raw), 'accepted_roots': 9,
        'raw_axiom_reports': raw, 'all_axiom_lists_empty': all(not row['axioms'] for row in raw),
        'cumulative_seconds': report['seconds'], 'compiler_wall_seconds': module['seconds'],
        'compiler_cpu_seconds': module['cpu_seconds'], 'peak_rss_kib': report['peak_child_rss_kib'],
        'nat_counting_adapter_proved': False, 'native_execution_certified': False,
        'kernel_integration_implemented': False, 'numerical_queens_count_proved': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-only', action='store_true',
                        help='Use canonical files for omitted snapshots; skip external runtime and compiled artifacts.')
    args = parser.parse_args()
    print(json.dumps(audit(args.source_only), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
