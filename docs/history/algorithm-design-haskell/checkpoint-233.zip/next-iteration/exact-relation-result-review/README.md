# Fixed relation batch: saved-result audit

The single fixed producer and its independent replay both completed successfully.
All sixteen precommitted candidate relations were individually refuted. **This
does not establish global rank 35, exclude another linear combination, or prove
an identity or queens count in Lean.** The five accepted zero proofs concern
proper substates; no candidate root was proved zero.

This review checks saved bytes, commands, resource reports, transcript framing,
request/completion accounting, and result consistency. It does not run the
producer or replayer again, evaluate a guarded function, compute a cofactor,
perform RREF/nullspace arithmetic, or test another relation.

## Accepted pair

| Saved process | Result | Wall time | Peak RSS |
| --- | --- | ---: | ---: |
| `relations-01` producer | Completed fixed batch, exit 0 | 0.6859392069891328 s | 92,468 KiB |
| `relations-replay-01` independent replay | Passed, exit 0 | 1.4428135769994697 s | 98,712 KiB |

Both reports retain the same 30-second wall/CPU limits, one CPU, one thread,
1 GiB address-space limit, shared lock, and 50,000 charged-request cap. Sources
and inputs were snapshotted before execution and remained unchanged afterward.
The commands invoke the correct isolated Python snapshot and exact trace,
sample, and (for replay) producer certificate.

The producer transcript contains 11,366 starts and 11,366 completions, with
22,734 physical records including its header and footer. IDs are dense,
completions close the recorded nesting stack, dependencies name completed
requests, and no work remains pending. The operation counts, sixteen candidate
outcomes, cache counts, phase, pivots and maxima agree with the independent
replay report. The recorded maximum signed state has four terms; coefficient
magnitudes use at most two bits. These are observations of this run, not bounds
for a different basis algorithm.

`metadata-audit.json` records 91 exact byte-binding checks across 37 files.
The four principal files are also pinned to the identities announced when the
run completed:

| File | SHA-256 |
| --- | --- |
| Producer `run-report.json` | `7a550f8d34f5534394270e7fb63ac1f78c0b15fb2a68c605c7713a35932bf050` |
| Producer `work.jsonl` | `8a0eb474d0fd77c9637b44f57d9665475cd82f11c7cfd3cd647f1ddc8d1c98b9` |
| Replay `run-report.json` | `407c83397ad60361eb49c18c87cf794364a42b3f8568eed9d3a23ef8ac8924e1` |
| Replay `replay-report.json` | `5570f52bb43ec81405bcf686e749f2e5078ae1d1b052b8a4b7f71fd23c556bba` |

The pre-execution review remains separate in
`../exact-relation-executable-review/`. The result audit records what was
executed and saved; it does not turn the external replay into a kernel proof.

## Compact recovery recommendation

Retain one producer transcript, the two run reports, the independent replay
report, the small process logs, the current result summary, and the current
source/review files. The eight attempt-level result/log files total 3,947,464
bytes before compression. Retain the already selected canonical guarded trace
and sample report once. Do not add either attempt's `input/` or `source/`
snapshot tree, interpreter binary, or an older checkpoint ZIP.

`compact-retention.json` gives exact proposed additions, the canonical files
already present in checkpoint 176, and hash-bound aliases for the omitted
snapshot paths. Historical reports remain byte-for-byte unchanged. Their
snapshot claims were checked here while the snapshots existed; after compact
recovery the aliases permit checking the retained canonical bytes against the
same hashes without reconstructing duplicate trees.

`audit_saved_pair.py` is the original live-workspace metadata check and expects
those historical snapshot paths. It is retained as an audit method, not
advertised as a portable command for a compact restore. No historical runner
or report is rewritten to conceal that distinction.
