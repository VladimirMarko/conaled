#!/usr/bin/env python3
"""Audit saved bytes, process reports and transcript metadata; never redo semantics."""
from pathlib import Path
from collections import Counter
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'next-iteration/exact-relation-diagnostic'
OUT = Path(__file__).resolve().parent
EXPECTED = {
    'relations-01/run-report.json': (9201, '7a550f8d34f5534394270e7fb63ac1f78c0b15fb2a68c605c7713a35932bf050'),
    'relations-01/work.jsonl': (3918899, '8a0eb474d0fd77c9637b44f57d9665475cd82f11c7cfd3cd647f1ddc8d1c98b9'),
    'relations-replay-01/run-report.json': (10556, '407c83397ad60361eb49c18c87cf794364a42b3f8568eed9d3a23ef8ac8924e1'),
    'relations-replay-01/replay-report.json': (8305, '5570f52bb43ec81405bcf686e749f2e5078ae1d1b052b8a4b7f71fd23c556bba'),
}


def binding(path):
    path = Path(path)
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha}


def main():
    target = OUT / 'metadata-audit.json'
    assert not target.exists()
    checks, unique = [], {}

    def check(entry, origin):
        actual = binding(entry['path'])
        assert actual['bytes'] == entry['bytes'] and actual['sha256'] == entry['sha256'], origin
        checks.append({'origin': origin, **actual})
        unique[actual['path']] = actual

    for relative, (size, sha) in EXPECTED.items():
        check({'path': str(BASE / 'attempts' / relative), 'bytes': size, 'sha256': sha},
              'announced completed pair')

    prior = json.loads((ROOT / 'next-iteration/exact-relation-executable-review/review.json').read_text())
    for row in prior['bindings']:
        check({**row, 'path': str(ROOT / row['path'])}, 'pre-execution review')
    reports = []
    for attempt, mode in [('relations-01', 'producer'), ('relations-replay-01', 'replay')]:
        directory = BASE / 'attempts' / attempt
        report_path = directory / 'run-report.json'
        report = json.loads(report_path.read_text())
        check(binding(report_path), mode + ' run report')
        assert report['status'] == 'passed' and report['exit_code'] == 0
        for name in ['child_process_started', 'semantic_execution_attempted', 'executed_snapshots',
                     'input_bindings_complete', 'input_hashes_unchanged',
                     'source_bindings_complete', 'source_hashes_unchanged', 'deadline_checked_after_exit']:
            assert report[name] is True, name
        for name in ['formal_evidence', 'source_count_computed', 'killed_for_deadline']:
            assert report[name] is False, name
        constraints = report['constraints']
        for name, value in {'wall_seconds':30, 'cpu_seconds':30, 'threads':1,
                            'address_space_bytes':1073741824, 'charged_semantic_requests_cap':50000,
                            'board_size':8, 'fixed_candidate_matrix':[19,35],
                            'lock_mode':'exclusive_nonblocking'}.items():
            assert constraints[name] == value, name
        assert constraints['shared_lock'] == str(ROOT / 'project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock')
        assert len(constraints['cpu_affinity']) == 1 and type(constraints['cpu_affinity'][0]) is int
        assert 0 <= report['seconds'] <= 30 and 0 <= report['peak_rss_kib'] <= 1048576
        assert 0 <= report['user_seconds'] + report['system_seconds'] <= 30
        assert len(report['sources']) == 6 and len(report['inputs']) == (2 if mode == 'producer' else 3)
        for group in ['sources', 'inputs']:
            for row in report[group]:
                check(row, mode + ' original ' + group)
                assert row['sha256'] == row['snapshot_sha256']
                check({'path':row['snapshot'], 'bytes':row['bytes'], 'sha256':row['snapshot_sha256']},
                      mode + ' snapshot ' + group)
        for row in report['artifacts']:
            check(row, mode + ' recorded artifact')
        check(report['python_executable'], mode + ' interpreter metadata')
        command = report['command']
        assert Path(command[0]).resolve() == Path(report['python_executable']['path'])
        script = 'diagnostics/produce_relations.py' if mode == 'producer' else 'replay/replay_relations.py'
        expected = ['-I', str(directory/'source'/script), '--trace', str(directory/'input/trace.jsonl'),
                    '--sample', str(directory/'input/sample.json')]
        if mode == 'replay':
            expected += ['--certificate', str(directory/'input/certificate.jsonl')]
        expected += ['--output', str(directory/('work.jsonl' if mode == 'producer' else 'replay-report.json'))]
        assert command[1:] == expected
        assert report['charged_semantic_requests'] == report['completed_requests'] == 11366
        assert report['physical_records'] == 22734 and report['pending_requests'] == []
        assert report.get('diagnostic_status', report.get('producer_status')) == 'completed_fixed_batch'
        reports.append(report)

    replay_path = BASE/'attempts/relations-replay-01/replay-report.json'
    replay = json.loads(replay_path.read_text())
    check(binding(replay_path), 'independent replay result')
    for group in ['input_bindings', 'policy_bindings']:
        for row in replay[group].values():
            check(row, 'replay result ' + group)
    check(replay['replayer'], 'executed replayer')
    assert replay['status'] == 'passed' and replay['producer_status'] == 'completed_fixed_batch'
    assert replay['completed_candidate_proposals'] == 16
    assert replay['pending_requests'] == []

    work = BASE/'attempts/relations-01/work.jsonl'
    operations = Counter({k:0 for k in replay['operation_counts']})
    stack, starts, done, outcomes = [], {}, set(), []
    header = footer = None
    records = new_zero = 0
    for line in work.open():
        row = json.loads(line);records += 1
        kind = row['kind']
        if kind == 'header':
            assert records == 1 and header is None;header = row
        elif kind == 'work':
            assert footer is None and row['id'] == len(starts)
            assert row['operation'] in operations
            starts[row['id']] = row['operation'];operations[row['operation']] += 1;stack.append(row['id'])
        elif kind == 'done':
            assert footer is None and stack and row['id'] == stack.pop()
            assert row['finish'] == len(done) and row['id'] not in done
            assert all(type(x) is int and x in done for x in row['dependencies'])
            done.add(row['id'])
            if starts[row['id']] == 'candidate_outcome':outcomes.append(row['output'])
            if starts[row['id']] == 'state' and row['output']['proof_new'] is True:new_zero += 1
        elif kind == 'footer':
            assert footer is None;footer = row
        else:raise AssertionError(kind)
    assert header is not None and footer is not None and not stack
    assert records == 22734 and len(starts) == len(done) == 11366
    assert dict(operations) == footer['operation_counts'] == replay['operation_counts']
    assert sum(operations.values()) == 11366
    assert footer['status'] == 'completed_fixed_batch' and footer['error'] is None
    assert footer['charged_starts'] == footer['completed_requests'] == 11366
    assert footer['pending_stack'] == [] and footer['physical_records'] == records
    assert outcomes == footer['candidate_outcomes'] == replay['candidate_outcomes']
    assert len(outcomes) == 16 and len({x['free_column'] for x in outcomes}) == 16
    assert all(x['outcome'] == 'refuted' and x['proof_id'] is None and
               type(x['nonzero_value']) is int and x['nonzero_value'] != 0 for x in outcomes)
    for key in ['cache_counts', 'phase', 'rref_pivots', 'maxima']:
        assert footer[key] == replay[key]
    assert new_zero == replay['new_zero_proofs'] == 5
    assert replay['validated_original_nodes'] == 1253
    assert replay['maxima']['state_terms'] == 4 and replay['maxima']['state_coefficient_bits'] == 2
    assert header['limits'] == {'charged_request_cap':50000,'wall_seconds':30,'cpu_seconds':30,
                                'cpu_count':1,'address_space_bytes':1073741824}
    for group in ['input_bindings','policy_bindings']:
        for row in header[group].values():check(row, 'producer header '+group)
    result = {
        'kind':'saved_exact_relation_pair_metadata_audit', 'status':'passed',
        'scope':'Byte bindings, process outcomes, request/completion/dependency metadata and recorded result consistency only. No scalar arithmetic, RREF, source semantics, function evaluation, restriction, candidate identity or rank recomputed.',
        'binding_checks':len(checks), 'distinct_bound_files':len(unique),
        'checks':checks,
        'producer':{k:reports[0][k] for k in ['status','exit_code','seconds','peak_rss_kib']},
        'replay':{k:reports[1][k] for k in ['status','exit_code','seconds','peak_rss_kib']},
        'result':{'completed_candidate_proposals':16,'proved_global_identities':0,'refuted_candidates':16,
                  'charged_starts':11366,'completed_requests':11366,'physical_records':22734,'pending_requests':0,
                  'zero_substate_proofs':5,'validated_original_nodes':1253,'maxima':replay['maxima']},
        'operation_counts':dict(operations),
        'interpretation':'All16 fixed candidates were individually refuted. This neither proves global rank35 nor excludes a true linear combination. Zero substate proofs are not candidate identities. No Lean identity, source count, or n16 theorem is established.'
    }
    target.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2,sort_keys=True))


if __name__ == '__main__':
    main()
