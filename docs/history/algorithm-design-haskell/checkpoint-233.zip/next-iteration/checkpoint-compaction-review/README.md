# Checkpoint175 compaction audit

**The checkpoint grew because it accumulated diagnostic output and historical copies, not because the finished proofs require a 400 MB recovery image.** A new checkpoint should contain current working sources, complete accepted proof inputs, one relevant verification record per result, and the current continuation. Older archives can remain the historical record without being carried forward into every new archive.

This audit changed no existing artifact, created no archive, and executed no mathematical calculation. It read the ZIP directory, checked the embedded manifest against the staged manifest, rehashed all 12,403 listed stage payloads, and rehashed the archive itself. ZIP member names and lengths match that manifest; the previous strict archive-integrity check remains separate. Exact results are in `composition.json`; the reproducible byte-only audit is `analyze_checkpoint175.py`.

## What takes the space

Checkpoint175 is **400,288,864 bytes (381.75 MiB)**, with 12,404 members and 2,116,115,802 uncompressed bytes. Its SHA256 is `ddb3f88259eeaedfcca567651cd5978117fc01706c14a15f07f61d6329f2ee63`.

| Content | Compressed payload bytes | Observation |
| --- | ---: | --- |
| Three identical large n6 certificate JSON files | 113,666,901 | Each contains the same 173,786,113 raw bytes |
| Two abandoned partial certificate writes | 74,576,085 | Neither is a completed proof input |
| Thirty-seven copies of `ChunkedSixLookup.lean` | 34,302,108 | One accepted copy is sufficient |
| Nine copies of the original guarded trace | 24,819,606 | One canonical copy supports current work |
| Bundled upstream packages and archives | 29,615,498 | Most belong to retired experiments |

There are **657 exact duplicate groups**, containing **6,068 redundant occurrences**. Keeping one copy per group would remove 194,961,733 compressed payload bytes under the existing independent ZIP compression. That figure is descriptive, not the proposed solution: deduplicating an accumulated history would still retain obsolete large results and failed variants.

Attempt input snapshots occupy 94.65 MB compressed; development trees occupy 38.86 MB. These classifications overlap the duplicate groups and must not be added to them. All measurements use the current ZIP's member sizes; no new compression was performed.

## The finished size-six proof is small and complete

The accepted size-six source closure is three ordinary Lean files: `ConsolidatedGeneric.lean`, `ConsolidatedArithmetic.lean`, and `ConsolidatedSource.lean`. Together they contain **4,042,014 raw bytes**, or **1,003,455 bytes** of existing compressed payload. The descriptor tables, routing controls, arithmetic checks, elimination plan, site data and source correspondence are already present in those literal definitions and proofs. No external JSON is read during their Lean checking.

The ten imported original ADWH modules occupy 108,613 source bytes and are already in the main repository. Their transitive imports include `QueensExamples`, but the accepted actual-dependency audit excludes prior concrete answers from the final theorem's proof dependencies. Retaining that audit and its exact target/denylist matters; retaining every old attempt does not.

The giant JSON is diagnostic generator output containing full packets and intermediate routing planes. Its small frozen producer and router can construct it from the fixed 2,515,033-byte n6 trace. No regeneration was run during this audit, so a new byte-identical regeneration is not claimed. For verifying the existing theorem, the complete generated Lean files are sufficient.

For maintainability, keep the 58 modular original sources as well. Their extra existing compressed payload is only 1,026,262 bytes. The unchanged consolidator additionally reads its small source plan and 58 accepted development reports; these can be retained without their source/build snapshot trees. This is a direct dependency of that convenience tool, not a mathematical need for all development history.

## Recommended recovery set

`proof-recovery-selection.json` gives exact paths, sizes and SHA256 bindings for the completed n4/n6/n8 sources and their selected successful evidence. Its full selection, including modular sources, consolidators and their direct metadata inputs, consumes only **2,946,448 bytes of existing compressed payload**.

Retain the full current original proof repository and correspondence, current verification/coverage/control records, compiler/dependency pins, and the licensed ADWH and Garsia–Wachs source references. Keeping the entire existing `adwh-lean` tree would cost 14.48 MB compressed; the two licensed source groups add 1.17 MB. Broad retention of small current source files is preferable to a fragile minimal dependency list.

For ongoing work, keep the current generic laws and certificate generators, the latest independent producer/replayer sources and fixed schemas, and concise outcome notes. The exact-relation experiment needs one original guarded trace, the saved 19×35 sample/B-view report, and its current unexecuted source/protocol/runner. One cut-work transcript is useful evidence; repeated input copies are unnecessary. The continuation must say that Chapter15 and `cqueens 16 = 14772512` remain open, and distinguish the accepted n4/n6/n8 Lean results from capped external diagnostics and sampled-rank observations.

Omit new copies of rejected generated variants, profiling output, redundant snapshots, incomplete writes, obsolete solver packages, ancestor manifests and old living-record versions. Preserve their meaningful results in a compact ledger and leave the existing historical archives untouched. Use a plain unpackable tree, not a mechanism that reconstructs the old archive's full history.

## Portable verification boundary

The historical n6 runner reads old baseline/import-pool reports and absolute workspace paths. Keep its accepted bytes as evidence, but do not silently call it portable after removing that historical layout. A new portable wrapper can bind the retained canonical three sources and original import closure directly, bootstrap original imports separately with pinned Lean, and then preserve the same cumulative 30-second, one-CPU, `-j1 -M1024` fresh experimental gate and separate dependency audit. Bootstrap time was excluded from the historical 27.33-second measurement and must remain explicit.

The new compact verifier should check the current payload manifest, selected accepted source/control bindings and necessary imports. It need not assert preservation of every file from every earlier checkpoint. Packaging/hash/import checks are recovery-integrity checks, not a new Lean run or a new mathematical claim.
