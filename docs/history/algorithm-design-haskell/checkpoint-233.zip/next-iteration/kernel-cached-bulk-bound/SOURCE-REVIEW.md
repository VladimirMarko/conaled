# Independent review of the exact bulk-cutoff supplement

Reviewer: `nat_only_gap_review`. Source author: `reflection_evidence_review`.
Status: **passed bounded source-only review; no compilation or budget
acceptance**.

## Scope and exact selection

All thirty public report roots, both private proof helpers, the new pure
bound specification and memo predicate, and all four bridge corollaries were
read. The six recorded upstream proof intervals and their explicit
adaptations were compared with the selected source. The review also read
the actual `Expr.data` field recurrence, the existing memoized bound walk
and accessor, and the exact Syntax/Helper interfaces used by the corollaries.

The selected leaf is the corrected 16,982-byte source, SHA-256
`04865ccfafe75dbef54266687a0357cc41f46eec34f3c266346f300b8d2ca666`.
The original 16,844-byte draft had two slice boundaries inside doc comments,
leaving bare trailing comment text. This reviewer identified both before
execution. The separate boundary-correction record preserves that draft and
restores the two exact upstream comment-opening lines. Removing only those
lines recovers the original draft. No theorem, proof or executable token
changed in this correction.

The author inventory's 116 input identities remain exact. The later
independent Observer/Syntax review is bound separately as additional context;
the inventory's recorded pending status was its status at freeze time and
is not silently rewritten. This review covers the new bound supplement and
its specified interfaces. It does not re-review every unrelated declaration
in the inherited Core/Cached/Stable/Helper sources or rebase their earlier
review scopes.

## Packed-word and constructor facts

The packed loose-bvar extraction law retains both necessary 15-bit range
premises: the bvar field and its adjacent fvar field are below 32768. The
arbitrary hash occupies multiples of `2^32`, so its modular high-word
contribution does not affect the extracted low field. The low Boolean flag
is covered by both cases. No fvar-range exactness or semantic environment
assumption is substituted for those concrete bounds.

The source preserves the actual saturation value 32767. `satSucc` stores
the minimum of the successor and that value; `satPred` preserves the
saturation marker and otherwise performs the ordinary truncated predecessor.
The UInt64-to-Nat maximum and subtraction lemmas supply the same equations
used by the actual packed data recurrence.

Every raw constructor equation matches `Expr.data`: leaves, applications,
both binder forms, lets and projections. Fvars have loose-bvar bound zero,
consistent with the pure bulk substitution's treatment of a free-variable
node. Binder bodies reduce their unsaturated bound by one while preserving
the saturation marker. Application/let component maxima and the adjacent
fvar bounds remain explicit. The modified maximum-bound proof uses
`Nat.max_lt.mpr` directly; it does not weaken either component bound.

## Exact unsaturated bound and saturated fallback

The newly restored `bvarBound` is the original pure recursive specification,
not a replacement for the executed accessor. Its equivalence with
`looseBVarsBounded` follows the matching constructor recurrence, including
the binder-depth increment and truncated predecessor.

`bvarBRaw_exact` asserts exactness only below the saturation marker. The
bvar case explicitly splits the minimum. In the other branch, the premise
would make the saturation value strictly less than itself, so that branch
is impossible. Application bounds are obtained by `Nat.max_lt.mp`.

For each binder and let case, a saturated body would force the corresponding
maximum component to equal the saturation value, contradicting its strict
bound. The proof explicitly excludes that branch, combines the retained raw
range `< 32768` with inequality from 32767 to obtain `< 32767`, and applies
the induction hypothesis. The proof therefore does not incorrectly subtract
one from an unknown saturated bound. All original theorem headers and the
exact saturation threshold are preserved.

The actual `bvarBoundGo` definition first returns a memo hit unchanged and,
on a miss, recursively traverses the same children before inserting its
result under the original expression key. `MemoBInv` states that each hit is
the pure bound of that exact key. Its empty-map proof eliminates the actual
impossible lookup; insertion uses lawful expression equality and retains
every other key.

The traversal proof establishes both the returned bound and preservation
of the returned map. In each recursive case, the next child receives the
map returned by the preceding child. Projections retain the outer insertion
after the subterm call. No arbitrary clean memo, fresh traversal state or
assumed traversal result replaces the actual state flow.

`bvarBoundMemo_eq` instantiates the traversal theorem at the actual empty
initial memo. `bvarB_eq` follows both branches of the existing accessor: an
unsaturated packed read uses raw exactness; the saturation marker uses the
actual memoized fallback equality. This handles all expression sizes and
indices, with no small-index or Nat-only restriction.

## Four public corollaries

`bulk_cutoff_sound` rewrites the actual accessor inequality using `bvarB_eq`
and the pure loose-variable equivalence. It proves exactly the earlier
Syntax module's `BulkCutoffSound` premise, rather than assuming the desired
bulk operation equality.

The plain bulk and actual cached-syntax equalities instantiate the existing
Syntax induction with that proved cutoff. The induction's result still
uses the complete live replacement prefix and its recursive replacement
semantics; no closed-replacement assumption is introduced. The actual
wrapper remains `Expr.instantiateListC`, and the target remains the original
pure `Expr.instantiateList`.

`instListM_pure_result` reuses the actual supplied-state helper theorem and
changes only the stated returned expression through that equality. It
retains `HelperCache fe state`, the helper invariant on the returned state,
and the two normal-form-map frame equations. It does not infer execution
from a simulation theorem, introduce a seeded helper cache, or establish
the invariant for an arbitrary record trace.

## Ownership, review and execution boundary

The leaf imports only the selected Syntax owner. Its added `bvarBound` and
`MemoBInv` names supplement existing Expr/ExprOps ownership; the actual
`bvarBoundGo`, `bvarBoundMemo` and `bvarB` operations are already present and
are not redeclared. The current Core observer-law restoration and Syntax
repair are separate reviewed source variants. The original Core and earlier
Syntax sources remain retained context, not duplicate selected owners.

The prospective inventory names six physical modules, 32 ownership origins,
112 distinct reports and twelve ordinary artifacts. These counts are source
selection metadata, not accepted theorem or runtime evidence. A later
combined selection using another proof-sharing owner must bind its exact
source and independent overlay review explicitly; this review is not
automatically rebased onto that changed physical file.

No axiom, proof placeholder, unsafe declaration, resource override or
alternative evaluator is introduced. The fixed 30-second complete-gate
policy remains unchanged. The earlier successful helper gate does not
predict that the larger complete closure will fit; no timing or memory
acceptance is inferred here.

Actual recursive cached reduction, body/head induction, initialization and
intervening record actions, visible-prefix lookup agreement, annotation and
installation validity, prefix `EnvWF`, `GroupChecked`, and the stock numeral
theorem remain separate obligations. No queen count or mathematical program
was evaluated. This reviewer ran no compiler, preflight, gate, exporter,
profiler, retained generator, or saved-evidence reader.
