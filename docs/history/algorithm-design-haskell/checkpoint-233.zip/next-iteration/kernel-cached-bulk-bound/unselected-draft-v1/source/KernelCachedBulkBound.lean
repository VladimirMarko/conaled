import KernelCachedSyntaxCorrespondence

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Exact loose-bound cutoff and unconditional bulk correspondence

Uncompiled source candidate. The packed-word and saturation-fallback proof
slice below targets the actual bvarB, bvarBoundGo and bvarBoundMemo definitions
already owned by the selected Core/Cached modules. This source does not
replace those operations. Its new pure specification bvarBound and memo
invariant support correctness proofs, not a new execution path.

Only the loose-bound cutoff is discharged here. Actual cached recursive
reduction, body/head induction, record initialization, installation and
GroupChecked remain separate obligations. SOURCE-CORRESPONDENCE.json records
the exact upstream slices and the explicit proof-only adaptations.
-/

namespace ConLeche

/- BEGIN proof slice packed_word_bound_facts -/
theorem bvarOfData_lt (w : UInt64) : (bvarOfData w).toNat < 32768 := by
  simp [bvarOfData, UInt64.toNat_mod]; omega

theorem fvarOfData_lt (w : UInt64) : (fvarOfData w).toNat < 32768 := by
  simp [fvarOfData, UInt64.toNat_mod]; omega

theorem satSucc_lt (n : Nat) : (satSucc n).toNat < 32768 := by
  simp [satSucc, satRange]; omega

/-- `UInt64.max` transports to `Nat.max` through `toNat`. -/
theorem toNat_max (a b : UInt64) : (max a b).toNat = max a.toNat b.toNat := by
  simp only [Max.max]
  split <;> rename_i h <;> simp_all [UInt64.le_iff_toNat_le] <;> omega

/-- Predecessor on a `UInt64` known to be nonzero. -/
theorem toNat_sub_one {x : UInt64} (h : x.toNat ≠ 0) :
    (x - 1).toNat = x.toNat - 1 := by
  have hs := UInt64.toNat_lt_size x
  simp only [UInt64.size] at hs
  simp only [UInt64.toNat_sub, UInt64.toNat_one]
  omega

theorem satPred_lt {x : UInt64} (hx : x.toNat < 32768) :
    (satPred x).toNat < 32768 := by
  unfold satPred
  split
  · decide
  · split
    · decide
    · rename_i h₁ h₂
      have hne : x.toNat ≠ 0 := by
        simpa [← UInt64.toNat_inj] using h₂
      rw [toNat_sub_one hne]
      omega

theorem max_lt_32768 {a b : UInt64} (ha : a.toNat < 32768)
    (hb : b.toNat < 32768) : (max a b).toNat < 32768 := by
  rw [toNat_max]
  exact Nat.max_lt.mpr ⟨ha, hb⟩

theorem bvarOfData_pack (h b f : UInt64) (lp : Bool)
    (hb : b.toNat < 32768) (hf : f.toNat < 32768) :
    bvarOfData (packData h b f lp) = b := by
  apply UInt64.toNat_inj.mp
  cases lp <;>
  · simp [bvarOfData, packData, UInt64.toNat_add, UInt64.toNat_mul,
      UInt64.toNat_div, UInt64.toNat_mod]
    omega
/- END proof slice packed_word_bound_facts -/

namespace Expr

/- BEGIN proof slice raw_bound_range -/
theorem bvarBRaw_lt (e : Expr) : e.bvarBRaw < 32768 := bvarOfData_lt _
/- END proof slice raw_bound_range -/

/- BEGIN proof slice nat_saturation_transport -/
private theorem toNat_satSucc (n : Nat) :
    (satSucc n).toNat = min (n + 1) satRange := by
  simp [satSucc, satRange]
  omega

private theorem toNat_satPred {x : UInt64} (_hx : x.toNat < 32768) :
    (satPred x).toNat = if x.toNat = satRange then satRange else x.toNat - 1 := by
  by_cases hs : x.toNat = satRange
  · have : x = 32767 := by rw [← UInt64.toNat_inj]; simpa [satRange] using hs
    simp [satPred, this, satRange]
  · have hne : x ≠ 32767 := by
      rw [Ne, ← UInt64.toNat_inj]; simpa [satRange] using hs
    by_cases hz : x.toNat = 0
    · have : x = 0 := by rw [← UInt64.toNat_inj]; simpa using hz
      simp [satPred, this, satRange]
    · have hz' : x ≠ 0 := by rw [Ne, ← UInt64.toNat_inj]; simpa using hz
      simp only [satPred, beq_iff_eq, hne, hz', ↓reduceIte, hs,
        toNat_sub_one hz]
/- END proof slice nat_saturation_transport -/

/- BEGIN proof slice raw_bound_constructor_equations -/
@[simp] theorem bvarBRaw_bvar (i : Nat) :
    (Expr.bvar i).bvarBRaw = min (i + 1) satRange := by
  show (bvarOfData (packData _ (satSucc i) 0 false)).toNat = _
  rw [bvarOfData_pack _ _ _ _ (satSucc_lt i) (by decide), toNat_satSucc]

@[simp] theorem bvarBRaw_fvar (idx : Nat) (ty : Expr) :
    (Expr.fvar idx ty).bvarBRaw = 0 := by
  show (bvarOfData (packData _ 0 (satSucc idx) _)).toNat = _
  rw [bvarOfData_pack _ _ _ _ (by decide) (satSucc_lt idx)]; rfl

@[simp] theorem bvarBRaw_sort (u : Level) : (Expr.sort u).bvarBRaw = 0 := by
  show (bvarOfData (packData _ 0 0 _)).toNat = _
  rw [bvarOfData_pack _ _ _ _ (by decide) (by decide)]; rfl

@[simp] theorem bvarBRaw_const (n : Name) (us : List Level) :
    (Expr.const n us).bvarBRaw = 0 := by
  show (bvarOfData (packData _ 0 0 _)).toNat = _
  rw [bvarOfData_pack _ _ _ _ (by decide) (by decide)]; rfl

@[simp] theorem bvarBRaw_lit (l : Literal) : (Expr.lit l).bvarBRaw = 0 := by
  show (bvarOfData (packData _ 0 0 _)).toNat = _
  rw [bvarOfData_pack _ _ _ _ (by decide) (by decide)]; rfl

@[simp] theorem bvarBRaw_app (f a : Expr) :
    (Expr.app f a).bvarBRaw = max f.bvarBRaw a.bvarBRaw := by
  show (bvarOfData (packData _ (max _ _) (max _ _) _)).toNat = _
  rw [bvarOfData_pack _ _ _ _
    (max_lt_32768 (bvarOfData_lt _) (bvarOfData_lt _))
    (max_lt_32768 (fvarOfData_lt _) (fvarOfData_lt _)), toNat_max]
  rfl

@[simp] theorem bvarBRaw_lam (ty b : Expr) (m : BinderMeta) :
    (Expr.lam ty b m).bvarBRaw =
      max ty.bvarBRaw
        (if b.bvarBRaw = satRange then satRange else b.bvarBRaw - 1) := by
  show (bvarOfData (packData _ (max _ (satPred _)) (max _ _) _)).toNat = _
  rw [bvarOfData_pack _ _ _ _
    (max_lt_32768 (bvarOfData_lt _) (satPred_lt (bvarOfData_lt _)))
    (max_lt_32768 (fvarOfData_lt _) (fvarOfData_lt _)), toNat_max,
    toNat_satPred (bvarOfData_lt _)]
  rfl

@[simp] theorem bvarBRaw_forallE (ty b : Expr) (m : BinderMeta) :
    (Expr.forallE ty b m).bvarBRaw =
      max ty.bvarBRaw
        (if b.bvarBRaw = satRange then satRange else b.bvarBRaw - 1) := by
  show (bvarOfData (packData _ (max _ (satPred _)) (max _ _) _)).toNat = _
  rw [bvarOfData_pack _ _ _ _
    (max_lt_32768 (bvarOfData_lt _) (satPred_lt (bvarOfData_lt _)))
    (max_lt_32768 (fvarOfData_lt _) (fvarOfData_lt _)), toNat_max,
    toNat_satPred (bvarOfData_lt _)]
  rfl

@[simp] theorem bvarBRaw_letE (ty v b : Expr) :
    (Expr.letE ty v b).bvarBRaw =
      max (max ty.bvarBRaw v.bvarBRaw)
        (if b.bvarBRaw = satRange then satRange else b.bvarBRaw - 1) := by
  show (bvarOfData (packData _ (max (max _ _) (satPred _)) (max (max _ _) _)
    _)).toNat = _
  rw [bvarOfData_pack _ _ _ _
    (max_lt_32768 (max_lt_32768 (bvarOfData_lt _) (bvarOfData_lt _))
      (satPred_lt (bvarOfData_lt _)))
    (max_lt_32768 (max_lt_32768 (fvarOfData_lt _) (fvarOfData_lt _))
      (fvarOfData_lt _)), toNat_max, toNat_max,
    toNat_satPred (bvarOfData_lt _)]
  rfl

@[simp] theorem bvarBRaw_proj (s : Name) (i : Nat) (e : Expr) :
    (Expr.proj s i e).bvarBRaw = e.bvarBRaw := by
  show (bvarOfData (packData _ _ _ _)).toNat = _
  rw [bvarOfData_pack _ _ _ _ (bvarOfData_lt _) (fvarOfData_lt _)]
  rfl
/- END proof slice raw_bound_constructor_equations -/

/- BEGIN proof slice pure_bound_specification -/
computed field `bvarB`). -/
def _root_.ConLeche.Expr.bvarBound : Expr → Nat
  | .bvar i => i + 1
  | .fvar _ _ | .sort _ | .const _ _ | .lit _ => 0
  | .app f a => max f.bvarBound a.bvarBound
  | .lam ty body _ | .forallE ty body _ =>
    max ty.bvarBound (body.bvarBound - 1)
  | .letE ty val body =>
    max (max ty.bvarBound val.bvarBound) (body.bvarBound - 1)
  | .proj _ _ e => e.bvarBound

/-- `bvarBound` is exact for `looseBVarsBounded`. -/
theorem looseBVarsBounded_iff {x : Expr} :
    ∀ {k : Nat}, x.looseBVarsBounded k = true ↔ x.bvarBound ≤ k := by
  induction x <;> intro k <;>
    (try simp [Expr.looseBVarsBounded, Expr.bvarBound, Nat.max_le, *]) <;>
    omega

/- END proof slice pure_bound_specification -/

/- BEGIN proof slice exact_unsaturated_and_memoized_bound -/
saturate. -/
theorem bvarBRaw_exact : ∀ e : Expr, e.bvarBRaw < satRange →
    e.bvarBRaw = bvarBound e := by
  intro e
  induction e with
  | bvar i =>
    intro h
    rw [bvarBRaw_bvar] at h ⊢
    change min (i + 1) satRange = i + 1
    by_cases small : i + 1 ≤ satRange
    · exact Nat.min_eq_left small
    · have saturated : satRange ≤ i + 1 := Nat.le_of_lt (Nat.lt_of_not_ge small)
      rw [Nat.min_eq_right saturated] at h
      exact False.elim (Nat.lt_irrefl _ h)
  | fvar _ _ _ | sort _ | const _ _ | lit _ =>
    intro _; simp [bvarBound]
  | app f a ihf iha =>
    intro h
    rw [bvarBRaw_app] at h ⊢
    have bounds := Nat.max_lt.mp h
    rw [ihf bounds.1, iha bounds.2, bvarBound]
  | lam ty b m iht ihb =>
    intro h
    rw [bvarBRaw_lam] at h ⊢
    have bounds := Nat.max_lt.mp h
    have hb : b.bvarBRaw ≠ satRange := by
      intro saturated
      have impossible := bounds.2
      rw [ite_eq_left saturated] at impossible
      exact Nat.lt_irrefl _ impossible
    have hb2 : b.bvarBRaw < satRange := by
      have rawBound := bvarBRaw_lt b
      have notSaturated : b.bvarBRaw ≠ 32767 := hb
      change b.bvarBRaw < 32767
      omega
    rw [ite_eq_right hb, iht bounds.1, ihb hb2, bvarBound]
  | forallE ty b m iht ihb =>
    intro h
    rw [bvarBRaw_forallE] at h ⊢
    have bounds := Nat.max_lt.mp h
    have hb : b.bvarBRaw ≠ satRange := by
      intro saturated
      have impossible := bounds.2
      rw [ite_eq_left saturated] at impossible
      exact Nat.lt_irrefl _ impossible
    have hb2 : b.bvarBRaw < satRange := by
      have rawBound := bvarBRaw_lt b
      have notSaturated : b.bvarBRaw ≠ 32767 := hb
      change b.bvarBRaw < 32767
      omega
    rw [ite_eq_right hb, iht bounds.1, ihb hb2, bvarBound]
  | letE ty v b iht ihv ihb =>
    intro h
    rw [bvarBRaw_letE] at h ⊢
    have bounds := Nat.max_lt.mp h
    have inner := Nat.max_lt.mp bounds.1
    have hb : b.bvarBRaw ≠ satRange := by
      intro saturated
      have impossible := bounds.2
      rw [ite_eq_left saturated] at impossible
      exact Nat.lt_irrefl _ impossible
    have hb2 : b.bvarBRaw < satRange := by
      have rawBound := bvarBRaw_lt b
      have notSaturated : b.bvarBRaw ≠ 32767 := hb
      change b.bvarBRaw < 32767
      omega
    rw [ite_eq_right hb, iht inner.1, ihv inner.2, ihb hb2, bvarBound]
  | proj s i sub ih =>
    intro h
    rw [bvarBRaw_proj] at h ⊢
    rw [ih h, bvarBound]

/-- The `bvarBound` walk's memo invariant. -/
def MemoBInv (memo : Std.HashMap Expr Nat) : Prop :=
  ∀ (e : Expr) (r : Nat), memo[e]? = some r → r = bvarBound e

theorem MemoBInv.empty : MemoBInv {} := by
  intro e r hit
  simp only [Std.HashMap.getElem?_empty] at hit
  cases hit

theorem MemoBInv.insert {memo : Std.HashMap Expr Nat} (hm : MemoBInv memo)
    {e : Expr} {r : Nat} (heq : r = bvarBound e) :
    MemoBInv (memo.insert e r) := by
  intro e' r' hk
  rw [Std.HashMap.getElem?_insert] at hk
  split at hk
  · rename_i hbeq
    cases hk
    rw [← (beq_iff_eq ..).mp hbeq]
    exact heq
  · exact hm e' r' hk

/-- **The memoized `bvarBound` walk agrees with `bvarBound`.** -/
theorem bvarBoundGo_spec : ∀ (e : Expr) {memo : Std.HashMap Expr Nat},
    MemoBInv memo →
      (bvarBoundGo memo e).1 = bvarBound e ∧
        MemoBInv (bvarBoundGo memo e).2 := by
  intro e
  induction e with
  | bvar i =>
    intro memo hm
    rw [bvarBoundGo.eq_def]
    split
    · rename_i r hhit; exact ⟨hm _ _ hhit, hm⟩
    · exact ⟨rfl, hm.insert rfl⟩
  | fvar idx ty _ | sort u | const n us | lit l =>
    intro memo hm
    rw [bvarBoundGo.eq_def]
    split
    · rename_i r hhit; exact ⟨hm _ _ hhit, hm⟩
    · exact ⟨rfl, hm.insert rfl⟩
  | app f a ihf iha =>
    intro memo hm
    rw [bvarBoundGo.eq_def]
    split
    · rename_i r hhit; exact ⟨hm _ _ hhit, hm⟩
    · obtain ⟨h1, hm1⟩ := ihf hm
      obtain ⟨h2, hm2⟩ := iha hm1
      refine ⟨by simp [h1, h2, bvarBound], hm2.insert ?_⟩
      simp [h1, h2, bvarBound]
  | lam ty b m iht ihb | forallE ty b m iht ihb =>
    intro memo hm
    rw [bvarBoundGo.eq_def]
    split
    · rename_i r hhit; exact ⟨hm _ _ hhit, hm⟩
    · obtain ⟨h1, hm1⟩ := iht hm
      obtain ⟨h2, hm2⟩ := ihb hm1
      refine ⟨by simp [h1, h2, bvarBound], hm2.insert ?_⟩
      simp [h1, h2, bvarBound]
  | letE ty v b iht ihv ihb =>
    intro memo hm
    rw [bvarBoundGo.eq_def]
    split
    · rename_i r hhit; exact ⟨hm _ _ hhit, hm⟩
    · obtain ⟨h1, hm1⟩ := iht hm
      obtain ⟨h2, hm2⟩ := ihv hm1
      obtain ⟨h3, hm3⟩ := ihb hm2
      refine ⟨by simp [h1, h2, h3, bvarBound], hm3.insert ?_⟩
      simp [h1, h2, h3, bvarBound]
  | proj s i sub ih =>
    intro memo hm
    rw [bvarBoundGo.eq_def]
    split
    · rename_i r hhit; exact ⟨hm _ _ hhit, hm⟩
    · obtain ⟨h1, hm1⟩ := ih hm
      refine ⟨by simp [h1, bvarBound], hm1.insert ?_⟩
      simp [h1, bvarBound]

@[inherit_doc bvarBoundGo_spec]
theorem bvarBoundMemo_eq (e : Expr) :
    bvarBoundMemo e = bvarBound e :=
  (bvarBoundGo_spec e MemoBInv.empty).1

/-- The `bvarB` field is `bvarBound`. -/
theorem bvarB_eq : ∀ e : Expr, e.bvarB = bvarBound e := by
  intro e
  show (if e.bvarBRaw == satRange then bvarBoundMemo e
    else e.bvarBRaw) = _
  split
  · rename_i h; exact bvarBoundMemo_eq e
  · rename_i h
    have hne : e.bvarBRaw ≠ satRange := by simpa using h
    have := bvarBRaw_lt e
    exact bvarBRaw_exact e (by simp [satRange] at *; omega)
/- END proof slice exact_unsaturated_and_memoized_bound -/

end Expr
end ConLeche

namespace ADWH.Experiments.Chapter15.KernelCachedBulkBound

open ConLeche
open ConLeche.Expr
open ConLeche.Cached
open KernelCachedHelperDirect
open KernelCachedSyntaxCorrespondence

/-- The actual packed-bound accessor, including its saturation fallback,
licenses the pure loose-variable cutoff for every expression and cursor. -/
theorem bulk_cutoff_sound : BulkCutoffSound := by
  intro expression cursor bounded
  apply Expr.looseBVarsBounded_iff.mpr
  rw [← Expr.bvarB_eq expression]
  exact bounded

/-- The proof-carrying plain bulk descent agrees with the pure recursive
list operation, including replacements that themselves contain loose bvars. -/
theorem plain_bulk_eq_pure {values : Array Expr} (count : Nat) (expression : Expr)
    {cursor : Nat} (countBound : count ≤ values.size) :
    Expr.instantiateListP values expression count cursor =
      expression.instantiateList (values.toList.take count) cursor :=
  KernelCachedSyntaxCorrespondence.plain_bulk_eq_pure
    bulk_cutoff_sound count expression countBound

/-- Unconditional equality of the actual cached syntactic wrapper and pure
bulk operation; the earlier explicit cutoff premise is now proved. -/
theorem bulk_eq_pure (expression : Expr) (values : List Expr) (cursor : Nat) :
    Expr.instantiateListC expression values cursor =
      expression.instantiateList values cursor :=
  KernelCachedSyntaxCorrespondence.bulk_eq_pure bulk_cutoff_sound
    expression values cursor

/-- The actual state helper returns the pure bulk result and preserves its
helper invariant and NF-map frames, with no additional cutoff-law premise. -/
theorem instListM_pure_result (fe : FEnv) (expression : Expr)
    (values : List Expr) (cursor : Nat) (state : CState)
    (valid : HelperCache fe state) :
    HelperResult fe (instListM expression values cursor)
      (expression.instantiateList values cursor) state :=
  KernelCachedSyntaxCorrespondence.instListM_pure_result bulk_cutoff_sound
    fe expression values cursor state valid

end ADWH.Experiments.Chapter15.KernelCachedBulkBound

#print axioms ConLeche.bvarOfData_lt
#print axioms ConLeche.fvarOfData_lt
#print axioms ConLeche.satSucc_lt
#print axioms ConLeche.toNat_max
#print axioms ConLeche.toNat_sub_one
#print axioms ConLeche.satPred_lt
#print axioms ConLeche.max_lt_32768
#print axioms ConLeche.bvarOfData_pack
#print axioms ConLeche.Expr.bvarBRaw_lt
#print axioms ConLeche.Expr.bvarBRaw_bvar
#print axioms ConLeche.Expr.bvarBRaw_fvar
#print axioms ConLeche.Expr.bvarBRaw_sort
#print axioms ConLeche.Expr.bvarBRaw_const
#print axioms ConLeche.Expr.bvarBRaw_lit
#print axioms ConLeche.Expr.bvarBRaw_app
#print axioms ConLeche.Expr.bvarBRaw_lam
#print axioms ConLeche.Expr.bvarBRaw_forallE
#print axioms ConLeche.Expr.bvarBRaw_letE
#print axioms ConLeche.Expr.bvarBRaw_proj
#print axioms ConLeche.Expr.looseBVarsBounded_iff
#print axioms ConLeche.Expr.bvarBRaw_exact
#print axioms ConLeche.Expr.MemoBInv.empty
#print axioms ConLeche.Expr.MemoBInv.insert
#print axioms ConLeche.Expr.bvarBoundGo_spec
#print axioms ConLeche.Expr.bvarBoundMemo_eq
#print axioms ConLeche.Expr.bvarB_eq
#print axioms ADWH.Experiments.Chapter15.KernelCachedBulkBound.bulk_cutoff_sound
#print axioms ADWH.Experiments.Chapter15.KernelCachedBulkBound.plain_bulk_eq_pure
#print axioms ADWH.Experiments.Chapter15.KernelCachedBulkBound.bulk_eq_pure
#print axioms ADWH.Experiments.Chapter15.KernelCachedBulkBound.instListM_pure_result
