# Small exact bound law for actual cached bulk instantiation

Status: source candidate, not compiled or accepted. This is a new proof leaf
after the distinct observer-law Core and repaired Syntax candidate. All
previous sources, corrections, reviews, attempts and markers remain unchanged.

## Intended result

The leaf proves the previously explicit `BulkCutoffSound` premise for the
actual `Expr.bvarB` accessor. It then supplies unconditional versions of the
plain and actual bulk-instantiation equalities, and the actual `instListM`
pure-result helper theorem. The helper theorem retains the supplied state's
`HelperCache` premise and returns the same actual state equation, helper-cache
preservation and two NF-map frame equations.

This closes a syntactic helper obligation. It does not prove the recursive
cached reducer succeeds, establish either cached body/head induction, or
initialize the helper/cache invariants along the actual record trace.

## Exact dependency slice

The new physical module imports only `KernelCachedSyntaxCorrespondence`.
Six source intervals are retained exactly in `SOURCE-CORRESPONDENCE.json`;
their selected text and every adaptation are explicit.

| Layer | Contents | Public reports |
| --- | --- | ---: |
| Packed word | The two raw range bounds, saturation arithmetic, UInt64 maximum and subtraction transport, maximum bound and bvar-field extraction equation. | 8 |
| Expression constructors | Raw bvar-bound range plus ten constructor equations. Two Nat saturation transport helpers remain private. | 11 |
| Exactness and fallback | Pure `bvarBound` specification, loose-variable predicate equivalence, unsaturated exactness, memo invariant with empty/insertion preservation, actual memo traversal specification, memo wrapper equality and actual accessor equality. | 7 |
| Public bridge | `bulk_cutoff_sound`, unconditional plain bulk equality, unconditional actual bulk equality and `instListM_pure_result`. | 4 |
| Total | Thirty public reports and two private proof helpers. | 30 |

The only new non-theorem declarations are the original pure specification
`ConLeche.Expr.bvarBound` and its proof predicate `ConLeche.Expr.MemoBInv`.
The actual `bvarBoundGo`, `bvarBoundMemo` and `bvarB` definitions are already
present in the corrected cached owner. They are not replaced or redefined.

The packed-field proof needs an upper bound on the fvar field so adjacent bits
cannot contaminate extraction. It does not require fvar-range exactness,
fvar memo correctness or an abstraction theorem. No `CEff`, `CSOK`, complete
`Erase`/`OpsC`, simulation, driver, environment model or installation module is
imported.

## Source adaptations

Upstream theorem headers are unchanged. Four of the six retained intervals
are byte-identical; the other two have these proof-only adaptations:

1. `max_lt_32768` applies `Nat.max_lt.mpr` explicitly after the UInt64-to-Nat
   transport equation.
2. `bvarBRaw_exact` splits the bvar minimum explicitly and extracts application
   and binder component bounds with `Nat.max_lt.mp`. In the saturated binder
   branch it eliminates the explicit impossible strict self-inequality.
   Arithmetic only converts the raw `< 32768` bound and inequality from the
   saturation value into the needed `< 32767` bound.
3. `MemoBInv.empty` explicitly eliminates the impossible `none = some` lookup
   equality after rewriting the empty-map lookup. This is the same proof shape
   justified by the earlier actual Stable diagnostic and its accepted repair.

These changes address previously observed proof-shape risks without changing
the theorem statements, semantic bounds, actual operations or strict options.
They have not themselves been compiled. The new source contains no deprecated
`if_pos`, `if_neg`, `dif_pos` or `dif_neg` alias.

## Why this proves the helper cutoff

The raw packed bound is exact whenever it is below the saturation threshold.
The actual accessor checks the saturation marker and recomputes the bound by
its actual memoized traversal on that branch. The memo invariant associates
each stored value with the pure `bvarBound` of its exact expression key. The
traversal proof establishes result equality and invariant preservation.

Together these facts give `expression.bvarB = expression.bvarBound` for every
expression, including saturated cases. The pure loose-variable predicate is
equivalent to `bvarBound ≤ cursor`, so the accessor inequality licenses the
pure cutoff. This discharges the premise of the earlier Syntax induction for
all inputs; no small-index, closed-replacement or Nat-only restriction is
introduced.

The pure-result corollary reuses actual helper execution already proved by
the direct-helper candidate and rewrites only its returned expression. It
does not infer cached success from a pure result or simulation theorem.

## Prospective complete closure and remaining gates

The complete selection is six physical modules, 32 declaration ownership
origins, 112 public reports and twelve default `.olean`/`.ilean` artifacts.
The additional Expr and ExprOps proofs supplement two already owned origins;
the new project bridge is one additional origin. The report order is
`1 + 25 + 20 + 25 + 11 + 30` for Core, Cached, Stable, Helper, Syntax and Bound.

This inventory is prospective. The observer-law Core/Syntax correction and
this bound leaf each need independent review. Existing reviews retain their
exact original scopes; their inclusion does not constitute acceptance of
either new source. Gate authoring must bind those new review records explicitly
when available. The available cumulative runtime is tight and must be measured
for the complete selected closure.

Root alone may execute the reviewed gate under the unchanged cumulative
30-second, one-CPU, one-thread, 1-GiB, strict-default, three-axiom policy, with
fresh compilation of all selected sources and no prepared experimental
objects. No gate, preflight, mathematical evaluation, exporter, retained
generator or dedicated saved-result reader was executed by this source author.

Beyond compilation and independent review, the remaining substantive work is
query-specific cached recursive reduction and its actual-state invariants,
record-trace initialization and intervening actions, visible-prefix lookup
agreement, annotation and installation validity, prefix `EnvWF`, record
acceptance, `GroupChecked` and the stock numeral theorem.
