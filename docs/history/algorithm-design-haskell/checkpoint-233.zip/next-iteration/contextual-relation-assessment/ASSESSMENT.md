# Contextual relations at the pending guarded contraction

**Assessment:** the outside context is mathematically relevant and fully
identifiable, but the saved evidence does not yet make contextual relations
materially more promising than an exact basis of the 35 global B functions.
Checking the full context would introduce 50 declared variables instead of
B's 16. None of the six recorded refutation assignments has been tested for
compatibility with the outside factors. No new semantic probe was performed.

## Exact saved context

The source is the frozen guarded trace
`cut-rank-review/attempts/cut-rank-01/input/trace.jsonl`, 22,953,426 bytes, SHA256
`6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea`.
Its pending `elimination_begin` at physical line117427 consumes factors187 and
204 at variable153. The fixed proposed shared block is S=[153,160).

The exact active multiset immediately before that event is:

| Factor | Root | Role | Source-cell occurrences | Definition line |
| --- | --- | --- | ---: | ---: |
| 187 | 25319 | A | 15 | 44088 |
| 204 | 42351 | B | 13 | 73220 |
| 190 | 26428 | outside C | 4 | 45864 |
| 193 | 29536 | outside D | 4 | 51426 |
| 216 | 67707 | outside E | 28 | 117425 |

Following only the `initial_factor` and `eliminate.consumed` records partitions
the original64 cell occurrences exactly once: A has15, B13, and the outside
context36. The full occurrence lists, original records, scope labels and root
declarations are retained in `metadata.json`; no graph semantics was used to
produce that extraction.

Writing N_i for the original descriptor interpretation, the actual outside
factor is **P_out = N_26428 * N_29536 * N_67707**. C comes from cells
(4,3),(5,2),(4,4),(5,3); D from (2,4),(3,3),(2,5),(3,4). E contains the other28
outside cells. The factors are not interchangeable with an arbitrary
compatibility mask.

All three outside scopes omit S. The previous accepted guarded replay checked
source-cell occurrences, exact bucket consumption, every completed arithmetic
step, and support containment in declared scopes. The prior guarded-fused
assessment also recorded outside-support independence from the whole block.
These are external diagnostic checks, not new Lean theorems.

Let X be A's12 boundary variables and Y B's16 boundary variables. The outside
declared scopes have these overlaps:

| Outside factor | X variables | Y variables | Other Z variables |
| --- | ---: | ---: | ---: |
| C / root26428 | 1 | 10 | 11 |
| D / root29536 | 6 | 1 | 15 |
| E / root67707 | 5 | 5 | 18 |

Their union is every variable160 through209: 50 variables, partitioned into
X12, Y16 and Z22. Each Y wire meets exactly one of these outside scopes. C
touches Y={189,191,192,193,195,200,202,203,206,208}; D touches Y={174}; E
touches Y={171,175,177,186,187}. The three saved root declarations are all
`ite` nodes (at188,160,160 respectively), so the roots themselves provide no
single unconditional guard shortcut. No descendant traversal was performed
to search for further restrictions.

## What a contextual identity would buy

The saved cut grouping has the form

F(X,Y) = sum over S of A(S,X) B(S,Y) = sum_j A'_j(X) B_j(Y).

The remaining scalar computation is the sum over X,Y,Z of P_out(X,Y,Z) F(X,Y).
Therefore a checked relation R(Y)=sum_j c_j B_j(Y) need only satisfy

**P_out(X,Y,Z) * R(Y) = 0 for every X,Y,Z**

to be usable under this exact outside product. It need not vanish on every Y.
Since P_out is Nat-valued, the condition says that R vanishes on every Y with
at least one positive outside extension. The magnitude of that positive
weight does not relax the equality. Summing P_out over X,Z would characterize
the same set of permitted Y assignments, but computing that marginal is new
work, not a free consequence of the metadata.

This observation does not rescue any of the failed candidates by itself. Their
counterexamples fix Y; the other variables being absent from those functions
does not mean they must be false in the outside network. Evaluating P_out at
an arbitrary all-false extension would not establish incompatibility. One
positive extension disproves a contextual candidate at that counterexample;
incompatibility requires ruling out **all34 free outside variables X,Z**.

The outside context may constrain Y considerably, but that has not been
measured. Conversely, refuting the16 original sample-null directions does not
settle the full global B span: another combination of them may still be a
global identity. There is thus no evidence-based reason yet to replace the
global-basis investigation with a larger contextual search.

## Missing obligations and smallest discriminating question

Before a conditional rewrite can enter a count proof, it needs exact bindings
to these three outside roots and their original source occurrences; a checked
global identity P_out*R=0; preservation of the signed coefficients and grouped
A multiplicities; and a finite-sum congruence carrying that product identity
through all remaining variables. A rewrite must keep its particular outside
context in scope. It cannot be cached as an unconditional B identity or reused
after dropping a context factor. Nonunit coefficients require a proved signed
scaling/divisibility transfer before returning to Nat counts.

The smallest useful future decision probe would be **outside extension versus
certified nonextension for exactly the six already-recorded Y assignments**,
under a separately reviewed fixed budget and full witness accounting. That
would test whether the known global refutations still apply contextually. It
would not prove a contextual identity even if all six were incompatible;
complete checking over the permitted Y assignments would still be required.
A smaller sufficient context, such as C alone, could be used only if its full
annihilation identity is proved, not merely because it touches ten Y wires.
No such probe is implemented or authorized by this assessment.

## Method and status

Only existing text/JSON records, source descriptions and accepted report
metadata were read. The extraction performs raw parsing, active-factor and
occurrence bookkeeping, and set operations on declared scope lists. It does
not walk descriptor children, derive new supports, evaluate functions, run
SAT, compute ranks, generate candidates or run Lean. No compatibility,
conditional identity, new count or n16 completion is claimed.
