#!/usr/bin/env python3
"""Read saved factor records only; no descriptor traversal or evaluation."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TRACE = ROOT / 'next-iteration/cut-rank-review/attempts/cut-rank-01/input/trace.jsonl'
EXPECTED = '6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea'
TARGET_ROOTS = {25319, 26428, 29536, 42351, 67707}


def main():
    raw = TRACE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED
    active, records, origins, roots = {}, {}, {}, {}
    header = pending = None
    for line_number, line in enumerate(raw.splitlines(), 1):
        record = json.loads(line)
        kind = record.get('type')
        if kind == 'header':
            header = record
        elif kind == 'node' and record['id'] in TARGET_ROOTS:
            roots[record['id']] = {'line': line_number, 'record': record}
        elif kind == 'initial_factor':
            fid = record['id']
            records[fid] = {'line': line_number, 'record': record}
            origins[fid] = [fid]
            active[fid] = record
        elif kind == 'eliminate':
            fid = record['id']
            records[fid] = {'line': line_number, 'record': record}
            origins[fid] = [origin for child in record['consumed'] for origin in origins[child]]
            for child in record['consumed']:
                del active[child]
            active[fid] = record
        elif kind == 'elimination_begin' and record['variable'] == 153:
            pending = {'line': line_number, 'record': record}
            break
    assert pending is not None and sorted(active) == [187, 190, 193, 204, 216]
    assert pending['record']['consumed'] == [187, 204]
    block = set(range(153, 160))
    x = set(active[187]['scope']) - block
    y = set(active[204]['scope']) - block
    outside = [190, 193, 216]
    outside_scope = set().union(*(set(active[f]['scope']) for f in outside))
    z = outside_scope - x - y
    result = {
        'kind': 'contextual-relation-factor-metadata-only-v1',
        'source': {'path': str(TRACE), 'bytes': len(raw), 'sha256': EXPECTED},
        'pending': pending,
        'outside_factor_ids': outside,
        'declared_x': sorted(x), 'declared_y': sorted(y), 'declared_z': sorted(z),
        'declared_outside_scope': sorted(outside_scope),
        'active_factors': [],
        'no_source_semantics_executed': True,
        'no_counterexample_compatibility_checked': True,
        'method': 'Raw JSON parsing, factor occurrence bookkeeping, source record selection and declared-scope set operations only. No graph walk, support derivation, function evaluation, SAT, rank or new candidate algebra.',
    }
    occurrences = []
    for fid, record in sorted(active.items()):
        occurrences.extend(origins[fid])
        result['active_factors'].append({
            'id': fid, 'outside': fid in outside,
            'factor_definition': records[fid], 'root_descriptor': roots[record['root']],
            'source_factor_occurrences': origins[fid],
            'source_cells': [records[i]['record']['cell'] for i in origins[fid]],
            'scope_labels': [header['variable_order'][v] for v in record['scope']],
            'declared_x_overlap': sorted(set(record['scope']) & x),
            'declared_y_overlap': sorted(set(record['scope']) & y),
            'declared_z_overlap': sorted(set(record['scope']) & z),
        })
    assert sorted(occurrences) == list(range(64))
    result['source_occurrence_partition'] = {'occurrences': len(occurrences), 'exact_ids_0_through_63': True}
    destination = Path(__file__).resolve().parent / 'metadata.json'
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'output': str(destination), 'outside_factor_roots': [26428, 29536, 67707],
                      'declared_variable_counts': {'X': len(x), 'Y': len(y), 'Z': len(z), 'outside': len(outside_scope)},
                      'semantic_probes': 0}))


if __name__ == '__main__':
    main()
