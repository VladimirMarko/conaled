# Exact basis after the sixteen refutations

## Recommendation

**One predetermined, bounded exact-basis algorithm is worth a final decision test at this cut.** Its useful result would be either complete identities reducing the span of the35 B functions, or a complete witness of their independence. This is a feasibility test with a clear exit condition, not evidence that compression exists or that n16 is close. Do not start a Lean implementation of the new algorithm before obtaining a useful exact identity.

Keep the original35-column order, one50,000-request budget, the existing30-second/one-CPU/1GiB limits, and the original source functions. If the algorithm caps, retain the prefix and stop this line unless a different mechanism supplies independent evidence. If it finishes with rank35, stop pursuing fewer unconditional rational separated terms at this fixed partition. Neither outcome rules out another partition or relations valid only under separately proved outside-factor conditions.

This recommendation is narrower than another sample search: every discarded column must have a complete global identity, and every added basis column must have a source-bound nonzero witness. The adaptive response is part of the new fixed algorithm, not a modification of the completed fixed-candidate batch.

## What the completed batch actually contributes

The producer and independent replayer finished all16 originally chosen directions. All were refuted; none was a zero identity. The total was11,366 charged requests, including700 loads,2,657 RREF requests,940 proposal requests,1,956 source-validation requests and5,113 identity requests. The source closure contained1,253 validated nodes. [RESULTS, REPLAY]

The small identity cost is particularly qualified: the maximum simultaneous relation state had **four terms**, and the maximum recorded coefficient, numerator and denominator widths were **two bits**. Every root stopped at a counterexample. The five completed zero proofs concern proper substates, not a full candidate. These measurements do not bound a35-term basis residual or a successful global zero proof. [RESULTS, REPLAY]

Only six distinct counterexample assignments occur in the outcomes. They are not six established independent new rows, nor evidence of ten remaining identities. We have not evaluated all35 columns at those points or computed an augmented rank. One limited mathematical inference is available: a nonzero evaluation of a vector in the old19-row sample nullspace puts that counterexample row outside the old row span. Thus at least one additional direction exists, conditional on the already replayed sample/source bindings. This is not a Lean rank theorem or a timing extrapolation. [RESULTS, CUT]

The positive evidence for one test is operational: the exact checker exists, source validation is manageable in the measured case, and it has returned genuine counterexamples instead of treating samples as identities. There is still **no affirmative evidence of a nontrivial global relation among B**.

## A concrete exact algorithm and its invariant

Process B0 through B34 once, in their existing order. Retain selected original columns together with integer residuals g0,…,g(k−1), witness assignments y0,…,y(k−1), and checked nonzero integers di = gi(yi). Maintain

`gi(yℓ) = 0 whenever ℓ < i`.

Each gi is an explicitly recorded integer linear combination of the retained original columns, with a nonzero coefficient on the column that introduced it. The resulting evaluation matrix is triangular with nonzero diagonal. This certifies independence of the retained original columns once all arithmetic and source evaluations are checked.

For the next original column Bj, start with r = Bj. For i in increasing order, use the exact source-bound value r(yi) and perform the fraction-free update

`r := di * r − r(yi) * gi`.

This preserves every earlier zero and makes the new residual vanish at yi. Its coefficient on Bj remains nonzero, because each di is nonzero. Keeping integer coefficients reuses the existing signed relation semantics; it does not avoid possible coefficient growth. A different normalization scheme would need its own fixed, fully metered arithmetic policy.

Run the existing global zero/refutation oracle on the resulting exact coefficient state:

- A complete zero proof discards Bj and records its integer identity against the earlier retained columns. The nonzero Bj coefficient gives a rational expression for Bj; it must not be silently treated as coefficient1.
- A complete refutation retains Bj, takes its residual as the next gi, and uses the returned assignment and nonzero value as the next yi and di. Since the residual vanishes at all earlier witnesses, this assignment is new in the required algebraic sense.
- An incomplete oracle result leaves this column unresolved. No basis-rank or spanning conclusion may be reported for it or subsequent columns.

At most35 root oracle decisions are needed. A completed algorithm supplies both required halves: global identities for all discarded columns and an exact nonsingular witness minor for retained columns. Individual candidate failures supplied neither combined invariant.

The scalar evaluations are a real new obligation. A refutation of a signed sum gives that sum's value; it need not supply every constituent function value, especially when terms canceled earlier. Evaluate or certify the missing retained-column values explicitly. Cache complete `(original view, full assignment)` results with charged requests. Do not fill a witness matrix from a residual value or from the old untrusted sample alone. Starting from an empty basis is the simplest source-bound version; any warm start must explicitly bind its required source evaluations and minor.

## Cost and a strict stopping rule

The new budget must include source validation, every scalar evaluation/cache request, coefficient access/comparison/update, normalization and any exact division, witness bookkeeping, and all oracle state/cofactor/branch/cache work. Arithmetic cache collisions and unsuccessful state comparisons cannot become hidden work. The resulting transcript must receive a separately bounded independent replay, under the existing producer/replayer convention. The previous batch's11,366 requests are a separate measured run, not a credit against this one.

There can be595 basis-elimination steps over35 columns. Each step updates a coefficient vector and computes a source-bound residual value: it is not one scalar operation. A dense implementation can already consume tens of thousands of integer operations before global identity checking. Up to35 witnesses and35 columns also permit1,225 distinct source-value positions; each value follows a charged guarded-ADD path, rather than costing one free lookup. Exact coefficient growth is not bounded by the two-bit values observed in the old batch.

More decisively, a simultaneous Shannon zero test on16 variables can visit a full binary tree of131,071 states before sharing, already exceeding the50,000 cap before charging its per-term work. This is an elementary worst-case capacity, not a measured shape of these functions. The shared DAG and caches may reduce it substantially, but there is no current guarantee that they do.

Therefore the proposed test must charge before work and accept an honest cap outcome. No second column order, alternate prime, modified sample pool, changed coefficient normalization, larger budget or larger board should follow automatically. A fixed empty-basis algorithm also should not pre-evaluate an entire truth table as preparation.

If a complete basis has dimension r < 35, report the actual identities, total nonzero transformation coefficients, coefficient/denominator widths and full proof work. A one-column reduction with expensive dense coefficients may offer no useful counting improvement. The exact regrouping would be

`B_j = Σ_t T[j,t] H_t`, hence `F = Σ_t (Σ_j T[j,t] A'_j) H_t`.

Signed or fractional T changes the intermediate arithmetic. Existing Nat factor rules do not automatically justify it; a positive coefficient1 substitution is easier to use than a general rational basis. The cross-representation binding from the original guarded cut to the current lazy contraction also remains necessary. No outside-factor compatibility, source count or useful nonunit aggregation follows merely from the span dimension. [CUT-ASSESSMENT, SIGNED-LAWS]

## What guard polynomials can and cannot offer

The saved35 B views have20 distinct bare cores, all `ite`, and no constant1 bare core. The recorded outer negative-literal counts are at most6. These are saved descriptor facts; no new descendant traversal, polynomial expansion or function evaluation was performed here. [B-METADATA]

There is a smaller sufficient algebraic certificate than expanding all core functions. Treat each distinct bare core as a formal symbol C, and represent its outer guard as

`G(y) = product(positive literals) * product(1 − negative variables)`.

If the signed guard polynomials cancel **separately for each identical core ID**, then the guarded-function relation is exact for arbitrary meanings of those cores. Expanding only an outer guard produces at most64 monomial occurrences, so35 such expansions permit at most2,240 initial occurrences. This is a bound on term production only; term merging, coefficient arithmetic and relation discovery must still be counted. No such expansion or dependence computation has been made.

This restricted certificate may recognize a literal partition of one shared core. It is incomplete for relations between different cores, and failure would not show B independence. Repeated cores under different guards alone do not imply an additive relation. Small outer guards also do not bound the polynomial degree or sparsity of the nontrivial core functions. Expanding the complete16-variable functions can have65,536 monomial positions per function. [B-METADATA, CUT-ASSESSMENT]

Consequently, guard-only formal cancellation is a coherent sufficient rule to retain in the design space, but it is not presently a better-supported separate experiment. Do not add both a polynomial campaign and a basis campaign. The exact-basis test can give the more decisive answer for this fixed cut; if it cannot obtain a useful complete result within the unchanged cap, the present evidence supports moving away from unconditional rank compression here.

## Scope and source bindings

This assessment reads completed metadata and frozen source only. It performs no new algebraic elimination, function evaluation, sample collection, oracle call, replay, counter or Lean run. The independent peer review agreed on the triangular-basis invariant and the need to certify all required constituent evaluations; it supplied no additional empirical result.

Workspace-relative references, bound by `evidence.json`:

- **RESULTS:** `next-iteration/exact-relation-diagnostic/RESULTS.json`.
- **REPLAY:** `next-iteration/exact-relation-diagnostic/attempts/relations-replay-01/replay-report.json`.
- **SOURCE:** `next-iteration/exact-relation-diagnostic/diagnostics/produce_relations.py` and `PROTOCOL.md`.
- **CUT:** `next-iteration/cut-rank-review/attempts/cut-rank-replay-01/replay-report.json`.
- **B-METADATA:** `next-iteration/cut-rank-next-step/recorded-metadata.json`.
- **CUT-ASSESSMENT:** `next-iteration/cut-rank-next-step/ASSESSMENT.md`.
- **SIGNED-LAWS:** `next-iteration/signed-relation-laws/SignedRelations.lean` and its accepted report `attempts/fresh-signed-02/report.json`.
