# Author source review

This records source reasoning and literal bookkeeping, not compilation or
independent review. No Lean command, evaluator, native program, exporter,
gate, preflight or saved-result reader was executed for this package.

## Selected origins and exact change

The selected Direct origin is
`kernel-cached-helper-proof-repairs/source/KernelCachedHelperDirect.lean`
(23,406 bytes, `159dff6a160f1008dee0abeb3dfbc5a33d88b496fef0f41fb51825cdb4bb8a72`).
The earlier `helper-direct/corrected-source` file is historical context and
still has diagnosed type/alias/proof-shape defects; it is not selected.
The selected Frame origin is
`kernel-cached-helper-frame-proof-repairs/source/KernelCachedHelperFrame.lean`
(11,938 bytes, `21d20688902af833b08390c2a7f61d51358b305020fe8c50537bd55a3fa4fab5`).

The source-only assembly script performs 7 Direct and 6 Frame changes. Four
whole old Stable-specific theorem blocks and their four report lines are
removed. The Direct import is relocated, the Frame import is internalized,
both old Stable namespace opens are removed, and the Direct introductory
comment is updated to the new scope. The original mathematical bodies of
all retained declarations are literal, including the tag binder types and
the previously corrected strict-version conditional proof names. Forward
and inverse byte reconstruction, unchanged-complement equality and the
37-report namespace census were checked by the source bookkeeping script.

There is no enclosing namespace change. Direct and Frame each keep their
explicit original namespace and end command. Direct's private tag theorem
is used only within Direct; Frame does not reference it. No imports follow
a module documentation command: the only import is first in the physical
contract. Repeated strict default source options remain the literal original
values. No instance or simp/environment attribute is introduced or removed.

## Actual helper contracts

I read both complete selected logical sources and the current runtime
definitions. `IEnvTags` checks both the type equality and the value/tag
equality of every hit. The three lookup-backed helper maps use actual
`fe.find?`, complete stored records and actual level instantiation; the rule
map additionally uses the real constructor-name search. `instReference`
uses the complete expression/list/cursor key. The cap-triggered bulk memo
reset is handled by the retained proof; there is no assumption that every
bulk instantiation inserts into the old map.

`HelperResult` frames exactly `whnfC` and noncheap `whnfCoreC`. Stored type
and value conversions do not mutate `ienv`; their real pointer/structural
tag tests are justified by the existing tag invariant. `HelperFrame` allows
only arbitrary replacement of the four helper-result maps, so it does not
silently permit a change to tags, NF maps, cheap head or typing caches.

All seven retained helper effect proofs were read, including the two stored
conversion effects and the five common actions. Their `Preserves` premise
only transports a predicate through an actual success equation; it does not
supply success by itself. The result/effect adapter keeps the final state
from the result proof and passes that same equation to preservation.

## New proofs

The two memo-frame constructors use only the generic insertion-field types.
Helper validity ignores those two fields, and the combined constructor pairs
that fact with the caller's frame. The nine-field frame theorem unfolds only
the unchanged projection and relies on no property of its contents.

The generic result theorems use `nf_frame` with equalities in its required
direction (`final.whnfC = state.whnfC` and likewise for noncheap head).
No relation functionality is assumed or needed when both maps are unchanged.
The Eventual specialization instantiates exactly `Full mode fe` and
`Head mode fe`, keeping the same actual FEnv in the semantic witness and
the helper reference lookups. The five forward corollaries do not establish
any new operational equation themselves; they compose the unchanged actual
helper correctness and effect proofs with that invariant transport.

The genuine-empty theorem uses `CState {}` on both sides. The flush theorem
requires `IEnvTags` for the actual surviving `ienv`; it claims nothing about
the validity of the three surviving level caches. The exact nine-field
`restCaches` includes both `ienv` and those level caches, so later callers
may require equality of their complete contents while carrying separate
semantic invariants if needed.

All 14 new roots have explicit parameter/result types and proof bodies.
They introduce no executable algorithm, axioms, admissions, unsafe blocks,
resource options or custom commands. The new helper module imports only
EventualEmpty and the canonical contract. It does not import the old Stable,
Compatibility, HelperDirect or HelperFrame physical owners.

## Limits retained

This is source-only. Prior acceptances of helper proofs in different owners
do not accept their new import closure. The runtime-owner slice and the
Eventual17 review remain separate provenance scopes; any reviews arriving
after this freeze must be bound separately rather than rebasing this record.

This package supplies no beta/delta/Nat-recursion trace, no query count, no
actual program/annotation recognition, no historical-prefix equality,
EnvWF or original GroupChecked certificate, and no numerical result. It
also does not discharge the original native API/default-data ownership or
the fixed total fresh-run cost. Its purpose is the exact reusable helper
boundary for the new actual-cache semantic relation.
