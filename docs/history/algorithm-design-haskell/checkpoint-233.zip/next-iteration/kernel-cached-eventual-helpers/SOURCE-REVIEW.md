# Independent review: actual helpers for eventual cached results

Reviewer: `book_scope_review`.

**Verdict: passed for the canonical contract assembly and all 14 new adapter
proofs, by source inspection.** No new source was compiled or executed. Prior
acceptance of an original helper module does not accept this new physical
ownership or its fresh import closure.

## Scope and exact reconstruction

I read both complete new sources, the retained actual helper/state operations,
the relevant generic memo and eventual interfaces, and the separate completed
owner-selection review. The contract is 33,565 bytes with 37 retained report
roots. The adapter is 10,709 bytes with 14 new report roots. Together they have
44,274 source bytes and 51 ordered reports.

All 576 author input identities match their recorded lengths and SHA-256
digests. Each of the five preserved prior-scope input arrays is included
verbatim. The completed Eventual421 and root Owner517 review/audit pairs arrived
after the author freeze; this review binds those four files separately, along
with the author inventory. Its direct list therefore contains 581 inputs. The
author inventory's historical pending-review statements remain unchanged.
Inherited external SDK/upstream context paths remain at their original
identities; this review adds no new external path.

The contract's 13 exact edits were checked in both directions against the two
selected repaired sources. I independently reconstructed all 15 unchanged
complements, the 77-byte physical separator, both complete transformed origin
chunks and their concatenation. All 52 retained declaration blocks match both
the original and assembled bytes and the recorded individual digests. These
include 37 public theorems, the private `pointer_tag_eq` theorem, and 14 retained
definitions or structures. No retained statement, proof, field, cache key or
expression operation changes.

The selected Direct source is the diagnosed 23,406-byte repair, not its earlier
failed corrected-source draft. The selected Frame source is the diagnosed
11,938-byte repair with the three explicit match reductions. The assembly
preserves both historical scopes rather than claiming that either review
already covered the new concatenation.

All 22 primary excerpts match their stated byte intervals, line intervals,
literal text, lengths and hashes. All 14 current-versus-historical runtime
excerpt pairs compare literally equal. The separate root owner review covers
the wider native/runtime correspondence and disclosed pure-owner omissions;
this helper review does not silently extend that review to an installer or
to the old pure-backed DriverForward proof.

## Explicit omissions and declaration ownership

Exactly four old Stable-specific theorem blocks and their report commands are
removed from the new contract:

| Original canonical theorem | Explicit replacement interface |
| --- | --- |
| `KernelCachedHelperDirect.helper_cache_memo_frame` | New EventualHelpers theorem returns GenericMemo's `MemoFrame`. |
| `KernelCachedHelperDirect.helper_result_stable_nf` | `helper_result_nf` transports arbitrary full/head relations. |
| `KernelCachedHelperFrame.helper_result_stable_with_auxiliary` | `helper_result_eventual_with_auxiliary` specializes the new transport. |
| `KernelCachedHelperFrame.restCaches_memo_frame` | New EventualHelpers theorem frames the same nine-field projection. |

The original files remain unchanged. The new theorems use the distinct
`KernelCachedEventualHelpers` namespace; no old name is assigned a changed
statement. The other edits are the single import relocation, internalization
of the Frame import, removal of the two old Stable opens, and the explicit
scope comment. This package contains no further proof or runtime omission.

The two original canonical namespaces each close explicitly. Their opens do
not leak as top-level opens across the physical separator. Frame's explicit
open of `KernelCachedHelperDirect` resolves to the retained earlier namespace.
The sole private declaration, `pointer_tag_eq`, changes its physical module
owner; its only uses remain inside Direct, and Frame contains no reference to
it. Neither origin adds notation, macros, instances, global simp attributes or
other registrations. Repeated strict-option commands retain their original
values. There is no import after module documentation.

The old physical HelperDirect and HelperFrame owners cannot be imported beside
this contract: they would duplicate the retained canonical declarations. Later
consumers must select one coherent owner and explicitly move any use of an
omitted Stable wrapper to the new interface. Exact source correspondence does
not replace fresh Lean name resolution and elaboration.

## Retained helper semantics

The canonical `HelperCache` has exactly five clauses: converted-entry tags,
bulk instantiation, level-instantiated types, definition values and recursor
RHS values. Every actual hit is covered. `IEnvTags` identifies each cached type
with its type tag and each cached optional value with its own value tag. A
stored conversion still executes the actual pointer/structural tag test before
using that entry. It does not derive validity of arbitrary stored entries from
the full environment or from a flush.

The bulk memo key is the complete expression, argument list and cursor. Its
proof handles the real cutoff, existing-hit and miss branches. In particular,
the capacity branch may discard the old bulk map before inserting the computed
value; correctness is not justified by an assumption that the old map always
survives. The value is the actual `Expr.instantiateListC` result. The retained
plain-descent facts expose the traversal's own proof-carrying result, without
asserting a new equality to a separate pure evaluator.

The type, value and rule references use the actual `fe.find?` lookup. The stored
definition and recursor cases retain complete record shapes, level parameters,
actual level substitution and the original constructor-rule search. Arbitrary
index-name arguments remain in the action interfaces, even where the runtime
does not use them. The `PrefixLookup` adapters require actual visible-prefix
agreement; they do not identify `fe.env` with a restricted prefix, infer
environment validity, or transport helper validity across an unchecked change
of visibility.

`HelperResult` supplies one actual run equation, validity of the five helper
clauses at its returned state, and equality of the two real NF maps in the
direction `final = initial`. It does not cover the cheap head, typing,
annotation, defeq or level memos.

The retained `Preserves` proposition is conditional on a supplied successful
action equation. It cannot establish success by itself. Its helper proofs
permit precisely the four helper-result map replacements through `HelperFrame`.
The stored type/value reads and level-instantiation helper preserve arbitrary
auxiliary predicates because those actual operations do not change state.
The new adapter never replaces an operational success proof with one of these
state-effect statements.

## All 14 new adapter proofs

The three memo-frame constructions are valid by the actual state projections.
Helper validity ignores changes to `whnfC` and noncheap `whnfCoreC`; the paired
frame combines that fact with the caller's independent frame. The new
`restCaches_memo_frame` uses the unchanged nine-field projection. The trivial
helper frame separately proves that arbitrary helper-map replacement preserves
`True`.

`helper_result_nf` takes arbitrary full/head relations and applies GenericMemo's
`nf_frame` using the equalities supplied by the actual helper result. Relation
functionality is unnecessary here because no NF entry changes. The auxiliary
version passes the very same returned state and run equation to `Preserves`.
It cannot combine correctness from one execution with effects from another.
The eventual specialization substitutes exactly the actual-empty `Full` and
`Head` relations for the same mode and `FEnv` used by the helper references.

The genuine-empty theorem combines the independent two-map and helper-cache
empty theorems for actual `CState {}`. The flush theorem requires
`IEnvTags state.ienv`: flush clears the NF and helper-result maps but retains
converted entries and the three level caches. The theorem claims no semantic
validity of those surviving level caches. The nine-field projection is exactly
`ienv`, `whnfCoreCheapC`, `inferC`, `inferIOC`, `defeqC`, `annotC`, `lsimpC`,
`lnzC` and `eqvC`; its frames preserve equality of contents without asserting
what those contents mean.

Finally, the five forward corollaries compose actual correctness and actual
state-effect proofs for `instLevelParamsM`, `instListM`, `constTyAtM`,
`constValAtM` and `ruleRhsAtM`. Each conclusion retains the real `CheckCM` run
equation, eventual NF validity, helper validity and the auxiliary predicate
at the same final state. The first needs no helper frame because the actual
action is pure. The remaining four retain the explicit `HelperFrame`; the
lookup-backed actions also retain their actual lookup and rule-search premises.
There is no answer, root-success or preseeded-cache premise.

## Prospective closure and remaining boundaries

I independently checked all six prospective owner identities, their import
lists and ordered report namespaces. The census is 83 distinct roots, 474,476
source bytes and 12 default output names: reduced Core2, reduced Cached6,
GenericMemo16, EventualEmpty8, canonical Contract37 and EventualHelpers14.
EventualAtoms9 is explicitly excluded. This is a coherent source selection
census, not a compiled dependency certificate or a measured resource fit.

The new helper source imports EventualEmpty and the canonical contract. It
does not import old StableNF, Compatibility, or the old physical helper owners.
No new executable definition is introduced by its 14 theorem declarations.
The retained contract definitions have exactly their original mathematical
bodies; the original actual cached runtime remains the separately reviewed
owner. Its full cached implementation, Lift operations and result-certificate
interfaces are not narrowed by this helper package.

These results supply the helper layer for a later noncircular finite trace
extension. They do not provide beta/delta/arithmetic/Nat-recursion traces,
a whole-query witness, annotation or program recognition, environment
validity, actual installed records, native installer eligibility, an original
`GroupChecked` certificate or the final numeral. A later record proof must
establish its own complete working-state invariant and use the original
record operations. Fresh strict elaboration of every selected owner and the
fixed cumulative resource gate remain necessary.

No author source, metadata, historical review, control or evidence was modified.
No Lean command, compiler, gate, metadata preflight, evaluator, exporter,
profiler, retained generator or dedicated saved-result reader was executed.
