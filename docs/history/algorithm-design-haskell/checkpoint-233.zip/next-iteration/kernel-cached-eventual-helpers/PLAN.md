# Actual helpers for eventual cached results

## Scope and status

This is a separate source candidate. It has not been compiled, evaluated or
selected in an execution gate. The frozen Eventual17 pilot and its inputs are
unchanged. The package prepares the actual helper/state layer needed by later
beta, delta and Nat-recursion trace constructors and by original-record proofs.
It does not construct those traces or an original `GroupChecked` certificate.

The two new physical modules have 51 reports: 37 retained canonical helper
reports and 14 new relation/eventual adapter reports. The prospective minimal
six-module source closure has 83 reports; it is recorded for source review,
not as a measured fit or an authorized execution selection. It includes the
new eventual runtime owner slice, GenericMemo16 and EventualEmpty8, but does
not need EventualAtoms9. A later selection must bind any independent reviews
that were pending when this author inventory was frozen as separate scopes.

## Canonical contract ownership

`KernelCachedHelperContract` imports only `KernelCachedForward`. It preserves
the original namespaces `KernelCachedHelperDirect` and
`KernelCachedHelperFrame`. The selected logical inputs are the diagnosed,
repaired HelperDirect source and the diagnosed, repaired HelperFrame source,
not their earlier failed variants. Their retained declaration bodies,
statements, fields, map keys, expressions and proof options are literal.

The direct helper origin supplies `PrefixLookup`, the five `HelperCache`
clauses, `IEnvTags`, `HelperResult`, the actual two-map `NFFrame`, all syntactic
helper result proofs and their actual-prefix adapters. The frame origin
supplies `Preserves`, `HelperFrame`, the original state-effect proofs and the
exact nine-field `RestCaches` projection. Thus the installed-record guard and
lookup-view contracts can retain their original fully qualified data names.
No historical-prefix equality or environment validity is introduced.

Exactly four old proof wrappers depend on the old Stable invariant/frame:

| Historical declaration | New, explicitly different interface |
| --- | --- |
| `KernelCachedHelperDirect.helper_cache_memo_frame` | `KernelCachedEventualHelpers.helper_cache_memo_frame` returns GenericMemo's frame. |
| `KernelCachedHelperDirect.helper_result_stable_nf` | `KernelCachedEventualHelpers.helper_result_nf` accepts arbitrary NF relations. |
| `KernelCachedHelperFrame.helper_result_stable_with_auxiliary` | `KernelCachedEventualHelpers.helper_result_eventual_with_auxiliary` accepts Eventual NF. |
| `KernelCachedHelperFrame.restCaches_memo_frame` | `KernelCachedEventualHelpers.restCaches_memo_frame` returns GenericMemo's frame. |

Those four historical declarations and their four report lines are omitted
from this selected physical contract. They remain unchanged in their original
files. No old theorem name is silently assigned a new statement. Any later
consumer using a removed wrapper must explicitly import and use the new
namespace. The old HelperDirect/HelperFrame physical owners must not be
imported alongside this owner, because their retained canonical declarations
would have duplicate ownership.

The correspondence file records all 13 changes, their full before/after
text, half-open byte intervals, unchanged complements, the one physical
separator, and inverse reconstruction. Apart from the four theorem/report
omissions, changes are import/open relocation and a truthful scope comment.
All retained declaration bodies are separately compared literally. The Frame
origin's `open KernelCachedHelperDirect` is retained and now resolves to the
earlier canonical declarations in the same file. Neither origin creates a
new instance, global simp attribute, notation or macro. The only retained
private declaration is Direct's `pointer_tag_eq`; Frame never references it.
Both explicit namespaces close before the next origin, so their namespace
opens do not become top-level opens.

## New coupling to the memo relations

`KernelCachedEventualHelpers` imports the contract and
`KernelCachedEventualEmpty`. It opens GenericMemo's namespace; it does not
import the old Stable or Compatibility owners and does not mention a pure
evaluator in a mathematical declaration.

The general helper result theorem takes arbitrary full/head relations. A
canonical `HelperResult` supplies one actual final-state witness, its helper
validity and equality of both NF maps. `nf_frame` transfers the caller's
GenericMemo `NFValid` to that same returned state. The auxiliary version uses
the exact same action equation with the independently supplied `Preserves`
proof; it cannot mix the result of one run with state effects from another.
Specialization substitutes the actual eventual genuine-empty relations.
It requires no new functionality lemma, because helpers preserve both maps.

Five small forward corollaries combine the retained actual result proofs with
their retained state-effect proofs:

| Actual action | Returned expression | Additional premises |
| --- | --- | --- |
| `instLevelParamsM` | Actual `Expr.instLevelParams` | Caller NF, helper validity and auxiliary validity. |
| `instListM` | Actual `Expr.instantiateListC` | The same, plus a frame for the four helper-map writes. |
| `constTyAtM` | Instantiated type of the supplied complete stored record | The same frame and the actual `fe.find?` equation. |
| `constValAtM` | Instantiated stored definition body | The same frame and the actual complete `defnInfo` lookup. |
| `ruleRhsAtM` | Instantiated RHS of the supplied actual rule | The same frame, actual complete `recInfo` lookup and actual constructor-rule search equation. |

Every conclusion includes the real `CheckCM` run equation, Eventual NF,
`HelperCache` and the caller's auxiliary predicate at the actual returned
state. The arbitrary index-name arguments remain present. No helper is
replaced by a mathematical shortcut, and no whole-query cached success or
expected numeral is a premise. The results use the actual cached syntactic
operations; equality to separate pure expression traversals is not inferred.

## Empty state, flush and the remaining caches

`empty_valid` combines independent NF and helper validity for the genuine
default `CState {}`. `true_helper_frame` is available when the empty-state
root construction needs no extra predicate. This supplies the intended
initial-state ingredients for the noncircular Eventual trace extension.

`flushed_valid` retains an explicit `IEnvTags state.ienv` premise. Actual flush
clears the two NF maps and the four helper maps but preserves the converted
entries and the three level caches. Neither this theorem nor the retained
helper theorem asserts that arbitrary surviving converted tags are valid.

The exact nine fields of `restCaches` are `ienv`, `whnfCoreCheapC`, `inferC`,
`inferIOC`, `defeqC`, `annotC`, `lsimpC`, `lnzC`, and `eqvC`. The retained helper
frame and new GenericMemo frame preserve equality of that projection to an
explicit initial state. They establish tolerance of the specified writes;
they do not establish that an arbitrary evaluator call performs only those
writes. The separate `helpers_auxiliary_memo_frame` combines canonical helper
validity with any additional memo frame, so root memo insertion can preserve
both without changing their meanings.

## Review and later integration

The old source reviews remain exact historical scopes. The new runtime-owner
omission is another separate scope: it preserves the complete cached runtime
and removes pure-only declarations/project proof wrappers. This helper
package neither broadens that omission nor claims native BasisGen or a full
original installer is in its dependency graph.

An independent review should reconstruct the contract both ways, compare all
canonical retained declarations and reports, inspect all 14 new proofs and
the selected runtime helper/state equations, and check the namespace/private
name relocation. A fresh execution selection must include the complete new
dependency closure under the existing fixed resource policy. No timing
conclusion follows from the source sizes or the prior helper acceptances.
