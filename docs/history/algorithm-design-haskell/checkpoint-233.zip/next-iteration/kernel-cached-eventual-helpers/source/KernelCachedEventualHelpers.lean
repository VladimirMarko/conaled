import KernelCachedEventualEmpty
import KernelCachedHelperContract

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Actual helper calls with eventual actual-cache backing

The helper contracts and returned values retain their original canonical
names and definitions. This namespace supplies only the coupling to the
relation-parametric NF maps and their eventual genuine-empty instantiation.
The five common helper actions preserve the caller's actual NF maps, the
five helper clauses and any explicitly framed auxiliary predicate.

No pure evaluator, StableNF invariant, arbitrary flush-validity assumption,
or precomputed query result is imported or used. Source candidate only.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedEventualHelpers

open ConLeche
open ConLeche.Cached
open KernelCachedMemoRelation
open KernelCachedHelperDirect
open KernelCachedHelperFrame

/-- The helper clauses ignore both actual normal-form map insertions. -/
theorem helper_cache_memo_frame (fe : FEnv) : MemoFrame (HelperCache fe) := by
  constructor
  · intro state query value valid
    exact ⟨valid.ienv, valid.inst, valid.typeAt, valid.valueAt, valid.ruleAt⟩
  · intro state query value valid
    exact ⟨valid.ienv, valid.inst, valid.typeAt, valid.valueAt, valid.ruleAt⟩

/-- Keep the helper clauses and the caller's additional frame at a memo root. -/
theorem helpers_auxiliary_memo_frame (fe : FEnv) (auxiliary : CState → Prop)
    (frame : MemoFrame auxiliary) :
    MemoFrame (fun state => HelperCache fe state ∧ auxiliary state) := by
  constructor
  · intro state query value valid
    exact ⟨(helper_cache_memo_frame fe).whnfC state query value valid.1,
      frame.whnfC state query value valid.2⟩
  · intro state query value valid
    exact ⟨(helper_cache_memo_frame fe).whnfCoreC state query value valid.1,
      frame.whnfCoreC state query value valid.2⟩

/-- This is the original nine-field projection, with the new memo-frame type. -/
theorem restCaches_memo_frame (initial : CState) :
    MemoFrame (fun state => restCaches state = restCaches initial) := by
  exact ⟨fun _ _ _ valid => valid, fun _ _ _ valid => valid⟩

/-- Used only when a root's genuine-empty run needs no extra state property. -/
theorem true_helper_frame : HelperFrame (fun _ => True) := by
  exact ⟨fun _ _ _ => trivial, fun _ _ _ => trivial,
    fun _ _ _ => trivial, fun _ _ _ => trivial⟩

/-- The actual two-map frame transports any pair of memo relations. -/
theorem helper_result_nf (fullRelation headRelation : Expr → Expr → Prop)
    (fe : FEnv) (action : CheckCM Expr) (value : Expr) (state : CState)
    (valid : NFValid fullRelation headRelation state)
    (result : HelperResult fe action value state) :
    ∃ final, action state = .ok (value, final) ∧
      NFValid fullRelation headRelation final ∧ HelperCache fe final := by
  obtain ⟨final, run, helpers, full, head⟩ := result
  exact ⟨final, run,
    nf_frame fullRelation headRelation state final valid full head, helpers⟩

/-- Correctness and state effects use the same actual returned-state witness. -/
theorem helper_result_nf_with_auxiliary
    (fullRelation headRelation : Expr → Expr → Prop)
    (fe : FEnv) (auxiliary : CState → Prop)
    (action : CheckCM Expr) (value : Expr) (state : CState)
    (valid : NFValid fullRelation headRelation state)
    (result : HelperResult fe action value state)
    (preservation : Preserves auxiliary action) (auxValid : auxiliary state) :
    ∃ final, action state = .ok (value, final) ∧
      NFValid fullRelation headRelation final ∧
      HelperCache fe final ∧ auxiliary final := by
  obtain ⟨final, run, helpers, full, head⟩ := result
  exact ⟨final, run,
    nf_frame fullRelation headRelation state final valid full head,
    helpers, preservation state value final auxValid run⟩

/-- Specialization to exact results of eventual actual calls from genuine {}. -/
theorem helper_result_eventual_with_auxiliary (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (action : CheckCM Expr) (value : Expr)
    (state : CState) (valid : KernelCachedEventualEmpty.NF mode fe state)
    (result : HelperResult fe action value state)
    (preservation : Preserves auxiliary action) (auxValid : auxiliary state) :
    ∃ final, action state = .ok (value, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_nf_with_auxiliary
    (KernelCachedEventualEmpty.Full mode fe)
    (KernelCachedEventualEmpty.Head mode fe)
    fe auxiliary action value state valid result preservation auxValid

/-- Both independent invariants hold in the genuine default state. -/
theorem empty_valid (mode : CheckMode) (fe : FEnv) :
    KernelCachedEventualEmpty.NF mode fe ({} : CState) ∧
      HelperCache fe ({} : CState) := by
  exact ⟨KernelCachedEventualEmpty.empty_valid mode fe, helper_cache_empty fe⟩

/-- Flush keeps converted tags. Their validity is an explicit residue premise. -/
theorem flushed_valid (mode : CheckMode) (fe : FEnv) (state : CState)
    (residue : IEnvTags state.ienv) :
    KernelCachedEventualEmpty.NF mode fe state.flushed ∧
      HelperCache fe state.flushed := by
  exact ⟨nf_flushed (KernelCachedEventualEmpty.Full mode fe)
    (KernelCachedEventualEmpty.Head mode fe) state,
    helper_cache_flushed fe state residue⟩

theorem instLevelParamsM_forward (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (names : List Name) (levels : List Level)
    (expression : Expr) (state : CState)
    (valid : KernelCachedEventualEmpty.NF mode fe state)
    (helpers : HelperCache fe state) (auxValid : auxiliary state) :
    ∃ final, instLevelParamsM names levels expression state =
      .ok (Expr.instLevelParams names levels expression, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_eventual_with_auxiliary mode fe auxiliary _ _ state valid
    (instLevelParamsM_helper_result fe names levels expression state helpers)
    (instLevelParamsM_preserves auxiliary names levels expression) auxValid

theorem instListM_forward (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : HelperFrame auxiliary)
    (expression : Expr) (values : List Expr) (cursor : Nat) (state : CState)
    (valid : KernelCachedEventualEmpty.NF mode fe state)
    (helpers : HelperCache fe state) (auxValid : auxiliary state) :
    ∃ final, instListM expression values cursor state =
      .ok (Expr.instantiateListC expression values cursor, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_eventual_with_auxiliary mode fe auxiliary _ _ state valid
    (instListM_correct fe expression values cursor state helpers)
    (instListM_preserves auxiliary frame expression values cursor) auxValid

theorem constTyAtM_forward (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : HelperFrame auxiliary)
    (indexName name : Name) (levels : List Level) (info : ConstantInfo)
    (state : CState) (valid : KernelCachedEventualEmpty.NF mode fe state)
    (helpers : HelperCache fe state) (auxValid : auxiliary state)
    (found : fe.find? name = some info) :
    ∃ final, constTyAtM fe indexName name levels state =
      .ok (Expr.instLevelParams info.toConstantVal.levelParams levels
        info.toConstantVal.type, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_eventual_with_auxiliary mode fe auxiliary _ _ state valid
    (constTyAtM_correct fe indexName name levels info state helpers found)
    (constTyAtM_preserves auxiliary frame fe indexName name levels) auxValid

theorem constValAtM_forward (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : HelperFrame auxiliary)
    (indexName name : Name) (levels : List Level) (constant : ConstantVal)
    (body : Expr) (hint : ReducibilityHint) (state : CState)
    (valid : KernelCachedEventualEmpty.NF mode fe state)
    (helpers : HelperCache fe state) (auxValid : auxiliary state)
    (found : fe.find? name = some (.defnInfo constant body hint)) :
    ∃ final, constValAtM fe indexName name levels state =
      .ok (Expr.instLevelParams constant.levelParams levels body, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_eventual_with_auxiliary mode fe auxiliary _ _ state valid
    (constValAtM_correct fe indexName name levels constant body hint state helpers found)
    (constValAtM_preserves auxiliary frame fe indexName name levels) auxValid

theorem ruleRhsAtM_forward (mode : CheckMode) (fe : FEnv)
    (auxiliary : CState → Prop) (frame : HelperFrame auxiliary)
    (recursorIndex constructorIndex recursor constructor : Name)
    (levels : List Level) (constant : ConstantVal) (majorIndex parameterCount : Nat)
    (rules : List RecRule) (rule : RecRule) (state : CState)
    (valid : KernelCachedEventualEmpty.NF mode fe state)
    (helpers : HelperCache fe state) (auxValid : auxiliary state)
    (found : fe.find? recursor = some (.recInfo constant majorIndex parameterCount rules))
    (ruleFound : rules.find? (fun candidate => candidate.ctor == constructor) = some rule) :
    ∃ final, ruleRhsAtM fe recursorIndex constructorIndex recursor constructor levels
      state = .ok (Expr.instLevelParams constant.levelParams levels rule.rhs, final) ∧
      KernelCachedEventualEmpty.NF mode fe final ∧
      HelperCache fe final ∧ auxiliary final := by
  exact helper_result_eventual_with_auxiliary mode fe auxiliary _ _ state valid
    (ruleRhsAtM_correct fe recursorIndex constructorIndex recursor constructor levels
      constant majorIndex parameterCount rules rule state helpers found ruleFound)
    (ruleRhsAtM_preserves auxiliary frame fe recursorIndex constructorIndex
      recursor constructor levels) auxValid

#print axioms helper_cache_memo_frame
#print axioms helpers_auxiliary_memo_frame
#print axioms restCaches_memo_frame
#print axioms true_helper_frame
#print axioms helper_result_nf
#print axioms helper_result_nf_with_auxiliary
#print axioms helper_result_eventual_with_auxiliary
#print axioms empty_valid
#print axioms flushed_valid
#print axioms instLevelParamsM_forward
#print axioms instListM_forward
#print axioms constTyAtM_forward
#print axioms constValAtM_forward
#print axioms ruleRhsAtM_forward

end ADWH.Experiments.Chapter15.KernelCachedEventualHelpers
