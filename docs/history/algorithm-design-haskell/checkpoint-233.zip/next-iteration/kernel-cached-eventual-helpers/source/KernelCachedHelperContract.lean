import KernelCachedForward

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Direct result correctness for the actual cached syntactic helpers

This physical contract slice imports the actual cached owner directly.
It retains the canonical helper definitions and all non-Stable helper proofs.
Four old Stable-specific wrappers are omitted across the two logical origins;
new relation and eventual adapters live in KernelCachedEventualHelpers.

The five clauses below concern actual CState maps and actual cache keys.
Syntactic results are specified by the actual proof-carrying ExprOpsC
functions. Their equality to the pure kernel's separate tree operations is
not assumed. The two plain-descent equations expose the proof carried by
the traversal; they do not establish that further pure correspondence.

All helper runs start from the state supplied by the caller. The small
invariant does not constrain the NF maps; every helper frames those maps.
The converted-entry tag clause survives a flush only when supplied for the
actual residue. An arbitrary flush does not establish that clause.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedHelperDirect

open ConLeche
open ConLeche.Cached

/-- A result map backed by its explicit, possibly partial reference lookup. -/
def MapBacked {Key : Type} [BEq Key] [Hashable Key]
    (reference : Key → Option Expr) (cache : Std.HashMap Key Expr) : Prop :=
  ∀ key value, cache[key]? = some value → reference key = some value

theorem map_backed_empty {Key : Type} [BEq Key] [Hashable Key]
    (reference : Key → Option Expr) :
    MapBacked reference (∅ : Std.HashMap Key Expr) := by
  intro key value hit
  simp only [Std.HashMap.getElem?_empty] at hit
  cases hit

theorem map_backed_insert {Key : Type} [BEq Key] [Hashable Key]
    [LawfulBEq Key] (reference : Key → Option Expr)
    (cache : Std.HashMap Key Expr) (key : Key) (value : Expr)
    (valid : MapBacked reference cache) (backing : reference key = some value) :
    MapBacked reference (cache.insert key value) := by
  intro query result hit
  rw [Std.HashMap.getElem?_insert] at hit
  by_cases same : key == query
  · rw [ite_eq_left same] at hit
    cases hit
    have keys : key = query := eq_of_beq same
    cases keys
    exact backing
  · rw [ite_eq_right same] at hit
    exact valid query result hit

/-- The full expression/list/cursor key used by the actual persistent memo. -/
def instReference (key : Expr × List Expr × Nat) : Option Expr :=
  some (Expr.instantiateListC key.1 key.2.1 key.2.2)

def typeReference (lookup : Name → Option ConstantInfo)
    (key : Name × List Level) : Option Expr :=
  match lookup key.1 with
  | some info => some (Expr.instLevelParams info.toConstantVal.levelParams
      key.2 info.toConstantVal.type)
  | none => none

def valueReference (lookup : Name → Option ConstantInfo)
    (key : Name × List Level) : Option Expr :=
  match lookup key.1 with
  | some (.defnInfo constant value _) =>
    some (Expr.instLevelParams constant.levelParams key.2 value)
  | _ => none

def ruleReference (lookup : Name → Option ConstantInfo)
    (key : Name × Name × List Level) : Option Expr :=
  match lookup key.1 with
  | some (.recInfo constant _ _ rules) =>
    match rules.find? (fun candidate => candidate.ctor == key.2.1) with
    | some rule => some (Expr.instLevelParams constant.levelParams key.2.2 rule.rhs)
    | none => none
  | _ => none

/-- Converted entries certify their own tags, independently of the current
environment. A use must still pass the actual pointer/structural tag test. -/
def IEnvTags (cache : Std.HashMap Name CConstE) : Prop :=
  ∀ (name : Name) (entry : CConstE), cache[name]? = some entry →
    entry.ty = entry.tyE ∧
    ∀ (tag value : Expr), entry.val = some (tag, value) → value = tag

theorem ienv_tags_empty : IEnvTags (∅ : Std.HashMap Name CConstE) := by
  intro name entry hit
  simp only [Std.HashMap.getElem?_empty] at hit
  cases hit

/-- Exactly five helper clauses. No invariant on any other CState field is
implicitly included, and the visible FEnv lookup is used without replacing
it by the stored full environment. -/
structure HelperCache (fe : FEnv) (state : CState) : Prop where
  ienv : IEnvTags state.ienv
  inst : MapBacked instReference state.instC
  typeAt : MapBacked (typeReference fe.find?) state.constTyAt
  valueAt : MapBacked (valueReference fe.find?) state.constValAt
  ruleAt : MapBacked (ruleReference fe.find?) state.ruleRhsAt

theorem helper_cache_empty (fe : FEnv) : HelperCache fe ({} : CState) := by
  exact ⟨ienv_tags_empty, map_backed_empty _, map_backed_empty _,
    map_backed_empty _, map_backed_empty _⟩

theorem helper_cache_frame (fe : FEnv) (before after : CState)
    (valid : HelperCache fe before)
    (ienv : after.ienv = before.ienv) (inst : after.instC = before.instC)
    (types : after.constTyAt = before.constTyAt)
    (values : after.constValAt = before.constValAt)
    (rules : after.ruleRhsAt = before.ruleRhsAt) : HelperCache fe after := by
  constructor
  · change IEnvTags after.ienv
    rw [ienv]
    exact valid.ienv
  · change MapBacked instReference after.instC
    rw [inst]
    exact valid.inst
  · change MapBacked (typeReference fe.find?) after.constTyAt
    rw [types]
    exact valid.typeAt
  · change MapBacked (valueReference fe.find?) after.constValAt
    rw [values]
    exact valid.valueAt
  · change MapBacked (ruleReference fe.find?) after.ruleRhsAt
    rw [rules]
    exact valid.ruleAt

/-- Flush clears the four other helper maps but retains ienv. The surviving
tag invariant is a premise about the actual incoming state. -/
theorem helper_cache_flushed (fe : FEnv) (state : CState)
    (residue : IEnvTags state.ienv) : HelperCache fe state.flushed := by
  exact ⟨residue, map_backed_empty _, map_backed_empty _,
    map_backed_empty _, map_backed_empty _⟩

def NFFrame (before after : CState) : Prop :=
  after.whnfC = before.whnfC ∧ after.whnfCoreC = before.whnfCoreC

/-- Result, helper-invariant preservation and both real NF-map frame facts. -/
def HelperResult (fe : FEnv) (action : CheckCM Expr) (value : Expr)
    (state : CState) : Prop :=
  ∃ final, action state = .ok (value, final) ∧
    HelperCache fe final ∧ NFFrame state final

theorem helper_result_of_unchanged (fe : FEnv) (action : CheckCM Expr)
    (value : Expr) (state : CState) (valid : HelperCache fe state)
    (run : action state = .ok (value, state)) :
    HelperResult fe action value state := by
  exact ⟨state, run, valid, rfl, rfl⟩

/-- This is the actual cached function's own cutoff, requiring no claim
about exactness of the saturated loose-variable range implementation. -/
theorem instantiateListC_cut (expression : Expr) (values : List Expr)
    (cursor : Nat) (cut : expression.bvarB ≤ cursor) :
    Expr.instantiateListC expression values cursor = expression := by
  cases values with
  | nil => rfl
  | cons value rest => simp only [Expr.instantiateListC, dite_eq_left cut]

/-- Expose the reference descent already carried in the traversal subtype.
This is not yet equality with Expr.instantiateList. -/
theorem instantiateListC_eq_plain (expression : Expr) (values : List Expr)
    (cursor : Nat) :
    Expr.instantiateListC expression values cursor =
      Expr.instantiateListP values.toArray expression values.toArray.size cursor := by
  cases values with
  | nil =>
    rw [Expr.instantiateListP.eq_def]
    rfl
  | cons value rest =>
    unfold Expr.instantiateListC
    dsimp only []
    by_cases cut : expression.bvarB ≤ cursor
    · rw [dite_eq_left cut]
      exact (Expr.instantiateListP_cut cut).symm
    · rw [dite_eq_right cut]
      exact Expr.resTerm_eq _

theorem instLevelParams_eq_plain (names : List Name) (levels : List Level)
    (expression : Expr) :
    Expr.instLevelParams names levels expression =
      Expr.instLevelParamsP names levels expression := by
  unfold Expr.instLevelParams
  by_cases cut : (!expression.hasLP) = true
  · rw [dite_eq_left cut]
    exact (Expr.instLevelParamsP_cut cut).symm
  · rw [dite_eq_right cut]
    exact Expr.resTerm_eq _

private theorem pointer_tag_eq (left right : Expr)
    (tagged : Expr.exprPtrBEq left right = true) : left = right := by
  change (left == right) = true at tagged
  exact eq_of_beq tagged

theorem instLevelParamsM_correct (names : List Name) (levels : List Level)
    (expression : Expr) (state : CState) :
    instLevelParamsM names levels expression state =
      .ok (Expr.instLevelParams names levels expression, state) := rfl

theorem storedTyIdxM_correct (name : Name) (expression : Expr)
    (state : CState) (valid : IEnvTags state.ienv) :
    storedTyIdxM name expression state = .ok (expression, state) := by
  cases found : state.ienv[name]? with
  | none =>
    simp only [storedTyIdxM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      found, pure, StateT.pure]
  | some entry =>
    by_cases tagged : Expr.exprPtrBEq entry.tyE expression = true
    · have same : entry.ty = expression :=
        (valid name entry found).1.trans (pointer_tag_eq _ _ tagged)
      simp only [storedTyIdxM, Bind.bind, StateT.bind, modifyGet,
        MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
        found, ite_eq_left tagged, same, pure, StateT.pure]
    · simp only [storedTyIdxM, Bind.bind, StateT.bind, modifyGet,
        MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
        found, ite_eq_right tagged, pure, StateT.pure]

theorem storedValIdxM_correct (name : Name) (expression : Expr)
    (state : CState) (valid : IEnvTags state.ienv) :
    storedValIdxM name expression state = .ok (expression, state) := by
  cases found : state.ienv[name]? with
  | none =>
    simp only [storedValIdxM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      found, pure, StateT.pure]
  | some entry =>
    rcases entry with ⟨typeTag, typeValue, optionalValue⟩
    cases optionalValue with
    | none =>
      simp only [storedValIdxM, Bind.bind, StateT.bind, modifyGet,
        MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
        found, pure, StateT.pure]
    | some pair =>
      rcases pair with ⟨tag, value⟩
      have tagValue : value = tag :=
        (valid name ⟨typeTag, typeValue, some (tag, value)⟩ found).2 tag value rfl
      by_cases tagged : Expr.exprPtrBEq tag expression = true
      · have same : value = expression := tagValue.trans (pointer_tag_eq _ _ tagged)
        simp only [storedValIdxM, Bind.bind, StateT.bind, modifyGet,
          MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
          found, ite_eq_left tagged, same, pure, StateT.pure]
      · simp only [storedValIdxM, Bind.bind, StateT.bind, modifyGet,
          MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
          found, ite_eq_right tagged, pure, StateT.pure]

theorem instLevelParamsM_helper_result (fe : FEnv) (names : List Name)
    (levels : List Level) (expression : Expr) (state : CState)
    (valid : HelperCache fe state) :
    HelperResult fe (instLevelParamsM names levels expression)
      (Expr.instLevelParams names levels expression) state := by
  exact helper_result_of_unchanged fe _ _ state valid
    (instLevelParamsM_correct names levels expression state)

theorem storedTyIdxM_helper_result (fe : FEnv) (name : Name)
    (expression : Expr) (state : CState) (valid : HelperCache fe state) :
    HelperResult fe (storedTyIdxM name expression) expression state := by
  exact helper_result_of_unchanged fe _ _ state valid
    (storedTyIdxM_correct name expression state valid.ienv)

theorem storedValIdxM_helper_result (fe : FEnv) (name : Name)
    (expression : Expr) (state : CState) (valid : HelperCache fe state) :
    HelperResult fe (storedValIdxM name expression) expression state := by
  exact helper_result_of_unchanged fe _ _ state valid
    (storedValIdxM_correct name expression state valid.ienv)

theorem instListM_correct (fe : FEnv) (expression : Expr) (values : List Expr)
    (cursor : Nat) (state : CState) (valid : HelperCache fe state) :
    HelperResult fe (instListM expression values cursor)
      (Expr.instantiateListC expression values cursor) state := by
  by_cases cut : expression.bvarB ≤ cursor
  · apply helper_result_of_unchanged fe _ _ state valid
    rw [instantiateListC_cut expression values cursor cut]
    simp only [instListM, modifyGet, MonadStateOf.modifyGet,
      StateT.modifyGet, ite_eq_left cut]
    all_goals rfl
  · cases hit : state.instC[(expression, values, cursor)]? with
    | some cached =>
      have same : cached = Expr.instantiateListC expression values cursor :=
        (Option.some.inj (valid.inst (expression, values, cursor) cached hit)).symm
      apply helper_result_of_unchanged fe _ _ state valid
      simp only [instListM, modifyGet, MonadStateOf.modifyGet,
        StateT.modifyGet, ite_eq_right cut, hit, same]
      all_goals rfl
    | none =>
      let cache := if state.instC.size < instCCapC then state.instC else ∅
      let value := Expr.instantiateListC expression values cursor
      let final := { state with instC := cache.insert (expression, values, cursor) value }
      have cacheValid : MapBacked instReference cache := by
        dsimp only [cache]
        split
        · exact valid.inst
        · exact map_backed_empty _
      have inserted : MapBacked instReference final.instC :=
        map_backed_insert instReference cache (expression, values, cursor) value
          cacheValid rfl
      refine ⟨final, ?_, ⟨valid.ienv, inserted, valid.typeAt, valid.valueAt,
        valid.ruleAt⟩, rfl, rfl⟩
      simp only [instListM, modifyGet, MonadStateOf.modifyGet,
        StateT.modifyGet, ite_eq_right cut, hit, final, cache, value]
      all_goals rfl

theorem constTyAtM_correct (fe : FEnv) (indexName name : Name)
    (levels : List Level) (info : ConstantInfo) (state : CState)
    (valid : HelperCache fe state) (found : fe.find? name = some info) :
    HelperResult fe (constTyAtM fe indexName name levels)
      (Expr.instLevelParams info.toConstantVal.levelParams levels info.toConstantVal.type)
      state := by
  let value := Expr.instLevelParams info.toConstantVal.levelParams levels info.toConstantVal.type
  have reference : typeReference fe.find? (name, levels) = some value := by
    simp only [typeReference, found, value]
  cases hit : state.constTyAt[(name, levels)]? with
  | some cached =>
    have same : cached = value :=
      Option.some.inj ((valid.typeAt (name, levels) cached hit).symm.trans reference)
    apply helper_result_of_unchanged fe _ _ state valid
    simp only [constTyAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, same, pure, StateT.pure, value]
  | none =>
    let final := { state with constTyAt := state.constTyAt.insert (name, levels) value }
    have inserted : MapBacked (typeReference fe.find?) final.constTyAt :=
      map_backed_insert _ state.constTyAt (name, levels) value valid.typeAt reference
    refine ⟨final, ?_, ⟨valid.ienv, valid.inst, inserted, valid.valueAt,
      valid.ruleAt⟩, rfl, rfl⟩
    simp only [constTyAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, found, storedTyIdxM_correct name info.toConstantVal.type state valid.ienv,
      instLevelParamsM_correct, modify, pure, StateT.pure, final, value]

theorem constValAtM_correct (fe : FEnv) (indexName name : Name)
    (levels : List Level) (constant : ConstantVal) (body : Expr)
    (hint : ReducibilityHint) (state : CState) (valid : HelperCache fe state)
    (found : fe.find? name = some (.defnInfo constant body hint)) :
    HelperResult fe (constValAtM fe indexName name levels)
      (Expr.instLevelParams constant.levelParams levels body) state := by
  let value := Expr.instLevelParams constant.levelParams levels body
  have reference : valueReference fe.find? (name, levels) = some value := by
    simp only [valueReference, found, value]
  cases hit : state.constValAt[(name, levels)]? with
  | some cached =>
    have same : cached = value :=
      Option.some.inj ((valid.valueAt (name, levels) cached hit).symm.trans reference)
    apply helper_result_of_unchanged fe _ _ state valid
    simp only [constValAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, same, pure, StateT.pure, value]
  | none =>
    let final := { state with constValAt := state.constValAt.insert (name, levels) value }
    have inserted : MapBacked (valueReference fe.find?) final.constValAt :=
      map_backed_insert _ state.constValAt (name, levels) value valid.valueAt reference
    refine ⟨final, ?_, ⟨valid.ienv, valid.inst, valid.typeAt, inserted,
      valid.ruleAt⟩, rfl, rfl⟩
    simp only [constValAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, found, storedValIdxM_correct name body state valid.ienv,
      instLevelParamsM_correct, modify, pure, StateT.pure, final, value]

theorem ruleRhsAtM_correct (fe : FEnv) (recursorIndex constructorIndex : Name)
    (recursor constructor : Name) (levels : List Level) (constant : ConstantVal)
    (majorIndex parameterCount : Nat) (rules : List RecRule) (rule : RecRule)
    (state : CState) (valid : HelperCache fe state)
    (found : fe.find? recursor = some (.recInfo constant majorIndex parameterCount rules))
    (ruleFound : rules.find? (fun candidate => candidate.ctor == constructor) = some rule) :
    HelperResult fe
      (ruleRhsAtM fe recursorIndex constructorIndex recursor constructor levels)
      (Expr.instLevelParams constant.levelParams levels rule.rhs) state := by
  let value := Expr.instLevelParams constant.levelParams levels rule.rhs
  have reference : ruleReference fe.find? (recursor, constructor, levels) = some value := by
    simp only [ruleReference, found, ruleFound, value]
  cases hit : state.ruleRhsAt[(recursor, constructor, levels)]? with
  | some cached =>
    have same : cached = value :=
      Option.some.inj ((valid.ruleAt (recursor, constructor, levels) cached hit).symm.trans reference)
    apply helper_result_of_unchanged fe _ _ state valid
    simp only [ruleRhsAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, same, pure, StateT.pure, value]
  | none =>
    let final := { state with ruleRhsAt := state.ruleRhsAt.insert (recursor, constructor, levels) value }
    have inserted : MapBacked (ruleReference fe.find?) final.ruleRhsAt :=
      map_backed_insert _ state.ruleRhsAt (recursor, constructor, levels) value
        valid.ruleAt reference
    refine ⟨final, ?_, ⟨valid.ienv, valid.inst, valid.typeAt, valid.valueAt,
      inserted⟩, rfl, rfl⟩
    simp only [ruleRhsAtM, Bind.bind, StateT.bind, modifyGet,
      MonadStateOf.modifyGet, StateT.modifyGet, Except.pure, Except.bind,
      hit, found, ruleFound, instLevelParamsM_correct, modify,
      pure, StateT.pure, final, value]

/-- Agreement with the actual visible prefix must be supplied. In particular,
FEnv.env need not be that prefix after restrictTo, and is not substituted. -/
def PrefixLookup (fe : FEnv) (visiblePrefix : Env) : Prop :=
  ∀ name, fe.find? name = visiblePrefix.find? name

theorem constTyAtM_from_prefix (fe : FEnv) (visiblePrefix : Env)
    (agreement : PrefixLookup fe visiblePrefix) (indexName name : Name)
    (levels : List Level) (info : ConstantInfo) (state : CState)
    (valid : HelperCache fe state) (found : visiblePrefix.find? name = some info) :
    HelperResult fe (constTyAtM fe indexName name levels)
      (Expr.instLevelParams info.toConstantVal.levelParams levels info.toConstantVal.type)
      state := by
  exact constTyAtM_correct fe indexName name levels info state valid
    ((agreement name).trans found)

theorem constValAtM_from_prefix (fe : FEnv) (visiblePrefix : Env)
    (agreement : PrefixLookup fe visiblePrefix) (indexName name : Name)
    (levels : List Level) (constant : ConstantVal) (body : Expr)
    (hint : ReducibilityHint) (state : CState) (valid : HelperCache fe state)
    (found : visiblePrefix.find? name = some (.defnInfo constant body hint)) :
    HelperResult fe (constValAtM fe indexName name levels)
      (Expr.instLevelParams constant.levelParams levels body) state := by
  exact constValAtM_correct fe indexName name levels constant body hint state valid
    ((agreement name).trans found)

theorem ruleRhsAtM_from_prefix (fe : FEnv) (visiblePrefix : Env)
    (agreement : PrefixLookup fe visiblePrefix) (recursorIndex constructorIndex : Name)
    (recursor constructor : Name) (levels : List Level) (constant : ConstantVal)
    (majorIndex parameterCount : Nat) (rules : List RecRule) (rule : RecRule)
    (state : CState) (valid : HelperCache fe state)
    (found : visiblePrefix.find? recursor = some (.recInfo constant majorIndex parameterCount rules))
    (ruleFound : rules.find? (fun candidate => candidate.ctor == constructor) = some rule) :
    HelperResult fe
      (ruleRhsAtM fe recursorIndex constructorIndex recursor constructor levels)
      (Expr.instLevelParams constant.levelParams levels rule.rhs) state := by
  exact ruleRhsAtM_correct fe recursorIndex constructorIndex recursor constructor levels
    constant majorIndex parameterCount rules rule state valid
    ((agreement recursor).trans found) ruleFound

#print axioms map_backed_empty
#print axioms map_backed_insert
#print axioms ienv_tags_empty
#print axioms helper_cache_empty
#print axioms helper_cache_frame
#print axioms helper_cache_flushed
#print axioms helper_result_of_unchanged
#print axioms instantiateListC_cut
#print axioms instantiateListC_eq_plain
#print axioms instLevelParams_eq_plain
#print axioms instLevelParamsM_correct
#print axioms storedTyIdxM_correct
#print axioms storedValIdxM_correct
#print axioms instLevelParamsM_helper_result
#print axioms storedTyIdxM_helper_result
#print axioms storedValIdxM_helper_result
#print axioms instListM_correct
#print axioms constTyAtM_correct
#print axioms constValAtM_correct
#print axioms ruleRhsAtM_correct
#print axioms constTyAtM_from_prefix
#print axioms constValAtM_from_prefix
#print axioms ruleRhsAtM_from_prefix

end ADWH.Experiments.Chapter15.KernelCachedHelperDirect

/- Canonical helper-state frame origin; its Stable wrappers are omitted. -/

set_option autoImplicit false
set_option warningAsError true
set_option Elab.async false

/-!
# Auxiliary invariants through actual cached helper calls

Source candidate only; no compilation or accepted theorem report is claimed.
The existing HelperResult is retained unchanged. Its actual run equation is
combined with an independent state-effect theorem to preserve any predicate
that tolerates the four real helper-map updates. No result correctness is
inferred from that effect theorem, and no successful helper call is postulated
in place of the existing correctness witness.

RestCaches records exactly the nine fields the licensed query path should
leave alone. Its frame instances cover helper writes and the two NF writes;
they do not prove that an arbitrary evaluator call stays in those operations.
-/

namespace ADWH.Experiments.Chapter15.KernelCachedHelperFrame

open ConLeche
open ConLeche.Cached
open KernelCachedHelperDirect

/-- A successful action preserves a predicate on its actual returned state.
This proposition alone does not assert that the action succeeds. -/
def Preserves {α : Type} (auxiliary : CState → Prop) (action : CheckCM α) : Prop :=
  ∀ state value final, auxiliary state →
    action state = .ok (value, final) → auxiliary final

/-- The four helper fields may be replaced by any map. This is a sufficient
frame property, not an assertion that actual helpers make arbitrary writes. -/
structure HelperFrame (auxiliary : CState → Prop) : Prop where
  inst : ∀ state cache, auxiliary state → auxiliary { state with instC := cache }
  typeAt : ∀ state cache, auxiliary state → auxiliary { state with constTyAt := cache }
  valueAt : ∀ state cache, auxiliary state → auxiliary { state with constValAt := cache }
  ruleAt : ∀ state cache, auxiliary state → auxiliary { state with ruleRhsAt := cache }

theorem preserves_pure {α : Type} (auxiliary : CState → Prop) (value : α) :
    Preserves auxiliary (pure value) := by
  intro state result final valid run
  change Except.ok (value, state) = Except.ok (result, final) at run
  have states : state = final := congrArg Prod.snd (Except.ok.inj run)
  exact states ▸ valid

theorem preserves_throw {α : Type} (auxiliary : CState → Prop) (error : CheckError) :
    Preserves auxiliary (throw error : CheckCM α) := by
  intro state value final _ run
  change Except.error error = Except.ok (value, final) at run
  cases run

theorem preserves_bind {α β : Type} (auxiliary : CState → Prop)
    (action : CheckCM α) (next : α → CheckCM β)
    (first : Preserves auxiliary action)
    (rest : ∀ value, Preserves auxiliary (next value)) :
    Preserves auxiliary (action >>= next) := by
  intro state result final valid run
  cases firstRun : action state with
  | error error =>
    simp only [Bind.bind, StateT.bind, firstRun, Except.bind] at run
    cases run
  | ok pair =>
    obtain ⟨value, middle⟩ := pair
    have middleValid : auxiliary middle := first state value middle valid firstRun
    simp only [Bind.bind, StateT.bind, firstRun, Except.bind] at run
    exact rest value middle result final middleValid run

theorem preserves_modifyGet {α : Type} (auxiliary : CState → Prop)
    (step : CState → α × CState)
    (frame : ∀ state, auxiliary state → auxiliary (step state).2) :
    Preserves auxiliary (modifyGet step) := by
  intro state value final valid run
  change Except.ok (step state) = Except.ok (value, final) at run
  have states : (step state).2 = final := congrArg Prod.snd (Except.ok.inj run)
  exact states ▸ frame state valid

theorem preserves_modify (auxiliary : CState → Prop) (step : CState → CState)
    (frame : ∀ state, auxiliary state → auxiliary (step state)) :
    Preserves auxiliary (modify step) := by
  exact preserves_modifyGet auxiliary (fun state => ((), step state)) frame

theorem instLevelParamsM_preserves (auxiliary : CState → Prop)
    (names : List Name) (levels : List Level) (expression : Expr) :
    Preserves auxiliary (instLevelParamsM names levels expression) := by
  exact preserves_pure auxiliary _

theorem storedTyIdxM_preserves (auxiliary : CState → Prop)
    (name : Name) (expression : Expr) :
    Preserves auxiliary (storedTyIdxM name expression) := by
  unfold storedTyIdxM
  apply preserves_bind auxiliary _ _
    (preserves_modifyGet auxiliary _ (fun _ valid => valid))
  intro entry
  cases entry with
  | none => exact preserves_pure auxiliary _
  | some entry =>
    dsimp only []
    split <;> exact preserves_pure auxiliary _

theorem storedValIdxM_preserves (auxiliary : CState → Prop)
    (name : Name) (expression : Expr) :
    Preserves auxiliary (storedValIdxM name expression) := by
  unfold storedValIdxM
  apply preserves_bind auxiliary _ _
    (preserves_modifyGet auxiliary _ (fun _ valid => valid))
  intro entry
  cases entry with
  | none => exact preserves_pure auxiliary _
  | some entry =>
    obtain ⟨typeTag, typeValue, value⟩ := entry
    cases value with
    | none => exact preserves_pure auxiliary _
    | some pair =>
      obtain ⟨tag, value⟩ := pair
      dsimp only []
      split <;> exact preserves_pure auxiliary _

theorem instListM_preserves (auxiliary : CState → Prop)
    (frame : HelperFrame auxiliary) (expression : Expr) (values : List Expr)
    (cursor : Nat) : Preserves auxiliary (instListM expression values cursor) := by
  unfold instListM
  apply preserves_modifyGet auxiliary
  intro state valid
  dsimp only []
  split
  · exact valid
  · split
    · exact valid
    · exact frame.inst state _ valid

theorem constTyAtM_preserves (auxiliary : CState → Prop)
    (frame : HelperFrame auxiliary) (fe : FEnv) (indexName name : Name)
    (levels : List Level) :
    Preserves auxiliary (constTyAtM fe indexName name levels) := by
  unfold constTyAtM
  apply preserves_bind auxiliary _ _
    (preserves_modifyGet auxiliary _ (fun _ valid => valid))
  intro hit
  cases hit with
  | some value => exact preserves_pure auxiliary _
  | none =>
    cases found : fe.find? name with
    | none => exact preserves_throw auxiliary _
    | some info =>
      apply preserves_bind auxiliary _ _ (storedTyIdxM_preserves auxiliary _ _)
      intro raw
      apply preserves_bind auxiliary _ _ (instLevelParamsM_preserves auxiliary _ _ _)
      intro value
      apply preserves_bind auxiliary _ _
        (preserves_modify auxiliary _ (fun state valid => frame.typeAt state _ valid))
      intro _
      exact preserves_pure auxiliary _

theorem constValAtM_preserves (auxiliary : CState → Prop)
    (frame : HelperFrame auxiliary) (fe : FEnv) (indexName name : Name)
    (levels : List Level) :
    Preserves auxiliary (constValAtM fe indexName name levels) := by
  unfold constValAtM
  apply preserves_bind auxiliary _ _
    (preserves_modifyGet auxiliary _ (fun _ valid => valid))
  intro hit
  cases hit with
  | some value => exact preserves_pure auxiliary _
  | none =>
    cases found : fe.find? name with
    | none => exact preserves_throw auxiliary _
    | some info =>
      cases info <;> try exact preserves_throw auxiliary _
      apply preserves_bind auxiliary _ _ (storedValIdxM_preserves auxiliary _ _)
      intro raw
      apply preserves_bind auxiliary _ _ (instLevelParamsM_preserves auxiliary _ _ _)
      intro value
      apply preserves_bind auxiliary _ _
        (preserves_modify auxiliary _ (fun state valid => frame.valueAt state _ valid))
      intro _
      exact preserves_pure auxiliary _

theorem ruleRhsAtM_preserves (auxiliary : CState → Prop)
    (frame : HelperFrame auxiliary) (fe : FEnv)
    (recursorIndex constructorIndex recursor constructor : Name)
    (levels : List Level) : Preserves auxiliary
      (ruleRhsAtM fe recursorIndex constructorIndex recursor constructor levels) := by
  unfold ruleRhsAtM
  apply preserves_bind auxiliary _ _
    (preserves_modifyGet auxiliary _ (fun _ valid => valid))
  intro hit
  cases hit with
  | some value => exact preserves_pure auxiliary _
  | none =>
    cases found : fe.find? recursor with
    | none => exact preserves_throw auxiliary _
    | some info =>
      cases info <;> try exact preserves_throw auxiliary _
      rename_i constant majorIndex parameterCount rules
      dsimp only []
      cases ruleFound : rules.find? (fun candidate => candidate.ctor == constructor) with
      | none => exact preserves_throw auxiliary _
      | some rule =>
        apply preserves_bind auxiliary _ _ (instLevelParamsM_preserves auxiliary _ _ _)
        intro value
        apply preserves_bind auxiliary _ _
          (preserves_modify auxiliary _ (fun state valid => frame.ruleAt state _ valid))
        intro _
        exact preserves_pure auxiliary _

/-- Lift an existing correctness witness and a separate state-effect proof.
The action equation used by preservation is exactly the witness's equation. -/
theorem helper_result_with_auxiliary (fe : FEnv) (auxiliary : CState → Prop)
    (action : CheckCM Expr) (value : Expr) (state : CState)
    (result : HelperResult fe action value state)
    (preservation : Preserves auxiliary action) (valid : auxiliary state) :
    ∃ final, action state = .ok (value, final) ∧
      HelperCache fe final ∧ NFFrame state final ∧ auxiliary final := by
  obtain ⟨final, run, helpers, frame⟩ := result
  exact ⟨final, run, helpers, frame, preservation state value final valid run⟩

/-- The actual fields untouched by the licensed query's intended operations.
No equality or validity of their contents is assumed by this projection. -/
structure RestCaches where
  ienv : Std.HashMap Name CConstE
  whnfCoreCheapC : Std.HashMap Expr Expr
  inferC : Std.HashMap Expr Expr
  inferIOC : Std.HashMap Expr Expr
  defeqC : Std.HashMap (Expr × Expr) Bool
  annotC : Std.HashMap Expr Expr
  lsimpC : Std.HashMap Level Level
  lnzC : Std.HashMap Level Bool
  eqvC : Std.HashMap (Level × Level) Bool

def restCaches (state : CState) : RestCaches :=
  ⟨state.ienv, state.whnfCoreCheapC, state.inferC, state.inferIOC,
    state.defeqC, state.annotC, state.lsimpC, state.lnzC, state.eqvC⟩

theorem restCaches_helper_frame (initial : CState) :
    HelperFrame (fun state => restCaches state = restCaches initial) := by
  exact ⟨fun _ _ valid => valid, fun _ _ valid => valid,
    fun _ _ valid => valid, fun _ _ valid => valid⟩

#print axioms preserves_pure
#print axioms preserves_throw
#print axioms preserves_bind
#print axioms preserves_modifyGet
#print axioms preserves_modify
#print axioms instLevelParamsM_preserves
#print axioms storedTyIdxM_preserves
#print axioms storedValIdxM_preserves
#print axioms instListM_preserves
#print axioms constTyAtM_preserves
#print axioms constValAtM_preserves
#print axioms ruleRhsAtM_preserves
#print axioms helper_result_with_auxiliary
#print axioms restCaches_helper_frame

end ADWH.Experiments.Chapter15.KernelCachedHelperFrame
