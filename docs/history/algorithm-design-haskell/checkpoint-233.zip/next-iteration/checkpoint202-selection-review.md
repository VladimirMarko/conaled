# Checkpoint 202 selection and publication allowance

This standalone snapshot retains the prior mathematical achievements, the
accepted actual-reducer low-operation proof, the accepted structural reference,
their genuine failed attempts, and the reviewed direct-primitive preparation.
The integrated library and its accepted verification bindings are unchanged.

The previous archive occupied 33,340,239 bytes, leaving 214,193 bytes below the
default 32-MiB storage guard. Inspection of the new selection showed that the
new source, evidence, reviews and recovery data exceed that remaining space.
The largest old members are retained canonical proof sources, integrated
verification reports, and complete diagnostic inputs/transcripts; removing
them would weaken existing recovery or require a new restoration format.

Duplicate attempt snapshots remain omitted and resolve through exact canonical
recovery maps. The new logical-reference recovery has one combined map and
auditor; two unpublished intermediate failed-only documents were superseded.
It preserves only five unique historical controls separately. Current selected
mathematical source trees stay physically present, including the kernel copies,
so a new workspace does not need an additional source-copy reconstruction step
before preparing future experiments. No compiled output or toolchain is added.

For this checkpoint the explicit publication allowance is **33 MiB**, passed to
the existing packager with `--max-mib 33`. The archive format, payload hash/CRC
verification, integrated source checks and size-six source checks are unchanged.
The general default remains 32 MiB. This is a storage allowance after selection
review, not a mathematical resource exception: all proof/native budgets remain
30 seconds, one CPU/thread and 1 GiB under their frozen controls.

Before packaging, root inspected both new saved-result auditors and ran each
in live and source-only modes. Both modes passed. The logical audit distinguishes
42 accepted/47 observed roots in the failed attempt from 47 accepted/47 observed
in the corrected attempt, and maps all 72 snapshots. The independent structural
audit distinguishes 18 accepted/26 observed from 26 accepted/26 observed, maps
all 20 snapshots, and checks the exact ten-edit source inverse. These are saved
evidence checks; they execute no Lean, exporter, native checker or counter.

The direct-primitive source, its three proposed rfl proofs and its reviewed
four-module proof/export controls are preparation at this snapshot boundary.
No accepted direct-primitive export or whole-program normalization is claimed.
Read its current review status before the next root-only gate. The concrete
stock Lean theorem `cqueens 16 = 14772512` remains open; the exact external
checker acceptance from checkpoint 200 remains fully preserved.
