# Results of the fixed cut-rank experiment

## Outcome and scope

The only producer attempt, `cut-rank-01`, completed the prescribed policy without reaching a resource or request cap. The only independent replay, `cut-rank-replay-01`, accepted every completed request, the original source bindings, the nesting and completed-dependency order, the fixed sample policy, and the final summary. Its qualification is `checked_complete_fixed_probe_inconclusive`.

This is Python diagnostic evidence, not a Lean theorem. Neither a whole-board counter nor a new contraction was executed. No board larger than 8 was used. The main target `ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512` remains open.

## Source reconstruction and exact grouping

The original guarded trace has SHA-256 `6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea`. The prior assessment has SHA-256 `4cdfebcacf843e88b2c4600a85609653e7308eb5bbee751bd28f2baed2915b00`. The two original roots are 25319 and 42351, and the fixed elimination interval is `[153,160)`.

The diagnostic derives support from source descriptors, reconstructs all 128 Boolean choices, and checks agreement with the previous full cut assessment. It retains original A/B orientation rather than using the assessment's sorted pair orientation as lineage. Exactly 67 choices produce zero products; 61 contributing occurrences remain. These use 61 distinct A views and 35 distinct B views. B multiplicities are 20 groups of size 1, 9 of size 2, 1 of size 3, and 5 of size 4. Every occurrence is retained in its A-group sum.

The resulting exact algebraic representation is

`F(x,y) = sum_j (sum_{i in group_j} A_i(x)) * B_j(y)`.

The independently reconstructed supports of x and y are disjoint. The grouping establishes 35 separated products in the diagnostic. It does not identify 35 syntactically equal factors in the later lazy factored counter, whose node representation differs from this guarded source. Importing these groups into that counter would require an exact correspondence or a new justified collector.

## What the fixed sample establishes

| Side | Source views visited | Distinct sampled assignments | Recorded sample rank over GF(2) | Stopping reason |
|---|---:|---:|---:|---|
| B |35|19|19|Fixed source pool exhausted|
| A |60|56|35|Full35-column rank reached|

The B pool's 19 distinct rows are all independent, but there are only 19 of them. The missing 16 ranks therefore do not establish any dependency among the 35 B functions. No extra assignments, changed ordering, alternate prime, random sample or adaptive null-vector search was attempted.

The A record contains an independent minor selected from actual original sample rows. All matrix entries were evaluated as natural numbers; every A incidence was added before parity reduction. Gaussian elimination retains original row identities rather than substituting the reduced basis rows as minor evidence.

Both sides would have needed full 35-column rank for the experiment's proposed exact rank 35 conclusion. That condition was not met. In particular, the report does not claim that the function has rank 19, that its optimal rank is35, or that either number constrains other partitions, contraction orders, outside-factor restrictions or the final scalar count.

One already computed A-group entry had natural value 2. Its outside-factor compatibility remains unchecked. It does not establish two valid complete queen placements or a reusable positive source count.

## Work accounting

There are 23,591 charged starts,23,591 completed requests, no pending requests, and 47,184 physical JSONL records including the header and footer. The 50,000-request ceiling was unchanged. This is a separate bounded diagnostic, not an addition claimed to fit within the old counter's 49,194-request prefix.

| Request category | Count |
|---|---:|
| Source validation |2,614|
| Partition |1|
| Cut cases |128|
| Cofactors |1,792|
| Retained-occurrence grouping |61|
| Saved pair checks |61|
| Group completion |1|
| Witness requests |467|
| Witness pool decisions |95|
| Scalar evaluations |7,843|
| Natural group additions |3,416|
| Parity conversions |2,625|
| Row packing |2,625|
| Pivot probes |1,763|
| Row XORs |24|
| Rank updates |75|

Cache hits remain charged requests: 847 validation hits, 93 witness hits and 43 evaluation hits. View wrappers are not cached. No packed-lane evaluator or unrecorded second elimination pass was used.

## Resource measurements and identities

| Process | Preparation outside child (seconds) | Timed child wall (seconds) | Peak RSS (KiB) | Exit/status |
|---|---:|---:|---:|---|
| Producer |0.11779046700394247|0.6906339330016635|87,828|0 / passed, sampled rank inconclusive|
| Independent replay |0.08065770899702329|2.046626010007458|97,392|0 / passed, complete fixed probe inconclusive|

Each child ran with the reviewed 30-second CPU and wall limits, one CPU, 1 GiB address-space limit, and shared exclusive execution lock. Child timing includes raw trace parsing, validation and the prescribed semantic work. The runner checked deadlines after exit. All source and input snapshots and originals retained their pre-execution hashes. These are single-run measurements, not repeated or isolated performance benchmarks.

The producer transcript is 6,527,119 bytes with SHA-256 `048355ac631a1cf5fb9793102511e093c6015d011d08236e16f2a309dc1c6066`.

Key records:

- Producer run report: `7592c089d624f0553334450e4c1b773b4ebc5e81f4def081d9a202d98c1f261d`.
- Replay run report: `53aece96a5d3f68cc71f15f11e313344ab9841716d2d107f0e3d1189d5c047c8`.
- Independent replay result: `ec7a47995a9a03f22e73669885b59148787dc29a533f4001a0e10b3f32924fb2`.
- Producer source: `7d0988daa3f275c236e31d03635b8e4509797f847535ff39033830653277354b`.
- Independent replayer source: `d6dbd5f8d5d630c2688db8e553d01a8aded7bcaf42a8287d9e1d3f3bc6525390`.
- Bounded runner: `63b172a2fa0f755881336e9a74930e8b7114508c7f4cd70dde75102d38bb31d2`.

Source/control review was communicated before execution. Its artifact finalization and the separate result-binding review are preserved with their stated chronology. There was no semantic retry, source correction after this run, cap increase or larger-board run.
