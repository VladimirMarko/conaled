# One counted scalar rank probe of the retained binary cut

Status: fixed design only; no implementation, evaluator, counter or Lean run yet.

## Question and exact scope

The retained guarded n8 trace reaches a pending contraction of original roots **25319 (A)** and **42351 (B)** over variables **153 through159**. The saved assessment traversed all128 choices and reported67 syntactically zero cases plus61 distinct remaining symbolic product pairs, each with multiplicity one. It did not compute the resulting contraction.

The new diagnostic will reconstruct those128 restrictions from the original descriptors. It will keep root lineage rather than the old pair sorting. From charged descriptor validation it must derive one fixed partition:

- X: `[172,173,176,178,179,180,181,182,183,184,185,198]`;
- Y: `[171,174,175,177,186,187,189,191,192,193,195,200,202,203,206,208]`.

X and Y are disjoint. Their sizes and the supplied metadata are checks to perform, not trusted support annotations. The two original supports must be exactly the seven cut variables plus X and Y respectively.

The parent's metadata-only grouping predicts61 distinct A views and35 distinct B views, with B degrees `20×1, 9×2, 5×4, 1×3`. This is a design aid, not a result of the new audit. Exact reconstruction, orientation and incidence validation come first.

If validated, write the whole designated two-root contraction as

`F(x,y) = Σ(j<35) A'_j(x) * B_j(y)`,

where `A'_j` is the exact natural sum of every A occurrence paired with B_j. The grouping removes one common B occurrence from each product only by distributivity; every original occurrence remains in its group. It is not semantic equality testing between different views. These35 groups, not the old61 pairs, define the rank question.

This F is one intermediate boundary function. It is not the full source count, and an evaluated boundary assignment need not extend to the outside factors.

## Fixed inputs

The sole mathematical descriptor input is the immutable file

`next-iteration/guarded-fused-review/attempts/assessment-03/input/guarded.jsonl`

with SHA-256 `6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea` (22,953,426 bytes). The old assessment JSON and its analyzer are preserved comparison inputs. No previous count, arithmetic result annotation, `maximum` annotation or supplied support is an evaluation oracle.

Parsing and hashing existing bytes are separately reported preparation. Parsing may build an index from node ID to raw records, preserving duplicate IDs for rejection on access. It must not derive all68,732 node supports, flatten all guards, evaluate nodes or run old replay helpers. Charged recursive validation starts only at roots25319,42351 and the canonical zero descriptor, then follows their actual ancestors. Unreached descriptors are not semantically processed.

## Fixed procedure

### 1. Validate the relevant descriptor closure

Each validation request is charged before any semantic inspection, including cache hits. Constants, ordered branches and guard descriptors are checked locally. Children must have smaller IDs. Branch children must have support strictly above the branch variable. A guard has disjoint positive/negative masks, a nonempty literal set, a bare nonguard core, and guard variables disjoint from the derived core support. All variables are below210.

Derive support and flat view `(positive, negative, bareCoreID)` from checked children. Store the exact result for reuse. Do not use `maximum`. The index may not silently replace duplicate node definitions. One explicitly charged `partition` request checks the two root supports, the cut intersection, the fixed X/Y sets and their disjointness; this is not unmetered preparation.

### 2. Reconstruct every seven-bit restriction and group occurrences

Visit choices0 through127 in ascending integer order, with bit `(choice >> (v−153)) & 1` at variable v. For every choice, restrict A and B independently at each of the seven variables. This performs exactly1,792 cofactor requests; do not shortcut away a whole choice because an earlier result is zero.

A residual is an exact symbolic flat view, not a fabricated existing root ID. A cofactor checks the current view's least possible variable. It removes a matching guard literal, returns canonical zero for a contradicted literal, preserves an absent variable, or selects the proper branch child and merges its exact flat guard. Each request is charged and records its local rule and resulting view. Local strip/merge work is part of this fixed-arity cofactor request; no recursive helper or full function evaluation is hidden in it.

After both full restrictions, drop only a proved canonical-zero factor or contradictory guards. An even positive constant is never pruned as Nat zero. Record all128 choices and their disposition. For retained choices, verify A support is contained in X and B support in Y.

Assign A and B view IDs in first-occurrence order while scanning choices. Group by exact B-view identity. Record every incidence occurrence, including repetitions if any. Compare the resulting canonicalized pair multiset with the saved assessment, but retain original A/B lineage in the new data. Reject a fixture mismatch rather than silently adapting to a different cut. Each saved pair/multiplicity comparison is an explicitly charged `pair_check` request. An explicitly charged `group_complete` request checks the completed counts and previously checked binding flags; it may not perform an unrecorded semantic scan. Expected61/35 sizes and degree data are diagnostic fixture checks, never a source-count premise.

### 3. Generate a deterministic small witness pool

Process the B side first, then A. On B, visit its35 distinct views in first-occurrence order. On A, visit its61 distinct views in first-occurrence order. Stop processing a side immediately when its sampled matrix reaches rank35.

For each view, request its canonical **first positive-leaf witness**: explore a branch's false child first, and its true child only if the false subtree has no positive leaf. Inspect actual constant values; zero has no witness and a positive constant returns the zero assignment. A guard adds its required positive literals to the core witness. Exact support/guard disjointness justifies that construction. Do not inspect maximum-value metadata.

Witness requests, including cached node requests, are charged. Memoize node witnesses, including a completed no-witness result. Virtual-view wrappers are explicit charged requests. Store full210-bit assignments with every unspecified coordinate false.

Deduplicate only exact full assignments within each side; log every accepted, duplicate or absent witness. Do not request additional points after the fixed pool, adapt to nullvectors, retry another order or use another prime. A positive leaf can be even, and distinct functions can have the same greedy witness. Both limitations are intentional.

### 4. Evaluate scalar Nat values and derive the two parity matrices

For each new B assignment, evaluate all35 B views. For each new A assignment, evaluate all61 A views. Scalar evaluation follows exactly one branch or stops on a false guard. It returns the actual Nat leaf value. Cache only `(nodeID, fullAssignment)` values; every cache hit and miss is logged and charged. A virtual-view wrapper is also charged. No evaluation or support prepass is allowed.

For an A row, initialize35 accumulators to0 and add every incidence occurrence's exact Nat value to its group. Every group addition is a charged operation. Then take each complete group modulo2, with each parity conversion charged. This is parity of the grouped sum, not rank of the ungrouped A functions. B rows likewise convert their exact values modulo2.

No extra samples are used to report Nat values. The output may retain sampled groups with value greater than1, but must explicitly state that outside-factor compatibility and useful global count aggregation have not been established.

### 5. Incremental GF(2) elimination

Both matrices have35 columns indexed by the B groups. Pack one row by inserting one parity bit at a time; charge every insertion. Use pivots in increasing column order0 through34. Charge every pivot probe, every executed row XOR and every insertion or zero-row conclusion. Rows and basis words use at most35 bits, so a recorded XOR never stands for a truth table.

Retain original candidate row values, assignment IDs, every elimination step and the original row IDs selected for the basis. On reaching rank35, the35 selected original rows are an explicit square minor. The independent replayer will reconstruct the matrix entries and elimination, not trust a stored rank numeral. No second unmetered Gaussian-elimination pass is permitted; the retained transcript itself supplies the witness.

## Mathematical interpretation

Let U be the selected A' evaluation matrix and V the selected B evaluation matrix. If both35×35 matrices are invertible modulo2, their integer determinants are odd, so both are invertible overQ. Because X and Y are one fixed disjoint partition, independent selected assignments combine and the corresponding sampled matrix of F is exactly `U * Vᵀ`. It is therefore invertible overQ.

Consequently F has separation rank at least35 overQ at this partition, and its displayed35-product grouping gives rank at most35. This excludes a representation with fewer than35 arbitrary rational separated products at this same cut. It does not exclude another partition, a different order, cheaper factors, approximate bounds or another counting method. It also does not prove that the current expensive cofactor algorithm is optimal.

If one or both sampled matrices have rank below35, the result is **inconclusive**. There may be unsampled separating assignments, even-value losses modulo2, or a true dependence. A nullvector of sampled parity rows is not a global GF(2) relation and certainly not a rational relation.

## Concrete accounting and bounds

There is one shared cap of **50,000 charged work requests**, with the same30-second wall/CPU, one-CPU,1-GiB process limits. It covers validation/support requests, cofactors, cut-case completion, grouping, witness requests, pool decisions, scalar evaluation, Nat group additions, parity conversions, row packing, pivot probes, XORs and rank updates. Cache-hit requests consume the cap. Work is charged and its start record written before execution. On exhaustion, retain every completed result and every started unfinished request.

An operation's start and completion are two physical records for one charged request; both IDs and total physical record counts are reported. A completion references only results already completed earlier in the stream. Every ticket has at most one completion; completion order must match the nested request stack. Cache entries are published only after their result completes. The cap footer lists exactly the started requests still on that stack, and a rejected request50001 has no start record. Recursive requests can have larger start IDs than their parent; these are execution tickets, not a falsely claimed topological proof numbering.

The fixed restriction cost is1,792 cofactor requests plus128 cut cases and at most128 grouping records. There are at most35 B assignments and61 A assignments. Before cache savings or early full rank, the bare scalar paths can require `61²×13 +35²×17 =69,198` node visits; explicit view wrappers add at most4,946, giving74,144 evaluation requests. Group additions add at most3,721, parity conversions3,360, row-packing steps3,360, pivot probes3,360 and row XORs at most3,360. These conservative completion bounds already exceed the cap before closure validation and witness search.

Thus **completion is not promised**. The unconditional execution bound is50,000 requests because the next request is rejected before work. The intended benefit of shared-node caching, duplicate witness removal and early side completion is unmeasured. A capped or deficient result is acceptable and must not trigger a retry or a packed-lane variant.

The input counter's49,194 operations before the cut remain historical input data. This new rank diagnostic has its own explicitly identified50,000-work analysis budget; it does not claim that appending its work to the original counting trace would fit a50,000-claim count certificate.

## Future source/Lean obligations if a useful relation is found

This diagnostic alone creates no Lean premise. A future formal use would need internal guarded-descriptor semantics, exact128-choice restriction coverage, natural occurrence grouping, the common support partition, exact scalar-evaluation soundness, and the finite-matrix rank argument. Full source counting additionally needs the retained factor-occurrence plan and all prior operation soundness, not merely the local table.

A proposed rational compression needs **global exact function identities**, not agreement on these sample points. Clear denominators and check the complete integer identities with a proved symbolic method. A modular identity proves only a residue unless an independently proved range/denominator argument restores exact equality. The actual cost of the new compressed factors and all identity witnesses must be included. No full2^28 boundary table, board-language enumeration, expected queens numeral, new contraction or complete count is part of this probe.

## Review and execution status

`schema.json` fixes the record fields and deterministic policy. The parent and independent reviewer must inspect the complete producer, replayer and unchanged bounded controls before any attempt. This file authorizes no execution by itself. Preserve exact input/source snapshots and all outcomes, including cap prefixes.
