# Independent replay of the fixed scalar cut-rank probe

`replay_cut_rank.py` uses only the Python standard library. It imports no producer, old evaluator, counter or mathematical helper. This source implements the frozen scalar-v2 DESIGN/schema and the refined PROTOCOL; it has not yet been executed.

CLI:

```text
python3 replay_cut_rank.py --trace GUARDED_JSONL --assessment SAVED_ASSESSMENT_JSON --certificate WORK_JSONL --output NEW_REPLAY_REPORT_JSON
```

Execution must use the root-owned, reviewed `../run_probe.py` supervisor. The independent replay has its own unchanged 30-second wall/CPU, one-CPU and 1-GiB bound. No direct unmanaged replay or additional sample is authorized by this file.

## Checked obligations

The source pins both original inputs and the approved policy/schema. It indexes raw node definitions without interpreting their semantics. Every later descriptor validation, support derivation, cofactor, greedy witness and scalar evaluation is performed only after consuming its matching charged start record. Recursive children need separate recorded tickets; cache entries become available only after checked completion. Every explicit reference and nested completion is checked in actual completion order.

The fixed policy reconstructs all 128 choices of the seven shared variables, both original root lineages, the common disjoint support partition, the saved-pair binding and every grouped occurrence. It then checks the predetermined B/A witness sources, exact assignment deduplication, all recorded scalar Nat values, occurrence-wise group additions, parity conversion, 35-bit packing and the original-row minor witnesses through incremental XOR elimination. There is no second Gaussian pass or unrecorded evaluator.

The exact work schedule enforces the rank-35 early stop and rejects added samples, skipped sources, wrong cache reuse or incomplete success claims. A cap footer is accepted only at 50,000 starts, before a new request, with the exact pending stack, completed records, caches, kind totals and partial summary. A partial row remains partial even if earlier parity operations have exposed a nonunit Nat group value. All outputs explicitly exclude a source-count or Lean-rank claim.

## Preserved preparation

`origin/reviewed-draft-01/` retains the first draft inspected by the runtime reviewer. Its proposed local output expressions and pool decision were originally eager. The retained patch defers them until after their work-start records; it also aligns canonical-zero comparisons with the exact ZERO view and carries cofactor support from the referenced selected child. The checkpoint field-set comparison uses ordinary set equality, not JSON serialization of sets.

These were source-level review corrections. No failed or successful replay, counter, Lean process, sampled evaluation or matrix-rank computation occurred during their preparation. The root and runtime reviewer must approve the frozen final source and supervisor before the one bounded producer/replay sequence.
