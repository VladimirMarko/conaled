#!/usr/bin/env python3
"""Independent, transcript-driven replay of the fixed scalar-v2 cut audit.

No producer or previous evaluator is imported. A semantic request is entered
only after its exact work record has been consumed. Its children must have
their own records. Thus a cap footer stops replay before an unrecorded request,
and all completed cache entries have locally checked derivations.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass, field
import hashlib
import json
import math
from pathlib import Path
import sys
import time


SCHEMA = "cut-rank-scalar-v2"
SCHEMA_SHA = "e3fb9033c476cbb91ae0de23a66d491deeec1a790f0e093aebf303c055202720"
POLICY_SHA = "017d648bdf79cb3e93fdca458ca51d1c0b6cab24c795e0621135e3bb64ce051e"
SOURCE_SHA = "6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea"
ASSESSMENT_SHA = "4cdfebcacf843e88b2c4600a85609653e7308eb5bbee751bd28f2baed2915b00"
ROOT_A, ROOT_B = 25319, 42351
START, STOP, VARIABLES, COLUMNS, CAP = 153, 160, 210, 35, 50000
ZERO = (0, 0, 0)
MASK_LIMIT = 1 << VARIABLES
ROW_LIMIT = 1 << COLUMNS
KINDS = ("validate", "partition", "cofactor", "cut_case", "group", "pair_check", "group_complete",
         "witness", "pool", "evaluate", "group_add", "parity", "row_pack", "pivot_probe",
         "row_xor", "rank_update")
X_VARS = (172, 173, 176, 178, 179, 180, 181, 182, 183, 184, 185, 198)
Y_VARS = (171, 174, 175, 177, 186, 187, 189, 191, 192, 193, 195, 200, 202, 203, 206, 208)
X_MASK = sum(1 << v for v in X_VARS)
Y_MASK = sum(1 << v for v in Y_VARS)
CUT_MASK = sum(1 << v for v in range(START, STOP))


class Rejected(Exception):
    pass


class ObservedFooter(Exception):
    def __init__(self, record):
        self.record = record


class FixtureFailure(Exception):
    pass


def require(condition, message):
    if not condition:
        raise Rejected(message)


def nat(value, label, bound=None):
    require(type(value) is int and value >= 0, f"{label}: not a natural")
    if bound is not None:
        require(value < bound, f"{label}: out of range")
    return value


def distinct_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"duplicate JSON field {key!r}")
        result[key] = value
    return result


def read_json(text):
    return json.loads(text, object_pairs_hook=distinct_object)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def equal(actual, expected, label):
    # JSON serialization distinguishes False from 0, and True from 1.
    require(canonical(actual) == canonical(expected),
            f"{label}: got {canonical(actual)[:600]}, expected {canonical(expected)[:600]}")


def file_binding(path):
    path = Path(path)
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            size += len(block)
            digest.update(block)
    return {"path": str(path), "bytes": size, "sha256": digest.hexdigest()}


def view(value):
    require(type(value) in (list, tuple) and len(value) == 3, "view shape")
    p, n, core = value
    nat(p, "view positive", MASK_LIMIT)
    nat(n, "view negative", MASK_LIMIT)
    nat(core, "view core")
    require(p & n == 0, "contradictory view")
    return p, n, core


class Source:
    """Pure raw-record indexing; semantic inspection happens inside tickets."""

    def __init__(self, trace, assessment):
        self.trace_binding = file_binding(trace)
        self.assessment_binding = file_binding(assessment)
        equal(self.trace_binding["sha256"], SOURCE_SHA, "guarded source hash")
        equal(self.assessment_binding["sha256"], ASSESSMENT_SHA, "assessment hash")
        self.nodes = {}
        self.parsed_records = 0
        with Path(trace).open(encoding="utf-8") as stream:
            for text in stream:
                record = read_json(text)
                self.parsed_records += 1
                if record.get("type") == "node":
                    # Preserve every definition, including duplicates. No support,
                    # guard flattening, constant evaluation or maximum is read.
                    key = canonical(record.get("id"))
                    self.nodes.setdefault(key, []).append(record)
        self.assessment = read_json(Path(assessment).read_text())
        self.saved_rows = None

    def node(self, node_id):
        nat(node_id, "source node ID")
        records = self.nodes.get(canonical(node_id), [])
        require(len(records) == 1, f"missing/duplicate selected node {node_id}")
        record = records[0]
        equal(record["id"], node_id, "source node ID identity")
        return record

    def saved_table(self):
        # Called only within a charged partition/pair/group request.
        if self.saved_rows is None:
            matches = [entry for entry in self.assessment["symbolic_pair_traversals"]
                       if entry.get("roots") == [ROOT_A, ROOT_B]
                       and entry.get("start") == START and entry.get("stop") == STOP]
            require(len(matches) == 1, "saved assessment cut identity")
            self.saved_rows = matches[0]["leaf_product_pairs"]
            require(type(self.saved_rows) is list, "saved pair table")
        return self.saved_rows


@dataclass
class Ticket:
    id: int
    kind: str
    explicit: list = field(default_factory=list)
    children: list = field(default_factory=list)


class Transcript:
    def __init__(self, path):
        self.path = Path(path)
        self.handle = self.path.open(encoding="utf-8")
        self.physical = 0
        self.starts = 0
        self.finished = {}
        self.stack = []
        self.kinds = Counter()
        self.hits = Counter()
        self.misses = Counter()
        self.stage = "validate"
        self.observation_point = "header"
        self.audit = None
        self.header = self.next_record()

    def next_record(self):
        text = self.handle.readline()
        require(text != "", "unexpected EOF before a complete footer")
        require(text.strip(), "blank JSONL record")
        self.physical += 1
        record = read_json(text)
        require(type(record) is dict, "non-object transcript record")
        return record

    def semantic_record(self):
        record = self.next_record()
        while record.get("type") == "checkpoint":
            require(not self.stack, "checkpoint inside an unfinished request")
            require(set(record) == {"type", "phase", "charged", "completed", "pending", "ranks"},
                    "checkpoint fields")
            require(type(record["phase"]) is str, "checkpoint phase")
            equal(record["charged"], self.starts, "checkpoint charged")
            equal(record["completed"], len(self.finished), "checkpoint completed")
            equal(record["pending"], [], "checkpoint pending")
            equal(record["ranks"], self.audit.ranks(), "checkpoint ranks")
            record = self.next_record()
        if record.get("type") == "error":
            raise ObservedFooter(record)
        return record

    def begin(self, kind, inputs):
        self.observation_point = "before_request"
        record = self.semantic_record()
        require(self.starts < CAP, "request beyond fixed cap")
        equal(record, {"type": "work", "id": self.starts, "stage": self.stage,
                       "kind": kind, "inputs": inputs}, "work record")
        ticket = Ticket(self.starts, kind)
        self.stack.append(ticket)
        self.starts += 1
        self.kinds[kind] += 1
        return ticket

    def finish(self, ticket, outputs):
        self.observation_point = "before_completion"
        record = self.semantic_record()
        require(self.stack and self.stack[-1] is ticket, "non-nested completion")
        dependencies = ticket.explicit + ticket.children
        require(all(type(d) is int and d in self.finished for d in dependencies),
                "dependency has not completed")
        equal(record, {"type": "done", "id": ticket.id,
                       "dependencies": dependencies, "outputs": outputs}, "done record")
        require(ticket.id not in self.finished, "duplicate completion")
        self.finished[ticket.id] = outputs
        self.stack.pop()
        if self.stack:
            self.stack[-1].children.append(ticket.id)
        return outputs, ticket.id

    def request(self, kind, inputs, body):
        ticket = self.begin(kind, inputs)
        return self.finish(ticket, body(ticket))

    def at_end(self):
        require(self.handle.read() == "", "records after terminal footer")


class Audit:
    def __init__(self, source, transcript):
        self.src, self.t = source, transcript
        self.t.audit = self
        self.validation = {}
        self.witness_cache = {}
        self.eval_cache = {}
        self.initial = {}
        self.partition = None
        self.partition_id = None
        self.cut_ids, self.group_ids, self.pair_ids = [], [], []
        self.case_count = 0
        self.zero_choices = []
        self.a_views, self.b_views = [], []
        self.a_lookup, self.b_lookup = {}, {}
        self.occurrences = []
        self.pair_occurrences = {}
        self.pair_group_ids = {}
        self.pair_matches = []
        self.saved_matched_rows = set()
        self.group_match = False
        self.b_degrees = []
        self.nonunits = []
        self.sides = {side: {"sample_rows": [], "source_attempts": [], "rank": 0,
                             "selected_original_row_ids": [], "minor_row_words": [],
                             "status": "not_started"} for side in ("B", "A")}
        self.bases = {"A": {}, "B": {}}
        self.pool_seen = {"A": {}, "B": {}}
        self.complete = False
        self.fixture_failed = False
        self.scope = {"phase": "validate"}

    def ranks(self):
        return {side: self.sides[side]["rank"] for side in ("B", "A")}

    def checked(self, node_id):
        require(node_id in self.validation, f"unvalidated source access {node_id}")
        return self.validation[node_id]

    def view_support(self, v):
        p, n, core = view(v)
        info, _ = self.checked(core)
        require(p & info["support"] == 0 and n & info["support"] == 0,
                "view guard/core overlap")
        require(info["node_kind"] != "guard", "view core is a guard")
        return p | n | info["support"]

    def validate(self, node_id):
        def body(ticket):
            if node_id in self.validation:
                self.t.hits["validate"] += 1
                previous, prior = self.validation[node_id]
                ticket.explicit.append(prior)
                return dict(previous, cache_hit=True, prior=prior)
            self.t.misses["validate"] += 1
            node = self.src.node(node_id)
            kind = node.get("kind")
            if kind == "constant":
                nat(node.get("value"), "constant value")
                support, flat = 0, [0, 0, node_id]
            elif kind == "ite":
                variable = nat(node.get("variable"), "branch variable", VARIABLES)
                low = nat(node.get("low"), "low child", node_id)
                high = nat(node.get("high"), "high child", node_id)
                lo, _ = self.validate(low)
                hi, _ = self.validate(high)
                require((lo["support"] | hi["support"]) & ((1 << (variable + 1)) - 1) == 0,
                        "branch child violates variable order")
                support = (1 << variable) | lo["support"] | hi["support"]
                flat = [0, 0, node_id]
            elif kind == "guard":
                positive = nat(node.get("positive"), "guard positive", MASK_LIMIT)
                negative = nat(node.get("negative"), "guard negative", MASK_LIMIT)
                require(positive | negative != 0 and positive & negative == 0,
                        "guard literals")
                core = nat(node.get("core"), "guard core", node_id)
                child, _ = self.validate(core)
                require(child["node_kind"] != "guard", "nested source guard")
                require((positive | negative) & child["support"] == 0, "guard/core support overlap")
                support = positive | negative | child["support"]
                flat = [positive, negative, core]
            else:
                raise Rejected(f"unknown source node kind {kind!r}")
            nat(support, "derived support", MASK_LIMIT)
            return {"cache_hit": False, "prior": None, "support": support,
                    "flat": flat, "node_kind": kind}
        outputs, work = self.t.request("validate", {"node": node_id}, body)
        if not outputs["cache_hit"]:
            require(node_id not in self.validation, "validation cache overwrite")
            self.validation[node_id] = (outputs, work)
        return outputs, work

    def check_partition(self):
        def body(ticket):
            ticket.explicit.extend(self.initial[key][1] for key in ("A", "B", "zero"))
            sa = self.initial["A"][0]["support"]
            sb = self.initial["B"][0]["support"]
            x, y = sa & ~CUT_MASK, sb & ~CUT_MASK
            zero_node = self.src.node(0)
            ok = (sa == CUT_MASK | X_MASK and sb == CUT_MASK | Y_MASK
                  and x & y == 0 and sa & sb == CUT_MASK
                  and zero_node.get("kind") == "constant" and zero_node.get("value") == 0)
            return {"x": x, "y": y, "matches": ok}
        result, work = self.t.request("partition", {"a_root": ROOT_A, "b_root": ROOT_B,
                                                    "start": START, "stop": STOP}, body)
        self.partition, self.partition_id = result, work
        if not result["matches"]:
            self.fixture_failed = True
            raise FixtureFailure("partition mismatch")

    def cofactor(self, current, variable, bit):
        current = tuple(current)
        inputs = {"view": list(current), "variable": variable, "bit": bit}
        support_out = []
        def body(ticket):
            view(current)
            nat(variable, "cofactor variable", VARIABLES)
            require(START <= variable < STOP and type(bit) is int and bit in (0, 1),
                    "cofactor input domain")
            p, n, core = current
            info, validated = self.checked(core)
            ticket.explicit.extend([validated, self.initial["zero"][1]])
            support = self.view_support(current)
            require(support & ((1 << variable) - 1) == 0, "cofactor below remaining head")
            literal = 1 << variable
            if current == ZERO:
                result, rule, result_support = ZERO, "zero", 0
            elif (p | n) & literal:
                satisfied = bool(p & literal) == bool(bit)
                result = (p & ~literal, n & ~literal, core) if satisfied else ZERO
                rule = "guard_true" if satisfied else "guard_false"
                result_support = support & ~literal if satisfied else 0
            elif not support & literal:
                result, rule = current, "absent"
                result_support = support
            else:
                node = self.src.node(core)
                require(node["kind"] == "ite" and node["variable"] == variable, "cofactor branch head")
                child = node["high"] if bit else node["low"]
                child_info, child_validation = self.checked(child)
                ticket.explicit.append(child_validation)
                cp, cn, cc = view(child_info["flat"])
                rp, rn = p | cp, n | cn
                result = ZERO if (cp, cn, cc) == ZERO or rp & rn else (rp, rn, cc)
                rule = "branch"
                # Derive this from the referenced child's checked flat form.
                # Do not read an unreferenced new bare-core cache entry.
                bare_support = child_info["support"] & ~(cp | cn)
                require((rp | rn) & bare_support == 0, "branch view guard/core overlap")
                result_support = 0 if result == ZERO else rp | rn | bare_support
            support_out.append(result_support)
            return {"result": list(result), "rule": rule}
        result, work = self.t.request("cofactor", inputs, body)
        return view(result["result"]), work, support_out[0]

    def cut_case(self, choice):
        def body(ticket):
            ticket.explicit.extend([self.initial["A"][1], self.initial["B"][1]])
            a = view(self.initial["A"][0]["flat"])
            b = view(self.initial["B"][0]["flat"])
            sa = self.initial["A"][0]["support"]
            sb = self.initial["B"][0]["support"]
            for variable in range(START, STOP):
                bit = (choice >> (variable - START)) & 1
                a, _, sa = self.cofactor(a, variable, bit)
                b, _, sb = self.cofactor(b, variable, bit)
            if a == ZERO:
                disposition = "zero_a"
            elif b == ZERO:
                disposition = "zero_b"
            elif (a[0] & b[1]) or (b[0] & a[1]):
                disposition = "guard_conflict"
            else:
                require(sa & ~X_MASK == 0, "A restriction left its fixed cut")
                require(sb & ~Y_MASK == 0, "B restriction left its fixed cut")
                disposition = "retained"
            return {"a": list(a), "b": list(b), "disposition": disposition}
        result, work = self.t.request("cut_case", {"choice": choice}, body)
        self.case_count += 1
        self.cut_ids.append(work)
        if result["disposition"] != "retained":
            self.zero_choices.append(choice)
        return result, work

    def group(self, choice, cut_result, cut_work):
        a, b = tuple(cut_result["a"]), tuple(cut_result["b"])
        pair_out = []
        def body(ticket):
            ticket.explicit.append(cut_work)
            view(a)
            view(b)
            pair = tuple(sorted((a, b)))
            pair_out.append(pair)
            ai = self.a_lookup.get(a, len(self.a_views))
            bi = self.b_lookup.get(b, len(self.b_views))
            return {"a_index": ai, "b_index": bi,
                    "pair_occurrences": self.pair_occurrences.get(pair, 0) + 1}
        result, work = self.t.request("group", {"choice": choice, "a": list(a), "b": list(b)}, body)
        pair = pair_out[0]
        ai, bi = result["a_index"], result["b_index"]
        if a not in self.a_lookup:
            self.a_lookup[a] = ai
            self.a_views.append(a)
        if b not in self.b_lookup:
            self.b_lookup[b] = bi
            self.b_views.append(b)
            self.b_degrees.append(0)
        self.b_degrees[bi] += 1
        self.occurrences.append({"choice": choice, "a_index": ai, "b_index": bi})
        self.pair_occurrences[pair] = result["pair_occurrences"]
        self.pair_group_ids.setdefault(pair, []).append(work)
        self.group_ids.append(work)

    def compare_pair(self, pair, multiplicity):
        matched_indices = []
        def body(ticket):
            ticket.explicit.extend(self.pair_group_ids[pair])
            total = 0
            for index, entry in enumerate(self.src.saved_table()):
                saved_pair = (view(entry["left"]), view(entry["right"]))
                require(saved_pair == tuple(sorted(saved_pair)), "old pair is not canonical")
                amount = nat(entry["assignment_multiplicity"], "old pair multiplicity")
                require(amount > 0, "empty old pair occurrence")
                if saved_pair == pair:
                    total += amount
                    matched_indices.append(index)
            return {"matches": len(matched_indices) == 1 and total == multiplicity}
        result, work = self.t.request("pair_check", {"pair": [list(v) for v in pair],
                                                     "multiplicity": multiplicity}, body)
        self.saved_matched_rows.update(matched_indices)
        self.pair_matches.append(result["matches"])
        self.pair_ids.append(work)

    def complete_grouping(self):
        def body(ticket):
            ticket.explicit.extend([self.partition_id] + self.cut_ids + self.group_ids + self.pair_ids)
            matched = (self.partition["matches"] and self.case_count == 128
                       and len(self.zero_choices) == 67 and len(self.occurrences) == 61
                       and len(self.a_views) == 61 and len(self.b_views) == 35
                       and Counter(self.b_degrees) == Counter({1: 20, 2: 9, 4: 5, 3: 1})
                       and len(self.pair_occurrences) == 61
                       and all(m == 1 for m in self.pair_occurrences.values())
                       and all(self.pair_matches)
                       and len(self.saved_matched_rows) == len(self.src.saved_table()))
            return {"b_degrees": self.b_degrees.copy(), "matches": bool(matched)}
        inputs = {"choices": self.case_count, "retained": len(self.occurrences),
                  "distinct_a": len(self.a_views), "distinct_b": len(self.b_views),
                  "checked_pairs": len(self.pair_ids)}
        result, _ = self.t.request("group_complete", inputs, body)
        self.group_match = result["matches"]
        if not self.group_match:
            self.fixture_failed = True
            raise FixtureFailure("complete grouping mismatch")

    def witness(self, target_kind, target):
        normalized = tuple(target) if target_kind == "view" else target
        inputs = {"target_kind": target_kind,
                  "target": list(normalized) if target_kind == "view" else normalized}
        def body(ticket):
            if target_kind == "view":
                view(normalized)
            else:
                require(target_kind == "node", "witness target kind")
                nat(normalized, "witness node")
            if target_kind == "node" and normalized in self.witness_cache:
                self.t.hits["witness"] += 1
                assignment, prior = self.witness_cache[normalized]
                ticket.explicit.append(prior)
                return {"assignment": assignment, "cache_hit": True, "prior": prior}
            if target_kind == "view":
                positive, negative, core = normalized
                _, validated = self.checked(core)
                ticket.explicit.append(validated)
                supported = self.view_support(normalized)
                child, _ = self.witness("node", core)
                assignment = child["assignment"]
                if assignment is not None:
                    require(assignment & (positive | negative) == 0, "view witness literal collision")
                    assignment |= positive
                    require(assignment & ~supported == 0, "view witness outside support")
            else:
                self.t.misses["witness"] += 1
                info, validated = self.checked(normalized)
                ticket.explicit.append(validated)
                node = self.src.node(normalized)
                if node["kind"] == "constant":
                    assignment = 0 if node["value"] > 0 else None
                elif node["kind"] == "guard":
                    child, _ = self.witness("node", node["core"])
                    assignment = child["assignment"]
                    if assignment is not None:
                        require(assignment & (node["positive"] | node["negative"]) == 0,
                                "guard witness literal collision")
                        assignment |= node["positive"]
                else:
                    low, _ = self.witness("node", node["low"])
                    assignment = low["assignment"]
                    if assignment is None:
                        high, _ = self.witness("node", node["high"])
                        assignment = high["assignment"]
                        if assignment is not None:
                            assignment |= 1 << node["variable"]
                if assignment is not None:
                    require(assignment & ~info["support"] == 0, "node witness outside support")
            if assignment is not None:
                nat(assignment, "witness assignment", MASK_LIMIT)
            return {"assignment": assignment, "cache_hit": False, "prior": None}
        outputs, work = self.t.request("witness", inputs, body)
        if target_kind == "node" and not outputs["cache_hit"]:
            require(normalized not in self.witness_cache, "witness cache overwrite")
            self.witness_cache[normalized] = (outputs["assignment"], work)
        return outputs, work

    def evaluate(self, target_kind, target, assignment):
        normalized = tuple(target) if target_kind == "view" else target
        key = normalized, assignment
        inputs = {"target_kind": target_kind,
                  "target": list(normalized) if target_kind == "view" else normalized,
                  "assignment": assignment}
        def body(ticket):
            nat(assignment, "full evaluation assignment", MASK_LIMIT)
            if target_kind == "view":
                view(normalized)
            else:
                require(target_kind == "node", "evaluation target kind")
                nat(normalized, "evaluation node")
            if target_kind == "node" and key in self.eval_cache:
                self.t.hits["evaluate"] += 1
                value, prior = self.eval_cache[key]
                ticket.explicit.append(prior)
                return {"value": value, "cache_hit": True, "prior": prior}
            if target_kind == "view":
                positive, negative, core = normalized
                _, validated = self.checked(core)
                ticket.explicit.append(validated)
                self.view_support(normalized)
                if assignment & positive != positive or assignment & negative:
                    value = 0
                else:
                    child, _ = self.evaluate("node", core, assignment)
                    value = child["value"]
            else:
                self.t.misses["evaluate"] += 1
                _, validated = self.checked(normalized)
                ticket.explicit.append(validated)
                node = self.src.node(normalized)
                if node["kind"] == "constant":
                    value = node["value"]
                elif node["kind"] == "guard":
                    if assignment & node["positive"] != node["positive"] or assignment & node["negative"]:
                        value = 0
                    else:
                        child, _ = self.evaluate("node", node["core"], assignment)
                        value = child["value"]
                else:
                    selected = node["high"] if (assignment >> node["variable"]) & 1 else node["low"]
                    child, _ = self.evaluate("node", selected, assignment)
                    value = child["value"]
            nat(value, "evaluated Nat")
            return {"value": value, "cache_hit": False, "prior": None}
        outputs, work = self.t.request("evaluate", inputs, body)
        if target_kind == "node" and not outputs["cache_hit"]:
            require(key not in self.eval_cache, "evaluation cache overwrite")
            self.eval_cache[key] = (outputs["value"], work)
        return outputs, work

    def local(self, kind, inputs, outputs, dependencies):
        def body(ticket):
            ticket.explicit.extend(dependencies)
            return outputs() if callable(outputs) else outputs
        return self.t.request(kind, inputs, body)

    def pool(self, side, source_index, witness_result, witness_work):
        def outputs():
            assignment = witness_result["assignment"]
            seen = self.pool_seen[side]
            if assignment is None:
                status, row = "absent", None
            elif assignment in seen:
                status, row = "duplicate", seen[assignment]
            else:
                status, row = "new", len(seen)
            return {"assignment": assignment, "row": row, "status": status}
        result, work = self.local("pool", {"side": side, "source_index": source_index,
                                           "witness_work": witness_work}, outputs, [witness_work])
        self.sides[side]["source_attempts"].append({"source_index": source_index,
                                                    "witness_work": witness_work, "pool_work": work})
        if result["status"] == "new":
            self.pool_seen[side][result["assignment"]] = result["row"]
        return result

    def sample_row(self, side, source_index, assignment, row):
        self.t.stage = "evaluate_" + side
        sources = self.b_views if side == "B" else self.a_views
        evaluations = [self.evaluate("view", v, assignment) for v in sources]
        values, origins = [0] * COLUMNS, [None] * COLUMNS
        if side == "B":
            values = [result["value"] for result, _ in evaluations]
            origins = [work for _, work in evaluations]
        else:
            for occurrence, incidence in enumerate(self.occurrences):
                group = incidence["b_index"]
                result, evaluation_work = evaluations[incidence["a_index"]]
                value = result["value"]
                dependencies = [evaluation_work]
                if origins[group] is not None:
                    dependencies.append(origins[group])
                inputs = {"row": row, "group": group, "occurrence": occurrence,
                          "before": values[group], "value": value, "evaluation_work": evaluation_work}
                after, work = self.local("group_add", inputs, lambda: {"after": values[group] + value}, dependencies)
                values[group], origins[group] = after["after"], work
        parity = []
        for column, value in enumerate(values):
            self.scope["column"] = column
            require(origins[column] is not None, "empty group in sampled row")
            result, work = self.local("parity", {"side": side, "row": row, "column": column,
                                                  "value": value}, lambda: {"bit": value % 2}, [origins[column]])
            parity.append((result["bit"], work))
            if side == "A" and value > 1:
                self.nonunits.append({"row": row, "assignment": assignment, "group": column,
                                      "value": value, "outside_compatibility_checked": False})
        packed, origin = 0, None
        self.t.stage = "rank_" + side
        for column, (bit, parity_work) in enumerate(parity):
            self.scope["column"] = column
            dependencies = [parity_work] + ([] if origin is None else [origin])
            result, origin = self.local("row_pack", {"side": side, "row": row, "column": column,
                                                       "before": packed, "bit": bit},
                                        lambda: {"after": packed | (bit << column)}, dependencies)
            packed = result["after"]
            nat(packed, "packed parity row", ROW_LIMIT)
        sample = {"row": row, "assignment": assignment, "source_index": source_index,
                  "nat_values": values, "parity_word": packed}
        equal(row, len(self.sides[side]["sample_rows"]), "sample row index")
        self.sides[side]["sample_rows"].append(sample)
        self.eliminate(side, row, packed, origin)

    def eliminate(self, side, row, word, origin):
        self.t.stage = "rank_" + side
        basis = self.bases[side]
        for column in range(COLUMNS):
            self.scope["column"] = column
            entry = basis.get(column)
            basis_row = None if entry is None else entry[1]
            dependencies = [origin] + ([] if entry is None else [entry[2]])
            probe, probe_work = self.local("pivot_probe", {"side": side, "row": row,
                                                            "column": column, "word": word},
                                           lambda: {"bit": (word >> column) & 1, "basis_row": basis_row}, dependencies)
            if probe["bit"] == 0:
                origin = probe_work
                continue
            if entry is not None:
                basis_word, basis_row, insertion = entry
                result, origin = self.local("row_xor", {"side": side, "row": row, "pivot": column,
                                                          "before": word, "basis_row": basis_row,
                                                          "basis_word": basis_word},
                                             lambda: {"after": word ^ basis_word}, [probe_work, insertion, origin])
                word = result["after"]
                nat(word, "reduced parity row", ROW_LIMIT)
                continue
            def insertion_result():
                require(word & ((1 << column) - 1) == 0 and (word >> column) & 1,
                        "invalid echelon insertion")
                return {"rank": len(basis) + 1}
            result, insertion = self.local("rank_update", {"side": side, "row": row,
                                                              "action": "insert", "pivot": column,
                                                              "word": word},
                                              insertion_result, [probe_work])
            basis[column] = (word, row, insertion)
            state = self.sides[side]
            state["rank"] = result["rank"]
            state["selected_original_row_ids"].append(row)
            state["minor_row_words"].append(state["sample_rows"][row]["parity_word"])
            return
        def zero_result():
            require(word == 0, "all probes completed with nonzero row")
            return {"rank": len(basis)}
        result, _ = self.local("rank_update", {"side": side, "row": row, "action": "zero",
                                                 "pivot": None, "word": word},
                                zero_result, [origin])
        self.sides[side]["rank"] = result["rank"]

    def side(self, side):
        state = self.sides[side]
        state["status"] = "in_progress"
        sources = self.b_views if side == "B" else self.a_views
        for source_index, source in enumerate(sources):
            require(state["rank"] < COLUMNS, "sampling after full rank")
            self.scope = {"phase": "side", "side": side, "source_index": source_index}
            self.t.stage = "witness_" + side
            result, witness_work = self.witness("view", source)
            pool = self.pool(side, source_index, result, witness_work)
            if pool["status"] == "new":
                self.scope["row"] = pool["row"]
                self.sample_row(side, source_index, pool["assignment"], pool["row"])
                if state["rank"] == COLUMNS:
                    state["status"] = "full_rank"
                    return
        state["status"] = "pool_exhausted"

    def run_policy(self):
        self.t.stage = "validate"
        self.initial["A"] = self.validate(ROOT_A)
        self.initial["B"] = self.validate(ROOT_B)
        self.initial["zero"] = self.validate(0)
        self.check_partition()
        self.scope = {"phase": "restrict"}
        for choice in range(128):
            self.scope["choice"] = choice
            self.t.stage = "restrict"
            result, work = self.cut_case(choice)
            if result["disposition"] == "retained":
                self.t.stage = "group"
                self.group(choice, result, work)
        self.t.stage = "group"
        self.scope = {"phase": "group"}
        for pair, multiplicity in self.pair_occurrences.items():
            self.compare_pair(pair, multiplicity)
        self.complete_grouping()
        self.side("B")
        self.side("A")
        self.complete = True
        self.scope = {"phase": "complete"}

    def grouping(self):
        return {"choices": self.case_count, "zero_choices": self.zero_choices,
                "retained_occurrences": len(self.occurrences),
                "a_views": [list(v) for v in self.a_views], "b_views": [list(v) for v in self.b_views],
                "occurrences": self.occurrences, "b_degrees": self.b_degrees,
                "saved_pair_multiset_matches": self.group_match,
                "x": self.partition["x"] if self.partition else 0,
                "y": self.partition["y"] if self.partition else 0}


def check_header(source, transcript):
    h = transcript.header
    require(set(h) == {"type", "schema", "input_bindings", "roots", "interval", "variable_limit",
                       "work_cap", "limits", "policy_sha256", "schema_sha256"}, "header fields")
    for key, value in {"type": "header", "schema": SCHEMA, "roots": {"A": ROOT_A, "B": ROOT_B},
                       "interval": [START, STOP], "variable_limit": VARIABLES, "work_cap": CAP,
                       "policy_sha256": POLICY_SHA, "schema_sha256": SCHEMA_SHA,
                       "limits": {"wall_seconds": 30, "cpu_seconds": 30, "cpu_count": 1,
                                  "address_space_bytes": 1073741824}}.items():
        equal(h[key], value, "header " + key)
    inputs = h["input_bindings"]
    require(type(inputs) is dict and set(inputs) == {"trace", "assessment", "preparation_seconds",
            "parsed_records", "indexed_node_ids", "semantic_node_processing_during_preparation"},
            "header input-binding fields")
    for role, binding in (("trace", source.trace_binding), ("assessment", source.assessment_binding)):
        value = inputs[role]
        require(type(value) is dict and set(value) == {"path", "bytes", "sha256"}, "input binding shape")
        require(type(value["path"]) is str and value["path"], "input historical path")
        equal(value["sha256"], binding["sha256"], role + " hash")
        equal(value["bytes"], binding["bytes"], role + " size")
    equal(inputs["parsed_records"], source.parsed_records, "parsed source record count")
    equal(inputs["indexed_node_ids"], len(source.nodes), "raw source ID count")
    equal(inputs["semantic_node_processing_during_preparation"], False, "preparation declaration")
    seconds = inputs["preparation_seconds"]
    require(type(seconds) in (int, float) and math.isfinite(seconds) and seconds >= 0,
            "preparation time metadata")


def check_footer(audit, footer, observed_stop):
    t = audit.t
    error = footer.get("type") == "error"
    fields = {"type", "status", "charged", "completed", "pending", "work_kinds", "cache_hits",
              "cache_misses", "grouping", "sides", "sampled_nonunit_groups", "physical_records", "scope"}
    if error:
        fields |= {"exception_type", "message"}
    require(set(footer) == fields, "footer fields")
    expected = {"charged": t.starts, "completed": len(t.finished),
                "pending": [ticket.id for ticket in t.stack],
                "work_kinds": {kind: t.kinds[kind] for kind in KINDS},
                "cache_hits": {kind: t.hits[kind] for kind in ("validate", "witness", "evaluate")},
                "cache_misses": {kind: t.misses[kind] for kind in ("validate", "witness", "evaluate")},
                "grouping": audit.grouping(), "sides": audit.sides,
                "sampled_nonunit_groups": audit.nonunits, "physical_records": t.physical,
                "scope": audit.scope}
    for key, value in expected.items():
        equal(footer[key], value, "footer " + key)
    require(t.starts <= CAP and len(t.finished) <= t.starts, "work cap accounting")
    status = footer["status"]
    if error:
        require(observed_stop and not audit.complete, "error after complete fixed policy")
        require(type(footer["exception_type"]) is str and type(footer["message"]) is str,
                "error metadata types")
        if status == "capped_prefix_only_no_combined_rank_conclusion":
            equal(t.starts, CAP, "cap footer starts")
            equal(footer["exception_type"], "LimitReached", "cap exception")
            equal(footer["message"], "charged work cap 50000 reached before next request", "cap message")
            equal(t.observation_point, "before_request", "cap rejected before any new request")
            qualification = "checked_capped_prefix_only_no_combined_rank_conclusion"
        elif status == "fixture_binding_rejected":
            require(audit.fixture_failed, "unverified fixture-rejection cause")
            equal(footer["exception_type"], "FixtureRejected", "fixture exception")
            qualification = "checked_fixture_rejection_no_rank_conclusion"
        elif status == "process_interrupted_or_failed":
            qualification = "checked_recorded_prefix_only_no_rank_conclusion"
        else:
            raise Rejected("unrecognized error footer status")
    else:
        equal(footer["type"], "result", "result footer type")
        require(audit.complete and not observed_stop and not t.stack, "incomplete success footer")
        require(audit.group_match and audit.case_count == 128 and t.kinds["cofactor"] == 1792,
                "success without complete cut and group coverage")
        full = audit.ranks() == {"A": 35, "B": 35}
        equal(status, "full_rank_exclusion_for_grouped_cut" if full else "inconclusive_sampled_rank",
              "reconstructed final status")
        qualification = ("checked_full_rank_exclusion_diagnostic_not_Lean" if full
                         else "checked_complete_fixed_probe_inconclusive")
    t.at_end()
    return qualification


def replay(args):
    source = Source(args.trace, args.assessment)
    transcript = Transcript(args.certificate)
    check_header(source, transcript)
    audit = Audit(source, transcript)
    observed_stop = False
    try:
        audit.run_policy()
        transcript.observation_point = "after_policy"
        footer = transcript.semantic_record()
    except ObservedFooter as stop:
        footer, observed_stop = stop.record, True
    except FixtureFailure:
        observed_stop = True
        transcript.observation_point = "after_fixture_failure"
        try:
            footer = transcript.semantic_record()
        except ObservedFooter as stop:
            footer = stop.record
    qualification = check_footer(audit, footer, observed_stop)
    return {"status": "passed", "kind": "independent_cut_rank_scalar_v2_replay",
            "qualification": qualification, "producer_status": footer["status"],
            "source_trace": source.trace_binding, "saved_assessment": source.assessment_binding,
            "certificate": file_binding(args.certificate), "schema_sha256": SCHEMA_SHA,
            "policy_sha256": POLICY_SHA, "charged_starts": transcript.starts,
            "completed_requests": len(transcript.finished),
            "pending_requests": [ticket.id for ticket in transcript.stack],
            "physical_records": transcript.physical, "work_kinds": footer["work_kinds"],
            "cache_hits": footer["cache_hits"], "cache_misses": footer["cache_misses"],
            "root_lineage": {"A": ROOT_A, "B": ROOT_B}, "interval": [START, STOP],
            "grouping_complete": audit.group_match, "grouping": audit.grouping(),
            "sides": audit.sides, "sampled_nonunit_groups": audit.nonunits,
            "extra_evaluation_samples": 0, "unrecorded_semantic_requests": 0,
            "independent_imports": "Python standard library only; no producer or evaluator imports",
            "formal_status": "Python diagnostic replay only; no Lean rank theorem or source-count claim",
            "outside_factor_compatibility_checked": False,
            "scope_limit": "Only the fixed retained intermediate function and its designated partition"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--assessment", type=Path, required=True)
    parser.add_argument("--certificate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "refusing to overwrite replay report")
    started = time.monotonic()
    code = 0
    try:
        result = replay(args)
    except Exception as exc:
        result = {"status": "rejected", "kind": "independent_cut_rank_scalar_v2_replay",
                  "exception_type": type(exc).__name__, "message": str(exc),
                  "formal_status": "No rank or count conclusion from rejected replay"}
        code = 1
    result["elapsed_seconds"] = time.monotonic() - started
    result["replayer"] = file_binding(Path(__file__).resolve())
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "qualification": result.get("qualification"),
                      "charged_starts": result.get("charged_starts"),
                      "completed_requests": result.get("completed_requests"),
                      "message": result.get("message")}, sort_keys=True))
    return code


if __name__ == "__main__":
    sys.exit(main())
