# Exact cut reconstruction and fixed scalar rank probe

Status: the single prescribed producer run and its independent replay completed successfully. The rank experiment is **inconclusive**. It does not prove a smaller exact representation, optimality of the 35-term grouping, a Lean rank theorem, or a new queen count.

The source-bound diagnostic reconstructs all 128 assignments to variables153 through159 of original guarded ADD roots 25319 and 42351. It preserves their original A/B lineage, removes 67 certified-zero products, retains all 61 surviving occurrences, and groups by 35 exactly identical B views. The independently checked fixed sample has rank 35 on A and rank 19 on B. The B witness policy supplies only 19 distinct assignments, so rank 19 is not a proof of function-space dimension 19.

Read `RESULTS.md` for measurements and limitations. `DESIGN.md`, `schema.json` and `PROTOCOL.md` specify the fixed experiment; `IMPLEMENTATION.md`, `producer-evidence.json`, `replay/preparation-evidence.json` and `review/` preserve source and control review. The complete producer transcript and independent replay are in `attempts/cut-rank-01` and `attempts/cut-rank-replay-01`. Source drafts, corrections and runner provenance remain in `origin/`, `replay/origin/` and `runner-origin/`.

The separate generic Lean regrouping law is preserved in `../block-grouping-laws`. Its fresh check establishes multiplicity-preserving algebra under an explicit coverage premise; it does not discharge this concrete trace's coverage or establish its ranks. No frozen prior experiment or integrated chapter source was changed.
