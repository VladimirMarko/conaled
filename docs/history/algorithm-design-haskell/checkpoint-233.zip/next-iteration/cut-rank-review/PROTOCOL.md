# Exact transcript protocol for scalar-v2

This refines execution order and field interpretation without changing the fixed DESIGN/schema policy. No execution has occurred.

## Work tickets and dependencies

A `work` record is written before the local body or any recursive child request. IDs are consecutive from0. Each request is pushed on a stack. `done` must finish the top request exactly once. Its `dependencies` are **explicit earlier input/cache references first, followed by direct nested child completion IDs in call order**. Duplicate references are retained. All referenced results must already have `done` records, independently of numeric start-ID order. Finishing a child appends its ID to its direct parent's child list.

Validation, witness and evaluation cache entries are published only after completion. Cache hits are charged requests with explicit dependency `[prior]` on the first completed cache entry. Footer hit/miss counters cover only cacheable node requests; view wrappers are neither cache hits nor cache misses. A virtual-view wrapper is never cached. Completed results of any kind may be reused through their exact explicit references; no semantic value is read from an unfinished request.

On request50001, reject before assigning an ID, writing a start or doing work. The footer lists the exact active stack; it may be empty if exhaustion occurs between requests. An incomplete logical row may have completed input operations without yet appearing in `sample_rows`. `scope` records the current phase/side/source/row/column when available; it is diagnostic position metadata, not a completed mathematical claim.

## Views, validation and zero

A view is the JSON list `[positive, negative, bare_core]`. The canonical zero view is `[0,0,0]`; node0 must independently validate as constant0. A node validation returns its derived support and flat view. Constants and branches have flat view `[0,0,id]`; guard nodes return their literal masks and actual bare core ID. Guard cores must not be guards. Selected definitions must be unique, children earlier, variables/masks within210bits, branch ordering strict, guard masks nonempty/nonconflicting, and literal support disjoint from the core. `maximum` is ignored.

The parser merely indexes raw source node records by ID and retains all duplicates. The charged validator rejects missing or duplicate selected definitions. The initial requests are `validate(25319)`, `validate(42351)`, `validate(0)`, in that order. Each miss recursively validates low then high, or guard core. It records those direct child dependencies. A hit records only its prior cached validation ID.

Later local operations may read the existing validation cache directly, without rerunning a semantic helper, while charged for that bounded local operation. They explicitly reference the first completed validation ID for the entries used. Supports are bitmasks, not untrusted trace annotations. The charged partition request references the three initial validation results and checks the fixed interval and X/Y masks.

## Restriction and incidence order

For each choice0..127, begin one `cut_case` request. Its explicit dependencies are the initial A/B validation result IDs. Within it, at each v=153..159, call A cofactor then B cofactor. The14 direct children occur in that exact order. Each request receives the full current view as an input.

A cofactor's explicit dependencies begin with the first cached validation result for its bare core and the explicit initial `validate(0)` request result (even if that initial request was itself a cache hit). For a branch step, append the validation result for its selected original child. There are no nested work requests. It checks that no support variable lies below v; then applies the zero, guard literal, absent, or branch rule. Branch merging ORs the two positive and two negative masks, returns zero on a conflict, otherwise requires disjointness from the new bare core support. Derive that core support from the selected child's checked support by removing its checked flat guard masks; do not make an unreferenced extra validation-cache read. The result support is derived within the charged local cofactor and passed to its enclosing cut case without another descriptor traversal. Guard-removal output is still a symbolic view; a new source node is never allocated. A zero result always canonicalizes to `[0,0,0]`.

On finishing each cut case, immediately emit one group request if retained. Its explicit dependency is that cut case. A/B IDs are first-occurrence IDs, using the full view tuple as exact identity. Record one incidence per retained choice. Canonical pair keys used for old-data comparison sort only the two complete views; they do not change A/B lineage.

After all128 cases, visit distinct canonical pair keys in first-occurrence order. Each `pair_check` explicitly references all group requests contributing to that pair, in choice order; compare exact multiplicity with the saved assessment. Then one `group_complete` request references the partition result, all128 cut results, all group results and all pair-check results in their respective creation order. Its checks use already maintained counts/flags/degrees; no new descriptor or function traversal occurs. The fixed fixture is rejected if the support,61/35,67/61, multiplicity, degree or saved-pair checks differ.

## Witness/evaluation request semantics

Within a side, visit source views in first-occurrence order. Call `witness` on the view, then a `pool` request. Pool references that witness result and logs absent/duplicate/new; duplicates compare exact full assignments. Cache witness results for source node IDs only. A view wrapper references its core validation and calls the bare core witness. Node misses reference their own validation and visit false child first; only a no-witness result permits visiting true. A guard visits its core once. Constants use their actual Nat value, with0 absent and a positive value returning assignment0. A true branch sets its variable; a guard sets its positive bits. Derived support ensures no conflict. All other bits remain false.

An `evaluate` node miss explicitly references its validation and calls only the selected branch child or a satisfied guard's core. A failed guard returns0 without a core call. Constants return their exact value. A view wrapper references its core validation, checks its masks and, if satisfied, calls its bare core. Node cache key is `(source_node_id, full_assignment)`; hits explicitly reference the first completed result. View wrappers remain uncached.

## Per-row schedule

Process B before A. After each new B pool assignment, evaluate all35 B views in column order, then perform all35 parity conversions, followed by all35 row-pack steps and elimination. After each new A pool assignment, evaluate all61 A views in A-index order; perform one Nat `group_add` per incidence in increasing choice order; convert the35 completed group sums to parity; pack and eliminate the row. No later witness is requested until the current row finishes. Stop a side immediately when rank35 is reached, otherwise exhaust its fixed sources.

A group addition explicitly references the relevant A-view evaluation and the previous addition to that group if any. It retains the zero-based incidence occurrence index. A parity request references the final group addition (A) or view evaluation (B). A row-pack request references its parity result and its preceding pack step if any. Packing starts at0 and visits columns0..34. `sample_rows` stores35 exact Nat matrix entries and the fully packed parity word, only after packing completes.

For each parity conversion on A, a Nat group value>1 may also be copied to `sampled_nonunit_groups`; this uses the already computed value and requests no new assignment or evaluation. Outside compatibility remains false/unchecked. On a cap stop these completed scalar observations may refer to a row whose packing never finished; they are not completed-row or rank claims.

## Elimination and minors

Start each row with the last packing result as current-word origin. For columns0..34, charge `pivot_probe` with dependencies on that origin and the prior basis insertion at that column if present. Bit0 advances with the probe as the new unchanged-word origin. Bit1 with a basis triggers `row_xor`, whose dependencies are the probe, basis insertion and previous word origin, in that order; its result becomes the origin. Bit1 without a basis triggers `rank_update(insert)` referencing the probe and installs that current word with the original row ID. It finishes the row. After all columns reduce to0, `rank_update(zero)` references the final current-word origin and finishes the row.

Rank is the number of inserted basis rows. Original sample row IDs selected by insertion are retained in insertion order. `minor_row_words` are the **original** sample words for those IDs, not the reduced basis words. All words are below2^35. The recorded elementary elimination proves their independence; no additional Gaussian pass or unrecorded inverse construction is allowed.

## Summary data and qualifications

`grouping.choices` and `retained_occurrences` are counts; `zero_choices` is the list of source choice integers; `a_views`, `b_views`, `occurrences`, and `b_degrees` retain the full small incidence data. `sample_rows` and `source_attempts` are lists. Pending or not-started side status is distinct from `full_rank` and `pool_exhausted`. A cap can retain completed individual rank facts but never produces the combined full-rank status unless the whole fixed procedure completes normally.

Checkpoints are optional metadata at completed phases, never a new semantic operation or a substitute for work records. An eventual report must disclose charged starts, completed requests, pending requests, physical JSON records and kind/cache distributions. No source count field is emitted. A complete sampled deficiency remains inconclusive. All source/control files require final review before the one proposed diagnostic and independent replay.
