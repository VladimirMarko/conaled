# Scalar probe implementation boundary

The fixed design is implemented in `diagnostics/probe_cut_rank.py`. As of this record, the source has been parsed with Python's AST parser only. It has not been imported or executed, and no rank, witness assignment, contraction or count has been computed by the new source.

The producer is original code for the fixed retained fixture. Its prior initial draft and exact static-review patch are preserved in `origin/`. The patch removes an extra cofactor validation-cache read: the selected child's checked support and flat guard determine its bare-core support directly. The cofactor derives its result support during the charged request and passes that result to the enclosing cut case. It does not traverse the resulting core a second time without an explicit dependency.

The schema/design first draft, the amendment introducing explicit partition/pair/group-binding requests, and the protocol clarifications are preserved byte-for-byte with their differences. These are pre-execution preparation histories, not failed counter attempts.

## Ownership

- This agent owns the design, protocol, producer and implementation evidence.
- The parent owns the new bounded runner and its exact prior controls/differences.
- The residual-rules agent owns the separately written `replay/` implementation and its provenance.
- The runtime-evidence agent owns the independent design/source/control review under `review/`.

No independent replayer imports this producer. All code paths and the complete bounded controls require final review before execution.

## Actual work accounting

`Meter.begin` increments the single counter and writes/flushed the start before the local operation or recursive calls. Request50001 raises before assigning an ID or performing work. `Meter.finish` requires the active nested frame, verifies that every dependency has already completed, writes the result, and only then exposes the result for later use. Cached validation, witness and scalar-evaluation entries are installed after completion. Cache hits are charged; uncached view wrappers are charged separately.

The parser is intentionally shallow. It hashes the exact files and indexes raw node records, keeping duplicate entries for rejection on selected access. It computes no whole-table support, flattened view, witness or value. Only the charged validation requests follow root ancestors.

The two-source restriction is explicit:128 choices, seven variables, A then B at each variable. It neither skips the rest of a choice after zero nor confuses even values with zero. Grouping records every surviving choice. The source views and copied saved assessment are compared after preserving root lineage.

The deterministic B-then-A schedule requests one positive witness per fixed source view and deduplicates only exact assignments. Every accepted sample is evaluated using actual constant leaves. Grouped A values are natural sums of all original incidence occurrences; reduction modulo2 occurs afterward. Every addition, parity conversion, row insertion, pivot probe, row XOR and rank update is individually charged. There is no new packed-lane evaluator, nullspace-guided sample search, second prime or retry policy.

Matrix rows remain35-bit words. Basis rows preserve an explicit chain from the original packed sample, through every probe/XOR, to insertion. The selected minor contains the original sample rows, not the reduced basis numerals. Full-rank status requires both sides and normal completion of the fixed procedure.

On a cap stop, completed scalar group values may refer to a sample whose row packing or elimination did not finish. They are retained as scalar observations only. They do not establish source extendibility, a completed row, a complete contraction or a count.

## Trust and outcome scope

The input's existing arithmetic claims are not re-proved by this diagnostic. The selected guarded descriptors are interpreted directly, with charged structural validation. The new result concerns their designated cut. A later Lean use would require the generic descriptor/restriction/evaluation/rank theorems and the complete source/factor connection.

The new analysis budget and the historical counter's49,194 pre-cut operations are reported separately. The producer never claims that their sum fits a50,000-claim counting certificate. The outputs contain no queens count and use no expected count as a premise.

The proposed producer command is:

```text
python3 diagnostics/probe_cut_rank.py --trace <frozen guarded.jsonl> --assessment <frozen assessment.json> --output <new work.jsonl>
```

This documents the interface; it is not an instruction to bypass the bounded runner or the pending source/control review.
