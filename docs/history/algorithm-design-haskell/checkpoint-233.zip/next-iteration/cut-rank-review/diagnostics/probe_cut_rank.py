#!/usr/bin/env python3
"""One fixed, fully metered scalar probe of an existing guarded cut.

No new ADD node, contraction, whole-board count, or fallback is constructed.
This program is an untrusted diagnostic producer, not a mathematical premise.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sys
import time


SCHEMA = "cut-rank-scalar-v2"
CAP = 50_000
VARIABLES = 210
START, STOP = 153, 160
ROOT_A, ROOT_B = 25319, 42351
ZERO = (0, 0, 0)
X = [172, 173, 176, 178, 179, 180, 181, 182, 183, 184, 185, 198]
Y = [171, 174, 175, 177, 186, 187, 189, 191, 192, 193, 195, 200, 202, 203, 206, 208]
SOURCE_SHA = "6d45c84df36797ed12e8b7f842e18f3b5c25e6b34b0742dd416dd0ba1842a0ea"
KINDS = ["validate", "partition", "cofactor", "cut_case", "group", "pair_check",
         "group_complete", "witness", "pool", "evaluate", "group_add", "parity",
         "row_pack", "pivot_probe", "row_xor", "rank_update"]


class LimitReached(RuntimeError):
    pass


class FixtureRejected(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise FixtureRejected(message)


def natural(value):
    require(type(value) is int and value >= 0, "expected a natural number")
    return value


def binding(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


class Meter:
    def __init__(self, stream):
        self.stream = stream
        self.charged = 0
        self.completed = 0
        self.physical = 0
        self.stack = []
        self.done_ids = set()
        self.kind_counts = {k: 0 for k in KINDS}
        self.hits = {k: 0 for k in ("validate", "witness", "evaluate")}
        self.misses = dict.fromkeys(self.hits, 0)
        self.scope = {"phase": "validate"}

    def write(self, obj):
        self.stream.write(json.dumps(obj, separators=(",", ":")) + "\n")
        self.stream.flush()
        self.physical += 1

    def begin(self, stage, kind, inputs):
        if self.charged == CAP:
            raise LimitReached("charged work cap 50000 reached before next request")
        require(kind in self.kind_counts, "unknown work kind")
        ticket = self.charged
        self.charged += 1
        self.kind_counts[kind] += 1
        self.stack.append({"id": ticket, "children": []})
        self.write({"type": "work", "id": ticket, "stage": stage, "kind": kind, "inputs": inputs})
        return ticket

    def finish(self, ticket, outputs, explicit=()):
        require(self.stack and self.stack[-1]["id"] == ticket, "non-nested completion")
        frame = self.stack[-1]
        dependencies = list(explicit) + frame["children"]
        require(all(i in self.done_ids for i in dependencies), "unfinished dependency")
        self.write({"type": "done", "id": ticket, "dependencies": dependencies, "outputs": outputs})
        self.stack.pop()
        self.done_ids.add(ticket)
        self.completed += 1
        if self.stack:
            self.stack[-1]["children"].append(ticket)
        return ticket

    def cache(self, kind, hit):
        (self.hits if hit else self.misses)[kind] += 1


def prepare(trace_path, assessment_path):
    """Byte/index preparation only: no support, flattening or node evaluation."""
    start = time.monotonic()
    tb, ab = binding(trace_path), binding(assessment_path)
    require(tb["sha256"] == SOURCE_SHA, "source trace hash differs")
    raw_nodes = defaultdict(list)
    input_records = 0
    with trace_path.open() as stream:
        for line in stream:
            record = json.loads(line)
            input_records += 1
            if record.get("type") == "node":
                raw_nodes[record.get("id")].append(record)
    assessment = json.loads(assessment_path.read_text())
    candidates = [r for r in assessment["symbolic_pair_traversals"]
                  if r["start"] == START and r["stop"] == STOP]
    require(len(candidates) == 1, "ambiguous saved cut")
    saved = candidates[0]
    old_pairs = defaultdict(list)
    for row in saved["leaf_product_pairs"]:
        key = (tuple(row["left"]), tuple(row["right"]))
        old_pairs[key].append(row)
    return raw_nodes, saved, old_pairs, {
        "trace": tb, "assessment": ab, "preparation_seconds": time.monotonic() - start,
        "parsed_records": input_records, "indexed_node_ids": len(raw_nodes),
        "semantic_node_processing_during_preparation": False}


class Probe:
    def __init__(self, meter, raw, saved, old_pairs):
        self.m = meter
        self.raw, self.saved, self.old_pairs = raw, saved, old_pairs
        self.valid = {}
        self.witness_cache = {}
        self.eval_cache = {}
        self.initial = {}
        self.partition_id = None
        self.cut_ids, self.group_ids, self.pair_ids = [], [], []
        self.a_views, self.b_views = [], []
        self.a_index, self.b_index = {}, {}
        self.occurrences = []
        self.pairs = {}
        self.pair_group_ids = defaultdict(list)
        self.zero_choices = []
        self.b_degrees = []
        self.degree_hist = Counter()
        self.x = self.y = 0
        self.binding_complete = False
        self.sampled_nonunit = []
        self.sides = {s: {"sample_rows": [], "source_attempts": [], "rank": 0,
                          "selected_original_row_ids": [], "minor_row_words": [],
                          "status": "not_started"} for s in ("A", "B")}
        self.bases = {s: {} for s in self.sides}
        self.pool_seen = {s: {} for s in self.sides}

    def info(self, node):
        require(node in self.valid, "unvalidated source read")
        return self.valid[node]

    def record(self, node):
        records = self.raw.get(node, [])
        require(len(records) == 1, "missing or duplicate selected definition")
        return records[0]

    def validate(self, node):
        t = self.m.begin("validate", "validate", {"node": node})
        natural(node)
        if node in self.valid:
            info, prior = self.valid[node]
            self.m.cache("validate", True)
            self.m.finish(t, {"cache_hit": True, "prior": prior, **info}, [prior])
            return info, t
        self.m.cache("validate", False)
        r = self.record(node)
        require(r.get("type") == "node" and natural(r["id"]) == node, "wrong source node")
        kind = r["kind"]
        if kind == "constant":
            natural(r["value"])
            support, flat = 0, [0, 0, node]
        elif kind == "ite":
            v, low, high = natural(r["variable"]), natural(r["low"]), natural(r["high"])
            require(v < VARIABLES and low < node and high < node, "branch bound/order")
            li, _ = self.validate(low)
            hi, _ = self.validate(high)
            child_support = li["support"] | hi["support"]
            require(child_support & ((1 << (v + 1)) - 1) == 0, "branch variable order")
            support, flat = (1 << v) | child_support, [0, 0, node]
        elif kind == "guard":
            p, n, core = natural(r["positive"]), natural(r["negative"]), natural(r["core"])
            require(p < 1 << VARIABLES and n < 1 << VARIABLES and core < node, "guard bounds")
            require(p | n and p & n == 0, "empty/conflicting guard")
            ci, _ = self.validate(core)
            require(ci["node_kind"] != "guard" and (p | n) & ci["support"] == 0,
                    "guard/core structure")
            support, flat = p | n | ci["support"], [p, n, core]
        else:
            raise FixtureRejected("unsupported node kind")
        info = {"node_kind": kind, "support": support, "flat": flat}
        self.m.finish(t, {"cache_hit": False, "prior": None, **info})
        self.valid[node] = (info, t)
        return info, t

    def partition(self):
        t = self.m.begin("validate", "partition",
                         {"a_root": ROOT_A, "b_root": ROOT_B, "start": START, "stop": STOP})
        ai, _ = self.info(ROOT_A)
        bi, _ = self.info(ROOT_B)
        zi, _ = self.info(0)
        require(zi["node_kind"] == "constant" and self.record(0)["value"] == 0, "node0 is not zero")
        block = ((1 << (STOP - START)) - 1) << START
        self.x, self.y = ai["support"] & ~block, bi["support"] & ~block
        matches = (self.x == sum(1 << v for v in X) and self.y == sum(1 << v for v in Y)
                   and ai["support"] & bi["support"] == block and self.x & self.y == 0
                   and ai["support"] == self.x | block and bi["support"] == self.y | block)
        self.m.finish(t, {"x": self.x, "y": self.y, "matches": matches},
                      [self.initial["A"], self.initial["B"], self.initial["zero"]])
        require(matches, "partition does not match fixed cut")
        self.partition_id = t

    def cofactor(self, view, v, bit):
        t = self.m.begin("restrict", "cofactor", {"view": list(view), "variable": v, "bit": bit})
        p, n, core = view
        ci, validation = self.info(core)
        deps = [validation, self.initial["zero"]]
        support = p | n | ci["support"]
        require(support & ((1 << v) - 1) == 0 and p & n == 0
                and (p | n) & ci["support"] == 0, "invalid view cofactor")
        mark = 1 << v
        if view == ZERO:
            rule, result, result_support = "zero", ZERO, 0
        elif p & mark:
            rule = "guard_true" if bit else "guard_false"
            result = (p ^ mark, n, core) if bit else ZERO
            result_support = support ^ mark if bit else 0
        elif n & mark:
            rule = "guard_false" if bit else "guard_true"
            result = ZERO if bit else (p, n ^ mark, core)
            result_support = 0 if bit else support ^ mark
        elif not support & mark:
            rule, result, result_support = "absent", view, support
        else:
            r = self.record(core)
            require(r["kind"] == "ite" and r["variable"] == v, "cofactor branch mismatch")
            child = r["high"] if bit else r["low"]
            ch, cv = self.info(child)
            deps.append(cv)
            cp, cn, cc = ch["flat"]
            pp, nn = p | cp, n | cn
            if tuple(ch["flat"]) == ZERO or pp & nn:
                result, result_support = ZERO, 0
            else:
                cc_support = ch["support"] & ~(cp | cn)
                require((pp | nn) & cc_support == 0, "cofactor merged support")
                result, result_support = (pp, nn, cc), pp | nn | cc_support
            rule = "branch"
        self.m.finish(t, {"rule": rule, "result": list(result)}, deps)
        return result, t, result_support

    def cut_case(self, choice):
        t = self.m.begin("restrict", "cut_case", {"choice": choice})
        a = tuple(self.info(ROOT_A)[0]["flat"])
        b = tuple(self.info(ROOT_B)[0]["flat"])
        for v in range(START, STOP):
            bit = (choice >> (v - START)) & 1
            a, _, sa = self.cofactor(a, v, bit)
            b, _, sb = self.cofactor(b, v, bit)
        if a == ZERO:
            disposition = "zero_a"
        elif b == ZERO:
            disposition = "zero_b"
        elif (a[0] & b[1]) | (a[1] & b[0]):
            disposition = "guard_conflict"
        else:
            disposition = "retained"
            require(sa & ~self.x == 0 and sb & ~self.y == 0, "residual changes fixed side")
        self.m.finish(t, {"a": list(a), "b": list(b), "disposition": disposition},
                      [self.initial["A"], self.initial["B"]])
        self.cut_ids.append(t)
        if disposition != "retained":
            self.zero_choices.append(choice)
        return a, b, disposition, t

    def group(self, choice, a, b, case_id):
        t = self.m.begin("group", "group", {"choice": choice, "a": list(a), "b": list(b)})
        if a not in self.a_index:
            self.a_index[a] = len(self.a_views)
            self.a_views.append(a)
        if b not in self.b_index:
            self.b_index[b] = len(self.b_views)
            self.b_views.append(b)
            self.b_degrees.append(0)
        ai, bi = self.a_index[a], self.b_index[b]
        old = self.b_degrees[bi]
        if old:
            self.degree_hist[old] -= 1
        self.b_degrees[bi] += 1
        self.degree_hist[old + 1] += 1
        self.occurrences.append({"choice": choice, "a_index": ai, "b_index": bi})
        pair = tuple(sorted((a, b)))
        self.pairs[pair] = self.pairs.get(pair, 0) + 1
        self.m.finish(t, {"a_index": ai, "b_index": bi, "pair_occurrences": self.pairs[pair]}, [case_id])
        self.group_ids.append(t)
        self.pair_group_ids[pair].append(t)

    def finish_grouping(self):
        all_match = True
        for pair, multiplicity in self.pairs.items():
            t = self.m.begin("group", "pair_check", {"pair": [list(v) for v in pair], "multiplicity": multiplicity})
            old = self.old_pairs.get(pair, [])
            matches = len(old) == 1 and old[0]["assignment_multiplicity"] == multiplicity
            self.m.finish(t, {"matches": matches}, self.pair_group_ids[pair])
            self.pair_ids.append(t)
            all_match = all_match and matches
        t = self.m.begin("group", "group_complete",
                         {"choices": len(self.cut_ids), "retained": len(self.occurrences),
                          "distinct_a": len(self.a_views), "distinct_b": len(self.b_views),
                          "checked_pairs": len(self.pair_ids)})
        matches = (all_match and len(self.cut_ids) == 128 and len(self.zero_choices) == 67
                   and len(self.occurrences) == 61 and len(self.pairs) == len(self.old_pairs) == 61
                   and len(self.a_views) == 61 and len(self.b_views) == 35
                   and self.degree_hist == Counter({1: 20, 2: 9, 3: 1, 4: 5})
                   and self.saved["roots"] == [ROOT_A, ROOT_B]
                   and self.saved["enumerated_block_choices"] == 128)
        self.m.finish(t, {"matches": matches, "b_degrees": self.b_degrees.copy()},
                      [self.partition_id] + self.cut_ids + self.group_ids + self.pair_ids)
        require(matches, "complete cut grouping differs from fixed fixture")
        self.binding_complete = True

    def witness(self, side, target_kind, target):
        inp = {"target_kind": target_kind, "target": list(target) if target_kind == "view" else target}
        t = self.m.begin("witness_" + side, "witness", inp)
        if target_kind == "node" and target in self.witness_cache:
            value, prior = self.witness_cache[target]
            self.m.cache("witness", True)
            self.m.finish(t, {"cache_hit": True, "prior": prior, "assignment": value}, [prior])
            return value, t
        if target_kind == "node":
            self.m.cache("witness", False)
            info, vi = self.info(target)
            r = self.record(target)
            if r["kind"] == "constant":
                value = 0 if r["value"] > 0 else None
            elif r["kind"] == "guard":
                child, _ = self.witness(side, "node", r["core"])
                value = None if child is None else child | r["positive"]
            else:
                value, _ = self.witness(side, "node", r["low"])
                if value is None:
                    child, _ = self.witness(side, "node", r["high"])
                    value = None if child is None else child | (1 << r["variable"])
        else:
            p, n, core = target
            info, vi = self.info(core)
            require(p & n == 0 and (p | n) & info["support"] == 0, "invalid witness view")
            child, _ = self.witness(side, "node", core)
            value = None if child is None else child | p
        self.m.finish(t, {"cache_hit": False, "prior": None, "assignment": value}, [vi])
        if target_kind == "node":
            self.witness_cache[target] = (value, t)
        return value, t

    def pool(self, side, source_index, assignment, witness_work):
        t = self.m.begin("witness_" + side, "pool",
                         {"side": side, "source_index": source_index, "witness_work": witness_work})
        if assignment is None:
            status, row = "absent", None
        elif assignment in self.pool_seen[side]:
            status, row = "duplicate", self.pool_seen[side][assignment]
        else:
            status, row = "new", len(self.pool_seen[side])
            self.pool_seen[side][assignment] = row
        self.m.finish(t, {"status": status, "row": row, "assignment": assignment}, [witness_work])
        self.sides[side]["source_attempts"].append(
            {"source_index": source_index, "witness_work": witness_work, "pool_work": t})
        return status, row

    def evaluate(self, side, target_kind, target, assignment):
        inp = {"target_kind": target_kind, "target": list(target) if target_kind == "view" else target,
               "assignment": assignment}
        t = self.m.begin("evaluate_" + side, "evaluate", inp)
        key = (target, assignment) if target_kind == "node" else None
        if key is not None and key in self.eval_cache:
            value, prior = self.eval_cache[key]
            self.m.cache("evaluate", True)
            self.m.finish(t, {"cache_hit": True, "prior": prior, "value": value}, [prior])
            return value, t
        if target_kind == "node":
            self.m.cache("evaluate", False)
            _, vi = self.info(target)
            r = self.record(target)
            if r["kind"] == "constant":
                value = r["value"]
            elif r["kind"] == "ite":
                child = r["high"] if (assignment >> r["variable"]) & 1 else r["low"]
                value, _ = self.evaluate(side, "node", child, assignment)
            elif assignment & r["positive"] == r["positive"] and assignment & r["negative"] == 0:
                value, _ = self.evaluate(side, "node", r["core"], assignment)
            else:
                value = 0
        else:
            p, n, core = target
            _, vi = self.info(core)
            if assignment & p == p and assignment & n == 0:
                value, _ = self.evaluate(side, "node", core, assignment)
            else:
                value = 0
        self.m.finish(t, {"cache_hit": False, "prior": None, "value": value}, [vi])
        if key is not None:
            self.eval_cache[key] = (value, t)
        return value, t

    def matrix_row(self, side, row, source_index, assignment):
        views = self.b_views if side == "B" else self.a_views
        evaluated = [self.evaluate(side, "view", v, assignment) for v in views]
        if side == "B":
            values, origins = [v for v, _ in evaluated], [i for _, i in evaluated]
        else:
            values, origins = [0] * 35, [None] * 35
            for occurrence, inc in enumerate(self.occurrences):
                col = inc["b_index"]
                value, ev = evaluated[inc["a_index"]]
                t = self.m.begin("evaluate_A", "group_add",
                                 {"row": row, "group": col, "occurrence": occurrence,
                                  "before": values[col], "value": value, "evaluation_work": ev})
                after = values[col] + value
                deps = [ev] + ([] if origins[col] is None else [origins[col]])
                self.m.finish(t, {"after": after}, deps)
                values[col], origins[col] = after, t
        parities = []
        for col, value in enumerate(values):
            self.m.scope.update(column=col)
            t = self.m.begin("evaluate_" + side, "parity",
                             {"side": side, "row": row, "column": col, "value": value})
            bit = value % 2
            if side == "A" and value > 1:
                self.sampled_nonunit.append({"row": row, "assignment": assignment, "group": col,
                                            "value": value, "outside_compatibility_checked": False})
            self.m.finish(t, {"bit": bit}, [origins[col]])
            parities.append((bit, t))
        word, origin = 0, None
        for col, (bit, parity_id) in enumerate(parities):
            self.m.scope.update(column=col)
            t = self.m.begin("rank_" + side, "row_pack",
                             {"side": side, "row": row, "column": col, "before": word, "bit": bit})
            after = word | (bit << col)
            self.m.finish(t, {"after": after}, [parity_id] + ([] if origin is None else [origin]))
            word, origin = after, t
        self.sides[side]["sample_rows"].append({"row": row, "assignment": assignment,
                                               "source_index": source_index, "nat_values": values,
                                               "parity_word": word})
        original_word = word
        basis = self.bases[side]
        for col in range(35):
            self.m.scope.update(column=col)
            t = self.m.begin("rank_" + side, "pivot_probe",
                             {"side": side, "row": row, "column": col, "word": word})
            bit = (word >> col) & 1
            entry = basis.get(col)
            self.m.finish(t, {"bit": bit, "basis_row": None if entry is None else entry[1]},
                          [origin] + ([] if entry is None else [entry[2]]))
            if not bit:
                origin = t
                continue
            if entry is None:
                u = self.m.begin("rank_" + side, "rank_update",
                                 {"side": side, "row": row, "action": "insert", "pivot": col, "word": word})
                rank = len(basis) + 1
                self.m.finish(u, {"rank": rank}, [t])
                basis[col] = (word, row, u)
                self.sides[side]["rank"] = rank
                self.sides[side]["selected_original_row_ids"].append(row)
                self.sides[side]["minor_row_words"].append(original_word)
                return
            u = self.m.begin("rank_" + side, "row_xor",
                             {"side": side, "row": row, "pivot": col, "before": word,
                              "basis_row": entry[1], "basis_word": entry[0]})
            after = word ^ entry[0]
            self.m.finish(u, {"after": after}, [t, entry[2], origin])
            word, origin = after, u
        t = self.m.begin("rank_" + side, "rank_update",
                         {"side": side, "row": row, "action": "zero", "pivot": None, "word": word})
        require(word == 0, "nonzero row escaped pivots")
        self.m.finish(t, {"rank": len(basis)}, [origin])

    def run_side(self, side):
        self.sides[side]["status"] = "in_progress"
        views = self.b_views if side == "B" else self.a_views
        for source_index, view in enumerate(views):
            self.m.scope = {"phase": "side", "side": side, "source_index": source_index}
            assignment, wi = self.witness(side, "view", view)
            status, row = self.pool(side, source_index, assignment, wi)
            if status == "new":
                self.m.scope.update(row=row)
                self.matrix_row(side, row, source_index, assignment)
                if self.sides[side]["rank"] == 35:
                    self.sides[side]["status"] = "full_rank"
                    return
        self.sides[side]["status"] = "pool_exhausted"

    def run(self):
        for name, node in (("A", ROOT_A), ("B", ROOT_B), ("zero", 0)):
            _, self.initial[name] = self.validate(node)
        self.partition()
        self.m.scope = {"phase": "restrict"}
        for choice in range(128):
            self.m.scope["choice"] = choice
            a, b, disposition, ci = self.cut_case(choice)
            if disposition == "retained":
                self.group(choice, a, b, ci)
        self.m.scope = {"phase": "group"}
        self.finish_grouping()
        self.run_side("B")
        self.run_side("A")
        self.m.scope = {"phase": "complete"}
        if self.sides["A"]["rank"] == self.sides["B"]["rank"] == 35:
            return "full_rank_exclusion_for_grouped_cut"
        return "inconclusive_sampled_rank"

    def footer(self, status, error=None):
        result = {"type": "error" if error else "result", "status": status,
                  "charged": self.m.charged, "completed": self.m.completed,
                  "pending": [f["id"] for f in self.m.stack], "work_kinds": self.m.kind_counts,
                  "cache_hits": self.m.hits, "cache_misses": self.m.misses,
                  "grouping": {"choices": len(self.cut_ids), "zero_choices": self.zero_choices,
                               "retained_occurrences": len(self.occurrences),
                               "a_views": [list(v) for v in self.a_views],
                               "b_views": [list(v) for v in self.b_views],
                               "occurrences": self.occurrences, "b_degrees": self.b_degrees,
                               "saved_pair_multiset_matches": self.binding_complete,
                               "x": self.x, "y": self.y},
                  "sides": self.sides, "sampled_nonunit_groups": self.sampled_nonunit,
                  "physical_records": self.m.physical + 1, "scope": self.m.scope}
        if error:
            result.update(exception_type=type(error).__name__, message=str(error))
        self.m.write(result)
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--assessment", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    home = Path(__file__).resolve().parent.parent
    raw, saved, pairs, inputs = prepare(args.trace, args.assessment)
    with args.output.open("x") as stream:
        meter = Meter(stream)
        meter.write({"type": "header", "schema": SCHEMA, "input_bindings": inputs,
                     "roots": {"A": ROOT_A, "B": ROOT_B}, "interval": [START, STOP],
                     "variable_limit": VARIABLES, "work_cap": CAP,
                     "limits": {"wall_seconds": 30, "cpu_seconds": 30, "cpu_count": 1,
                                "address_space_bytes": 1073741824},
                     "policy_sha256": binding(home / "DESIGN.md")["sha256"],
                     "schema_sha256": binding(home / "schema.json")["sha256"]})
        probe = Probe(meter, raw, saved, pairs)
        try:
            status = probe.run()
            result = probe.footer(status)
            code = 0
        except LimitReached as exc:
            result = probe.footer("capped_prefix_only_no_combined_rank_conclusion", exc)
            code = 4
        except FixtureRejected as exc:
            result = probe.footer("fixture_binding_rejected", exc)
            code = 5
        except Exception as exc:
            result = probe.footer("process_interrupted_or_failed", exc)
            code = 6
        print(json.dumps({"status": result["status"], "charged": result["charged"],
                          "completed": result["completed"], "pending": result["pending"],
                          "ranks": {s: result["sides"][s]["rank"] for s in ("A", "B")},
                          "no_count_computed": True}, sort_keys=True))
        return code


if __name__ == "__main__":
    sys.exit(main())
