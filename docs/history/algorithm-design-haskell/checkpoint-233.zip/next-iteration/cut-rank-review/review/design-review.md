# Independent pre-execution design review

**No design-level mathematical blocker was found in the frozen v2 proposal.** This is a review of `DESIGN.md` and `schema.json`, not of an executed probe or an implemented checker. Producer, independent replayer, scheduling protocol and bounded controls require a later source review before execution. No descriptor evaluation, cofactor computation, rank computation, counter, Lean process or compile-lock acquisition was performed by this review.

## Coverage and exact target

The intended object is the complete contraction of original guarded roots 25319 and 42351 over the seven variables in `[153,160)`. The old assessment inspected all 128 choices; its 61 saved products were not merely leaves emitted before the counting cap. The new design must independently reconstruct that coverage and may not accept the old reported totals as premises.

The design correctly preserves original root lineage. Its residuals are exact views `(positive mask, negative mask, bare core)`, including guard literals removed by restriction; they are not invented existing node IDs. The common X/Y cut must be derived from checked descriptors, with each residual side contained in its designated support and the supports disjoint. The expected sizes 12 and 16 remain fixture checks until then.

Every retained choice remains an occurrence. Grouping uses identical complete B views and adds all corresponding A occurrences in Nat. The expected 61-to-35 grouping is conditional on those checks. Canonical comparison with the old unordered-pair metadata does not determine the new lineage or discard repetitions. A true zero factor may be dropped; parity-zero or an even positive leaf may not be used as Nat-zero evidence.

## Rank inference

After complete coverage, let the designated function be `F(x,y) = Σ(j<35) A'_j(x) B_j(y)`. The matrix on the A side must evaluate the grouped sums, not the 61 individual A functions. Both sides reduce exact Nat evaluations modulo two.

If each evaluation matrix has 35 independent columns, select its 35 independent original rows. Those square integer minors have odd determinants. Independent assignments on the fixed disjoint cuts can be combined; the corresponding sampled matrix of F is their product `U Vᵀ`, hence is nonsingular over the rationals. Any separated representation of F with fewer than 35 rational products would give a sampled matrix of rank below 35, a contradiction. The existing 35-product grouping gives the matching upper bound.

The sibling reviewer independently checked this argument and emphasized complete Nat coverage, retained coefficients, disjoint assignment combination and actual nonsingular minors. These are conditional mathematical observations, not a computed or Lean-proved rank result.

A deficient sampled matrix remains inconclusive. Greedy positive witnesses may repeat or reach even values; neither sampled parity deficiency nor its nullvectors prove a global function dependence. Even a full-rank outcome concerns this one boundary function and cut. It supplies no lower bound for another partition, the contraction with the remaining outside factors, the final scalar count, or the cost of every possible counting algorithm.

## Fixed policy and accounting

The v2 design fixes all 1,792 cofactor requests, complete choice accounting, first-occurrence groups, B-before-A witness processing, false-before-true positive-leaf search, exact assignment deduplication, scalar Nat evaluation, grouping before parity, and increasing-column Gaussian elimination. Predetermined stopping at sampled rank 35 is allowed; adding samples, changing primes or trying another order after a deficient result is not.

The 50,000-request cap covers cache hits as well as misses, support validation, restrictions, partition and saved-pair checks, group completion, witness/pool work, evaluation, Nat additions, parity conversion, row packing, pivot probes, row XORs and rank updates. Masks are bounded to 210 bits and matrix rows to 35 bits. Byte parsing/indexing and hashing are separately reported preparation, with no semantic support/evaluation prepass.

Each request has a start ticket and at most one completion. A completion may reference only earlier completed results, even when a recursive child's start ticket is numerically later than the parent's. The nested stack, cache publication after completion, exact cap footer and rejection of request 50,001 before work are necessary implementation checks. Two physical records per completed request are explicit; they must not be misreported as fewer physical records.

The design honestly gives an uncached evaluation bound already exceeding the cap. It promises bounded execution, not completion. Its separate analysis budget is also distinct from the historical 49,194 counting records before this cut; it makes no claim that appending the probe to that counting certificate fits 50,000 claims.

## Remaining source review

The actual implementations must enforce the declared integer and Boolean types, exact record fields, genuine descriptor bindings, full deterministic schedule, every dependency and cache key, the complete matrix row construction, original-row minor selection, and all terminal statuses. A capped or interrupted run must preserve its incomplete work and make no combined rank claim. The independent replayer must use its own local rule checks and scheduling state rather than import a producer/evaluator helper.

This review authorizes no run and approves no later source bytes by implication. Its JSON companion binds the exact v2 design and existing comparison inputs. The separately accepted generic `BlockGrouping` component proves occurrence-preserving algebra only; it does not discharge this probe's concrete coverage, semantics or rank obligations.
