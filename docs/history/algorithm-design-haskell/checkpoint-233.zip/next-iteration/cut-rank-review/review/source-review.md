# Independent source and control review: fixed cut-rank probe

## Conclusion and boundary

The final producer, independent replayer, protocol and bounded runner have no remaining blocker identified by this read-only review. They are ready for the parent's proposed single producer attempt and corresponding independent replay. This conclusion concerns the reviewed source and controls before execution. It is not a report that the probe completed, that either sampled matrix has full rank, or that a Lean theorem or queens count has been established.

The exact reviewed files, preserved drafts and patches, and original input bytes are bound in `source-review.json`. No producer, replayer, descriptor evaluator, rank algorithm, counter or Lean compiler was imported or executed during this review. The shared compilation lock was not acquired. File reading, hashing, provenance comparison and writing these new review files were the only operations performed.

The scope remains the function represented by original guarded nodes 25319 and 42351 after summing the seven variables in [153,160). The original trace's arithmetic claims and its whole-board source connection are not re-proved here. The new diagnostic's 50,000-request allowance is separate from the historical counter's 49,194 pre-cut requests; this review does not combine them into a bounded counting certificate.

## Input origin, validation and complete restriction

The runner binds and snapshots the exact original guarded trace and assessment. The replayer independently checks both fixed hashes. Raw indexing retains duplicate definitions rather than silently replacing them. Its selected-node access rejects missing or repeated definitions. The producer and replayer import only Python standard-library facilities; the replayer imports neither the producer nor any earlier evaluator.

The charged validator starts with the two designated roots and zero. It follows only selected ancestors, derives support from actual descriptors, enforces earlier child IDs and ordered branches, and checks guard masks and guard/core disjointness. Constant values are the actual nonnegative integers in the descriptors. Serialized maxima do not guide witnesses, zero decisions, evaluations or support. Parsing performs no whole-table support calculation or function evaluation.

The partition check derives the two outside support sets and confirms the fixed 12/16-variable split, disjointness, and the seven-variable intersection. Restriction then visits all 128 choices and all seven variables in order, processing A before B each time. That requires all 1,792 local cofactor requests even for a choice that has already become zero. No parity test is used to delete a natural-valued term. Only the canonical zero view or a checked guard contradiction justifies deletion.

The new support for a branch cofactor is derived from the selected child's checked support and flat guard. It is passed to the enclosing cut case, which checks residual support containment. There is no unreferenced traversal of a new core to recover support. A and B retain their root lineage; sorting the two views is confined to comparing a pair with the old saved assessment.

Every retained choice contributes one incidence. Repeated incidences would remain repeated natural summands. First-occurrence view IDs and the complete pair/group checks prevent substituting a different 61-to-35 grouping. The anticipated sizes and degrees are fixture checks that can reject the probe, not premises that can bypass reconstruction.

## Transcript continuity and charged work

The independent replay is driven by the fixed schedule, not by a free list of locally valid requests. For every next request it constructs the expected operation kind, stage and exact inputs, then requires the corresponding transcript start. It reconstructs outputs and exact dependency lists before accepting completion. Complete JSON-object comparisons reject unexpected and inactive fields, distinguish booleans from integers, and preserve repeated references. JSON duplicate keys are rejected.

Start IDs are consecutive. Completions must close the current stack frame once. Every explicit dependency and completed nested child must already have a checked completion. Numeric start-ID order alone is not treated as proof of completion. Validation, witness and evaluation caches publish only completed results, and cache hits retain the first corresponding completion as their dependency. View wrappers remain separately charged and uncached.

The reviewed correction moves group addition, parity, row packing, pivot tests, XOR, rank updates and pool decisions into bodies called only after their work starts have been consumed. Consequently an error footer encountered before the next request does not trigger that next semantic operation in replay. The cap check rejects request 50,001 before assigning an ID or doing its body. A capped footer must report exactly 50,000 starts, the exact active stack, exact completed count, and the prescribed exception and status. It must be observed before a new request, rather than in place of an outstanding completion.

The small descriptor masks and 35-bit row words are local values. They are not a packed evaluation table for all boundary assignments. Every recursive witness/evaluation request, cache hit, occurrence addition, parity conversion and elimination step is separately represented in the single request stream. Metadata assembly and raw byte/index preparation do not serve as an alternative semantic evaluator.

## Witnesses, matrix entries and genuine minor rows

The witness policy is fixed: B before A, first-occurrence source order, false branch first, and true branch only after a checked no-witness result. Positive constant leaves supply witnesses; zero leaves do not. The checked support conditions ensure that adding guard and branch bits yields an assignment within the source view's support. Complete restriction and the fixed partition therefore confine each side's assignments to its own disjoint cut. Deduplication compares whole assignments exactly.

For each new sample, every required source view is evaluated at that exact assignment. Constant values and selected branches determine the result; the cache key includes both node and assignment. B entries are its 35 view values. A entries are natural sums over every original group incidence, with an explicit chain from each view evaluation through each group addition. Only completed natural entries are reduced modulo two. No maximum oracle, adaptive witness search, additional prime or replacement sample policy is present.

Elimination starts from the last checked packing result. Each pivot probe references the current word's origin and, when present, the earlier basis insertion. A zero probe remains an origin-preserving step; an XOR references the probe, the basis insertion and the preceding word origin. Insertion records a valid increasing pivot and the original sample row ID. The reported minor words are copied from those original sample rows, not from the reduced echelon basis. This preserves the exact link from original guarded function values to the tested minors.

If both fixed sample matrices eventually have rank 35, their original row minors are nonsingular modulo two and hence over the rationals. Together with disjoint supported assignments and the complete 35-term expansion, that would exclude rational separation rank below 35 for this particular function and partition. It would not exclude other cuts, other representations, later context-dependent simplifications or a cheaper scalar count. Deficient sampled rank remains inconclusive.

## Incomplete rows and terminal status

Rows enter `sample_rows` only after all 35 packing operations finish. A packed row can still have unfinished elimination; only completed insertions affect rank. Completed nonunit scalar observations may be retained even when their row's packing is unfinished, but the protocol explicitly denies them completed-row, rank or outside-factor compatibility status. Exact side states, scope, completed requests and pending requests distinguish these cases.

A successful terminal result requires normal completion of the entire fixed procedure, complete grouping and all 1,792 cofactors. Both ranks must actually be 35 for the combined full-rank label. A cap footer always remains a checked prefix without the combined conclusion. Error and success labels are checked separately, and records after the terminal footer are rejected. The bounded runner's producer status is explicitly untrusted until independent replay.

## Controls, preservation and resolved review points

The runner executes isolated snapshots with `python -I`. It snapshots both implementations, the runner, design, schema and protocol; pins the original trace and assessment; and separately snapshots the exact supplied replay certificate. It retains logs, partial outputs, source/input hashes and a report for preparation or process failure as well as success.

The child runs on one selected CPU with a 1 GiB address-space limit and 30-second CPU and wall limits. The shared lock is exclusive and nonblocking. A post-exit wall-deadline check prevents a late successful exit from being accepted. Source and input hashes are rechecked after execution. Snapshot preparation is recorded separately; the child's own parsing, validation and all semantic computation remain inside its timed process.

The producer's earlier extra support-cache read and the replayer's earlier eager local-output computation were corrected before any run. Their reviewed original bytes and exact patches are retained. Canonical-zero matching and checkpoint field-set handling also agree with the final protocol. This review rechecked those changes rather than treating the earlier drafts as accepted executions.

No frozen parent bundle was modified, and no new rank, contraction, numeral or source-count result was obtained by this review.
