#!/usr/bin/env python3
"""Read saved bytes and record bookkeeping only; never evaluate nodes or ranks."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ROOT = BASE.parents[1]
bindings = {}
binding_checks = 0


def bind(path):
    path = Path(path)
    key = str(path)
    if key not in bindings:
        raw = path.read_bytes()
        bindings[key] = {"path": str(path.relative_to(ROOT)), "bytes": len(raw),
                         "sha256": hashlib.sha256(raw).hexdigest()}
    return bindings[key]


def verify(path, size, digest):
    global binding_checks
    actual = bind(path)
    assert actual["bytes"] == size and actual["sha256"] == digest, str(path)
    binding_checks += 1
    return actual


def load(path):
    bind(path)
    return json.loads(Path(path).read_text())


review = load(HERE / "source-review.json")
reviewed = {b["path"]: b for b in review["bindings"]}
report_shas = {
    "cut-rank-01": "7592c089d624f0553334450e4c1b773b4ebc5e81f4def081d9a202d98c1f261d",
    "cut-rank-replay-01": "53aece96a5d3f68cc71f15f11e313344ab9841716d2d107f0e3d1189d5c047c8",
}
reports = {}
for attempt, wanted_sha in report_shas.items():
    directory = BASE / "attempts" / attempt
    report_path = directory / "run-report.json"
    assert bind(report_path)["sha256"] == wanted_sha
    report = load(report_path)
    mode = "producer" if attempt == "cut-rank-01" else "replay"
    assert report["status"] == "passed" and report["exit_code"] == 0
    assert report["mode"] == mode and not report["killed_for_deadline"]
    assert report["formal_evidence"] is False and report["source_count_computed"] is False
    for flag in ("source_hashes_unchanged", "input_hashes_unchanged",
                 "source_bindings_complete", "input_bindings_complete"):
        assert report[flag] is True
    limits = report["constraints"]
    assert limits["wall_seconds"] == limits["cpu_seconds"] == 30
    assert limits["address_space_bytes"] == 1073741824
    assert limits["threads"] == 1 and len(limits["cpu_affinity"]) == 1
    assert limits["charged_semantic_requests_cap"] == 50000
    assert limits["board_size"] == 8 and limits["fixed_cut"] == [153, 160]
    assert limits["lock_mode"] == "exclusive_nonblocking"
    assert limits["shared_lock"] == str(ROOT / "project/experiments/chapter15-queens-model-counting/residual-dag/compile.lock")
    assert math.isfinite(report["seconds"]) and 0 <= report["seconds"] <= 30
    assert report["user_seconds"] + report["system_seconds"] <= 30
    assert 0 < report["peak_rss_kib"] < 1048576
    assert len(report["sources"]) == 6 and len(report["inputs"]) == (2 if mode == "producer" else 3)
    for category in ("sources", "inputs"):
        for entry in report[category]:
            actual = verify(entry["path"], entry["bytes"], entry["sha256"])
            verify(entry["snapshot"], entry["bytes"], entry["snapshot_sha256"])
            assert entry["sha256"] == entry["snapshot_sha256"]
            if category == "sources":
                assert actual == reviewed[actual["path"]]
    for entry in report["artifacts"]:
        verify(entry["path"], entry["bytes"], entry["sha256"])
    executable = report["command"][0]
    assert str(Path(executable).resolve()) == report["python_executable"]["path"]
    script = "diagnostics/probe_cut_rank.py" if mode == "producer" else "replay/replay_cut_rank.py"
    command = [executable, "-I", str(directory / "source" / script),
               "--trace", str(directory / "input/trace.jsonl"),
               "--assessment", str(directory / "input/assessment.json")]
    if mode == "replay":
        command += ["--certificate", str(directory / "input/certificate.jsonl")]
    command += ["--output", str(directory / ("work.jsonl" if mode == "producer" else "replay-report.json"))]
    assert report["command"] == command
    assert (directory / "stderr.log").read_bytes() == b""
    reports[mode] = report

certificate = BASE / "attempts/cut-rank-01/work.jsonl"
replay = load(BASE / "attempts/cut-rank-replay-01/replay-report.json")
assert replay["status"] == "passed"
assert replay["qualification"] == "checked_complete_fixed_probe_inconclusive"
assert replay["producer_status"] == "inconclusive_sampled_rank"
assert replay["grouping_complete"] is True
cert_binding = bind(certificate)
assert replay["certificate"]["sha256"] == cert_binding["sha256"]
assert replay["certificate"]["bytes"] == cert_binding["bytes"]
assert reports["replay"]["inputs"][-1]["sha256"] == cert_binding["sha256"]

# Count starts/completions and check the dependency bookkeeping. Do not inspect
# descriptors, evaluate a function, calculate parity, or perform elimination.
work, done, stack = {}, set(), []
kinds, types = Counter(), Counter()
hits, misses = Counter(), Counter()
physical = 0
header = footer = None
with certificate.open() as stream:
    for text in stream:
        assert footer is None, "record after terminal footer"
        record = json.loads(text)
        physical += 1
        types[record["type"]] += 1
        if record["type"] == "header":
            assert physical == 1
            header = record
        elif record["type"] == "work":
            assert record["id"] == len(work)
            work[record["id"]] = record
            stack.append(record["id"])
            kinds[record["kind"]] += 1
        elif record["type"] == "done":
            identifier = record["id"]
            assert stack and stack.pop() == identifier and identifier not in done
            assert all(d in done for d in record["dependencies"])
            done.add(identifier)
            request = work[identifier]
            if request["kind"] == "validate" or (request["kind"] in ("witness", "evaluate")
                    and request["inputs"]["target_kind"] == "node"):
                (hits if record["outputs"]["cache_hit"] else misses)[request["kind"]] += 1
        elif record["type"] == "result":
            assert footer is None
            footer = record
        else:
            raise AssertionError("Unexpected record type in this accepted complete attempt")
assert header is not None and footer is not None and not stack
assert types == Counter({"header": 1, "work": 23591, "done": 23591, "result": 1})
assert physical == 47184 and len(work) == len(done) == 23591
assert footer["status"] == "inconclusive_sampled_rank" and footer["scope"] == {"phase": "complete"}
assert footer["pending"] == [] and footer["charged"] == footer["completed"] == 23591
assert footer["physical_records"] == physical
assert dict(kinds) == footer["work_kinds"] == replay["work_kinds"]
assert dict(hits) == footer["cache_hits"] == replay["cache_hits"]
assert dict(misses) == footer["cache_misses"] == replay["cache_misses"]
for field in ("grouping", "sides", "sampled_nonunit_groups"):
    assert footer[field] == replay[field]
for report in reports.values():
    assert report["charged_semantic_requests"] == report["completed_requests"] == 23591
    assert report["physical_records"] == physical and report["pending_requests"] == []
assert header["roots"] == {"A": 25319, "B": 42351} and header["interval"] == [153, 160]
assert header["schema_sha256"] == replay["schema_sha256"]
assert header["policy_sha256"] == replay["policy_sha256"]
assert kinds["cofactor"] == 1792 and kinds["cut_case"] == 128 and kinds["group"] == 61
assert replay["grouping"]["choices"] == 128
assert len(replay["grouping"]["zero_choices"]) == 67
assert len(replay["grouping"]["occurrences"]) == 61
side_summaries = {}
for side, expected in {"A": (35, 56, 60, "full_rank"), "B": (19, 19, 35, "pool_exhausted")}.items():
    data = replay["sides"][side]
    actual = (data["rank"], len(data["sample_rows"]), len(data["source_attempts"]), data["status"])
    assert actual == expected
    selected = data["selected_original_row_ids"]
    assert len(selected) == len(set(selected)) == data["rank"]
    assert data["minor_row_words"] == [data["sample_rows"][i]["parity_word"] for i in selected]
    side_summaries[side] = dict(zip(("reported_rank", "sample_rows", "source_attempts", "status"), actual))

bind(HERE / "check_attempt_metadata.py")
result = {
    "kind": "independent_postrun_cut_rank_metadata_audit",
    "status": "passed",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "Exact saved bindings, commands, resource acceptance, transcript bookkeeping and outcome qualification only",
    "binding_checks": binding_checks,
    "distinct_bound_files": len(bindings),
    "bindings": sorted(bindings.values(), key=lambda b: b["path"]),
    "certificate_sha256": cert_binding["sha256"],
    "charged_and_completed": 23591,
    "physical_records": physical,
    "pending": [],
    "record_type_counts": dict(types),
    "work_kinds": dict(kinds),
    "cache_hits": dict(hits), "cache_misses": dict(misses),
    "side_summaries": side_summaries,
    "outcome": "Complete fixed sampled probe is inconclusive; B yielded only19 distinct rows from35 fixed witnesses",
    "original_minor_words_match_saved_selected_original_rows": True,
    "sampled_nonunit_scalar_observations": len(replay["sampled_nonunit_groups"]),
    "descriptor_evaluation_or_rank_recomputation": False,
    "producer_replay_counter_or_lean_rerun": False,
    "shared_lock_acquired": False,
    "frozen_attempt_or_parent_modified": False,
    "new_count_or_formal_theorem": False,
}
with (HERE / "attempt-review.json").open("x") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps({k: result[k] for k in ("status", "binding_checks", "distinct_bound_files", "charged_and_completed", "side_summaries")}, sort_keys=True))
