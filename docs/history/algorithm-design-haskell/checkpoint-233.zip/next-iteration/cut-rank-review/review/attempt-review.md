# Independent audit of the two saved cut-rank attempts

The saved producer and independent replay agree on a **complete but inconclusive fixed probe**. This audit rechecked their exact file bindings, process commands, resource records, transcript bookkeeping and outcome labels. It did not rerun the producer, replay, descriptor evaluation, parity calculations, elimination or any Lean code.

| Saved item | Producer `cut-rank-01` | Replay `cut-rank-replay-01` |
|---|---:|---:|
| Process status | Passed | Passed |
| Wall time | 0.690633933 s | 2.046626010 s |
| Peak resident memory | 87,828 KiB | 97,392 KiB |
| Charged requests | 23,591 | 23,591 checked |
| Completed requests | 23,591 | 23,591 checked |
| Pending requests | 0 | 0 |
| Outcome | `inconclusive_sampled_rank` | `checked_complete_fixed_probe_inconclusive` |

Both processes used the reviewed source snapshots, one CPU, the 30-second CPU/wall bounds, 1 GiB address-space limit and shared lock. All source and input binding flags are true. This audit independently rehashed 57 explicit report bindings across 35 distinct files and confirmed that the replay's certificate is exactly the producer's 6,527,119-byte transcript, SHA256 `048355ac631a1cf5fb9793102511e093c6015d011d08236e16f2a309dc1c6066`.

The transcript has 47,184 physical records: one header, 23,591 starts, 23,591 completions and one result footer. The starts are dense, completions close the exact active stack, and every referenced completion exists before use. Its recorded work-kind and cache distributions match both the footer and independent replay. The saved grouping covers all 128 block choices and 1,792 cofactors; 67 choices are zero and 61 incidences remain, grouped into 61 A views and 35 B views. These statements are checks of the saved accepted replay and transcript accounting, not a new semantic evaluation by this audit.

| Sampled side | Source witnesses attempted | Distinct sample rows | Reported rank | Final side status |
|---|---:|---:|---:|---|
| A | 60 | 56 | 35 | Full rank |
| B | 35 | 19 | 19 | Fixed pool exhausted |

B has only 19 distinct assignments from its 35 fixed greedy witnesses. Its sampled rank of 19 therefore does **not** establish a dependence among the 35 complete B functions or a rational separation-rank upper bound of 19. It also does not provide the two full 35-dimensional minors needed for the proposed rank-35 exclusion. A's 35 selected original row IDs and B's 19 selected IDs point to their original saved sample words; this audit checked those identities without repeating elimination.

The replay records one grouped A scalar value of 2, at row 46 and group 30. It remains explicitly unqualified with respect to the outside factors: `outside_compatibility_checked` is false. It is not a new global solution count or a proof of extendibility.

The fixed procedure completed naturally below its cap. No additional witness sampling, adaptive policy, changed modulus or second rank probe was performed. The conclusion stays limited to this sampled probe of the designated intermediate function. There is no new Lean rank theorem, original-source count or size-six/size-eight/size-sixteen count claim.

## Audit implementation and preserved correction

`check_attempt_metadata.py` only reads bytes and saved record metadata. The first audit invocation stopped on an overly literal command-path comparison: the saved command uses `python3`, while the executable binding resolves the same symlink to `python3.12`. The original checker and failure log are retained. The correction requires that the command executable resolve to the recorded executable and then checks the exact remaining command. The second metadata audit passed. This was a review-tool path-alias correction, not a producer or replay failure; neither authorized semantic process was rerun or changed.

The detailed audit is `attempt-review.json`. Its checker, both metadata logs, the exact correction and this note are sealed by `attempt-review-evidence.json`. The earlier source/control review remains separate and unchanged.
