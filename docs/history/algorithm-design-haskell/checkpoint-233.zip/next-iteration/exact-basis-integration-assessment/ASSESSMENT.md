# Using the four exact cut identities

## Decision

The useful next milestone is **kernel checking the four fixed guarded-function identities, followed by a generic signed block-rewrite theorem**. Do not formalize the adaptive basis search, claim a31-term Nat basis, or launch another counter merely because the dimension fell from35 to31.

The identities are genuine new algebraic compression beyond literal duplicate grouping. Their immediate operation saving is small, however, and the current counter's expensive work is recursive conditioning. Affordable complete counting integration remains unmeasured.

## What is now established diagnostically

The fixed producer and independent replay completed all35 columns with29,360 requests and no pending work. The rational function-space dimension is31. The four dependent columns have positive clearing scale1 and these original-column coefficient vectors: [RESULTS]

| Discarded column | Complete identity |
| --- | --- |
| 3 | B0 − B1 − B2 + B3 = 0 |
| 9 | B6 − B7 − B8 + B9 = 0 |
| 14 | B11 − B12 − B13 + B14 = 0 |
| 20 | B17 − B18 − B19 + B20 = 0 |

These equalities concern the original guarded views for every assignment on their16-variable side. They do not depend on outside-factor compatibility or on assuming a queens count. The whole diagnostic is externally replayed evidence, not yet a Lean identity/rank theorem. Its11,510,282-byte work transcript remains retained. [RESULTS, REPLAY]

For integration, use the31 retained **original B columns** and these four integer identities. The normalized triangular basis includes fractions and signed combinations useful for establishing independence; there is no reason to carry those normalized vectors into counting. All four required substitutions use coefficients1,1,−1 and no denominators.

## Exact block rewrite and its sign obligation

The previously checked cut grouping is

`F(X,Y) = Σ(j<35) A'_j(X) B_j(Y)`.

Each A'_j is the natural sum of its original grouped occurrences. For any one listed quartet (p,q,r,s), the identity gives `B_s = B_q + B_r − B_p` over Int. Therefore its four contributions become

`(A'_p − A'_s) B_p + (A'_q + A'_s) B_q + (A'_r + A'_s) B_r`.

Apply this to the four disjoint index quartets and leave the other groups unchanged. The result has31 separated terms. All grouped A multiplicities remain present. This is a complete algebraic identity over lifted Nat functions; it does not require A'_p≥A'_s. The difference may be negative. Nat's truncated subtraction would be unsound here unless a separate pointwise inequality were proved.

The equivalent Nat statement `B_p + B_s = B_q + B_r` is a useful kernel-level conclusion, but it does not by itself turn an arbitrary weighted four-term block into three nonnegative terms. A Nat-only rewrite would need additional structure in the A weights. None has been checked.

Existing signed laws already provide casts, finite projection transfer, signed collection/cancellation, cofactor splitting and a generic earlier-proof DAG theorem. Existing block-grouping laws preserve occurrences under exact grouping. They do not yet implement the original guarded descriptor interpreter, this concrete proof stream, or the signed weighted quartet rewrite. Those are the actual next obligations. [SIGNED, GROUP]

## Why31 terms do not yet imply a faster counter

After A grouping, a naive35-term lazy sum has35 product roots and34 additions. Applying the four substitutions gives31 product roots,30 outer additions, eight coefficient additions and four coefficient subtractions:73 binary arithmetic operations rather than69, if subtraction is primitive. Expressing each subtraction as addition plus multiplication by−1 adds further work. These are simple structural counts, not measurements of either counter and not complete certificate costs.

The current lazy representation makes ordinary multiplication nonrecursive; reducing four product roots therefore does not remove the old large ADD product expansions. Its common-factor rule sees literal identical child IDs, not these four global functional identities. At completed frontier153 the factored variant had42,402 operation records, including26,932 cofactors, and still stopped inside[153,160) at the50,000 cap. [LAZY-SOURCE, LAZY-RESULTS]

A possible performance mechanism is to keep a signed boundary coefficient representation and apply the four identities **before** building the block's final product/sum expression. This could change later cofactor sharing or allow signed cancellations. Applying it after the original expensive block has already been computed cannot erase that work. The current evidence does not quantify either benefit. A31-dimensional span also rules out a dramatic further unconditional rank collapse at this same partition, subject to formalizing the independence witness; it says nothing about other cuts or context-restricted relations.

Do not run the29,360-request basis discovery inside every contraction. A future fixed certificate can reuse the four proved relations with exact source bindings. Their discovery cost stays reported; extracting the necessary proof DAG for kernel verification is a reduction in verification evidence, not retroactive computation savings or a reset of the counter's budget.

## The provenance boundary is concrete

The guarded cut used original roots25319 and42351. The current factored-lazy trace's pending event, at physical line56698, consumes factors116 and120 with roots6430 and9815. Both intervals are[153,160), with the same recorded28-variable post-block scope, but the roots belong to different descriptor languages. Numeric IDs or matching scopes cannot transfer the identities. [CUT, LAZY-TRACE]

A valid replacement must bind:

1. The sixteen B views appearing in the four relations to their exact original guard masks and source core IDs. Any compact remapping must retain a checked original-ID/child correspondence.
2. Each identity root to a complete local proof DAG over an internally interpreted original descriptor table. The sample matrix, basis declaration and external replay are not Lean premises.
3. The designated original block to all128 assignments of the seven eliminated wires, with zero cases and repeated occurrence multiplicities preserved, and then to the35-group formula.
4. Any use in the current lazy counter to equal functions for its actual factor roots, ideally through their exact source-cell occurrence and elimination histories. The selected factor multiset must be consumed once and the outside factors retained.

For now, items1–2 plus the generic signed quartet theorem form a useful, bounded mathematical milestone. The block coverage and cross-representation equalities are explicit later integration obligations; they must not be hidden in a theorem name suggesting a complete source count.

## Smallest sensible proof extraction

Generate only the four fixed identity proofs and their required original-node/view/local-proof closure from the already checked records. There is no need to replay adaptive witness selection, certify rational rank31, or include the31 nonzero basis witnesses in a theorem whose purpose is rewriting these four relations. The original full transcript remains available and its measured work remains unchanged.

The generic checker should define guarded meanings internally, check strict earlier-node references and support/cofactor conditions, and validate exact signed normalization and both branches for each zero proof. A prior diagnostic's claimed support or value must not become an axiom. The concrete generator may extract and remap existing records, but must retain original IDs and emit the correspondence needed to check the remapping. It must not evaluate functions, discover new relations or silently regenerate cofactors.

Prove the four Nat additive equalities or their equivalent signed-zero forms. Then prove the signed block rewrite and finite-sum congruence generically. Rebuild all required new mathematics under the unchanged fresh30-second, one-CPU and1GiB Lean gate before calling this milestone accepted. A successful component would establish a reusable exact compression rule on real retained functions; it would still not establish n8 counting completion for this route or the n16 goal.

## Scope and sources

This assessment performed only static source and completed-metadata inspection. There was no new function evaluation, cofactor computation, algebraic elimination, probe, counter, replay or Lean run. Symbolic equalities and structural operation counts above are mathematical reasoning.

Workspace-relative references, bound in `evidence.json`:

- **RESULTS:** `next-iteration/exact-basis-diagnostic/RESULTS.json`.
- **REPLAY:** `next-iteration/exact-basis-diagnostic/attempts/basis-replay-01/replay-report.json`.
- **CUT:** `next-iteration/cut-rank-next-step/ASSESSMENT.md` and `next-iteration/contextual-relation-assessment/metadata.json`.
- **LAZY-SOURCE:** `next-iteration/lazy-factored-circuit/diagnostics/produce_lazy_trace.py`.
- **LAZY-RESULTS:** `next-iteration/lazy-factored-circuit/RESULTS.json`.
- **LAZY-TRACE:** `next-iteration/lazy-factored-circuit/diagnostics/attempts/factor-eight-01/trace.jsonl`.
- **SIGNED:** `next-iteration/signed-relation-laws/SignedRelations.lean`.
- **GROUP:** `next-iteration/block-grouping-laws/BlockGrouping.lean`.
