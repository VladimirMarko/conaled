# Actual Nat-only source, annotation and installation boundary

This is a source-only assessment, not a new theorem, parser/export run, annotated
record construction, installed-environment witness or complete saved-result audit.
It preserves the current proof/gate selections. The source excerpts and exact
identities are in PRIMARY-SOURCE-INTERVALS.json and SOURCE-INVENTORY.json.

## What the retained export comparison actually supplies

The retained raw comparison reports complete type and capture-safe zeta-expanded
body agreement for these three actual exported definitions:

| Suffix under ADWH.Experiments.Chapter15.StructuralNatOnlyReference | Raw type index | Raw value index | Actual hint |
| --- | ---: | ---: | --- |
| branches | 11284 | 11337 | regular 12 |
| count | 11339 | 11399 | regular 13 |
| evaluate | 11338 | 11445 | regular 14 |

All three exported declarations have empty universe-parameter lists and are safe.
The report retains exact canonical type/body hashes, checks binder information
and universe expressions, and records 161 selected raw expression nodes. It
expands one raw let node, 11320. Its two normalizations are ignoring alpha-renamable
binder names and capture-safe let substitution. These are retained report fields,
not a fresh computation performed for this assessment. The report explicitly
does not establish actual annotation, installed ProgramPins or a stock numeral.
The raw file is 744,554 bytes, SHA-256
`4a57e0874be5047e3fedf62d88571666316cdfe5b8ed847593b350bc208cea21`.

The accepted conditional pure177 owner's KernelNatOnlyBodies templates use these
Nat-only names and contain complete types/bodies with .never binder metadata.
Its DefinitionPins records require actual environment lookup, internal name,
empty levels and exact annotated type/body; ProgramPins groups the three. The
saved byte comparison is useful source correspondence, but does not construct
those actual environment lookup or annotation facts.

The older kernel-original-record-contract still names StructuralPrimitiveReference.
Its Eq.{1} Nat (Nat.add query 0) N / Eq.refl.{1} Nat N wrapper strategy is reusable,
but a new concrete record must name StructuralNatOnlyReference.evaluate explicitly.
Its old source bridge and artifact naming cannot silently certify this new source.

## Why .never in the raw syntax is insufficient

The actual scanner defaults missing binder pw fields to .never, and ExportC maps
that value into BinderMeta. The actual pwWritten function is `!pw.isNever`.
Consequently .never is the placeholder that annotation recomputes, even though
it is also a legitimate final annotation. Only non-placeholder ifAllZero metadata
is retained by the write routine; all annotations still require validation by
the original checker. There is no safe inference from a raw .never token to a
valid beta/iota licence or an installed final .never record.

The actual cached annotator reads typeSortPW for a forall telescope and proofPW
for a lambda telescope. A successful read returns the datum without fallback;
an unknown read invokes actual inferIO/ensureSort. The telescope machinery also
opens expressions, annotates each opened domain/body, abstracts them again and
threads the written datum outward. Closed lambda detection uses the actual
bvar-bound helper. Proving only the reader returns .never therefore does not yet
prove annotation of the full telescope succeeds or returns the proposed body.

For constants, the metadata readers inspect the actual stored ConstantInfo,
reject tower entries, check universe arity and read the full type, with level
substitution. The current eight ArithmeticPins booleans check reduction-time
definition kinds. They do not supply the exact Nat-operation types needed for
these reads or for inference. Full typed lookup facts for Nat, the operations,
Nat.rec and any recursively referenced program declarations are needed.

The single raw branches let is a further concrete obligation. annotateBodyI does
not simply erase it: it annotates the declared type, infers it and ensures a sort;
annotates and infers the value; checks the value type against the declared type;
then substitutes the original value into the body and annotates the reduct.
The retained zeta comparison records the final syntax only. It does not prove
these real type/value/defeq checks, their state transitions or their fixed fuel.

## Existing guards and what still has to produce their evidence

The existing installed-guards22 source has recognizers for ProgramPins and the
operational basis pins. Its program recognizer checks actual complete stored
records and supplies ProgramPins on success; its completeness theorem is
conditional on those pins. It is not an actual successful recognition of this
exported program's installed prefix.

The Nat recursor guard is stronger than the arithmetic bits: it checks the whole
active two-rule list, internal names, major and recursive-parameter index 3,
constructor metadata, one recursor universe parameter, empty constructor levels,
and the exact types and rule bodies after level instantiation, plus literal
support. These conditions are useful adapter inputs; they still need an actual
installed record witness. PrefixLookup must come from the real visibility view
with the canonical-index and name-uniqueness conditions retained. It does not
by itself transport all cache validity across a visibility change.

Original annotConstantValC and annotValC perform raw scope/name/universe guards,
actual annotation, final universe/constant resolution, and converted-constant
recording. annotValueC flushes and threads their actual returned states.
annotStepC then pushes the actual annotated definition and records its preceding
visibility bound. A theorem installs its annotated statement and keeps the raw
proof for the later original checkPending. An InstallRun is the actual successful
chain of these steps, not a manually assembled list with desirable records.

The current evaluator slice deliberately omits parts of that driver API, including
recordCConst and the two cached driver guard traversals. Those exact declarations
must return in a separately reviewed closure before an original installation or
GroupChecked theorem can be claimed. The public BasisA names also do not provide
literal annotated Nat records in the retained source: they are produced by the
#annotate_basis command, whose real recipe runs annotation and computes recursor
rule metadata. No such generator was executed here, and its output cannot be
silently stipulated as an installed witness.

## Smallest concrete next proof work

A useful next leaf can prove generic metadata-reader facts for actual typed
constant/fvar lookup premises, then the real annotPwPiI / annotPwLamI successful
branches. Keep exact universe arities, level substitutions and non-tower guards
in those premises. The record-wrapper work already has an Eq-specific
notProofFast lemma; this program leaf should share the general observer facts
without duplicating its finite Eq wrapper branches.

The next layer must prove actual opened/abstracted Nat telescope annotation,
using returned-state threading and exact helper semantics. The existing Syntax
leaf covers bulk instantiation and level substitution; it does not automatically
supply all abstraction and reversed-instantiation correspondence needed here.
A small constructor-restricted proof may be enough for these finite raw bodies,
but any packed-bound cutoffs and fvar abstraction assumptions must remain visible.
The branches let then needs its concrete type/value/defeq checks before zeta.
These are the missing operational interfaces, not just missing lookup boilerplate.

Only after these annotation results and restored original installation steps are
proved should literal raw records be connected to their actual annotated prefix
and passed to the existing ProgramPins/Nat/arithmetic recognizers. A manually
chosen annotated environment may serve as an explicit conditional intermediate,
but must not be labelled installed. The raw export correspondence, annotation
success, annotation licence validity, successful original installation, true
prefix lookup and original record verification should remain separately named
obligations until their proofs compose.

This assessment adds no selected mathematical source, executable probe, expected
numeral premise, performance claim or resource exception. All existing consumed
and prospective gates remain unchanged.
