#!/usr/bin/env python3
"""Build the explicit current recovery set, with a 32 MiB publication guard."""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile
import zipfile
from verify_durability import inspect_archive, safe_name

ROOT = Path(__file__).resolve().parent


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--id', required=True)
    p.add_argument('--title', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--selection', type=Path, default=ROOT / 'durability-selection.json')
    p.add_argument('--max-mib', type=float, default=32)
    a = p.parse_args()
    if not math.isfinite(a.max_mib) or a.max_mib <= 0:
        p.error('--max-mib must be finite and positive')
    if a.output.exists():
        p.error('Output exists; checkpoints are never overwritten')
    selection = json.loads(a.selection.read_text())
    if selection.get('format') != 'adwh-durability-selection-v1':
        raise ValueError('Unexpected selection format')
    rows = selection['files']
    names = [r['path'] for r in rows]
    if len(names) != len(set(names)) or 'CHECKPOINT-MANIFEST.json' in names:
        raise ValueError('Duplicate/reserved selection path')
    files = []
    for row in sorted(rows, key=lambda r: r['path']):
        name = row['path']
        safe_name(name)
        path = ROOT / name
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(ROOT):
            raise ValueError(f'Not an ordinary in-workspace file: {name}')
        files.append({'path': name, 'role': row['role'], 'bytes': path.stat().st_size,
                      'sha256': digest(path)})
    manifest = {
        'format': 'adwh-standalone-durability-v2', 'checkpoint': a.id, 'title': a.title,
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'book_complete': False,
        'open_target': 'ADWH.Chapter15.Queens.BitRepresentation.cqueens 16 = 14772512',
        'scope': 'Current source recovery and selected evidence; packaging does not rerun mathematical gates.',
        'prior_archives_required': [], 'compiled_objects_included': False,
        'selection_policy': 'CHECKPOINT-POLICY.md', 'restore_instructions': 'RESTORE.md',
        'size_guard_mib': a.max_mib, 'files': files,
    }
    current_gate = json.loads((ROOT / 'project/adwh-lean/reports/verification.json').read_text())
    manifest['current_integrated_gate_status'] = current_gate.get('status')
    if current_gate.get('status') != 'passed':
        migration_state = 'next-iteration/lean435-migration/durability-state.json'
        if migration_state not in names:
            raise ValueError('An unfinished migration requires its explicit durability state')
        manifest['migration_state'] = migration_state
    raw = (json.dumps(manifest, indent=2) + '\n').encode()
    a.output.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=a.output.name + '.', suffix='.partial', dir=a.output.parent)
    os.close(fd)
    temporary = Path(temporary_name)
    with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for row in files:
            z.write(ROOT / row['path'], row['path'])
        z.writestr('CHECKPOINT-MANIFEST.json', raw)
    if temporary.stat().st_size > a.max_mib * 1024 * 1024:
        with zipfile.ZipFile(temporary) as z:
            largest = [{'path': i.filename, 'compressed_bytes': i.compress_size}
                       for i in sorted(z.infolist(), key=lambda i: i.compress_size, reverse=True)[:15]]
        raise RuntimeError(json.dumps({'error': 'Archive exceeds publication size guard; review selection.',
                                       'partial_retained': str(temporary), 'bytes': temporary.stat().st_size,
                                       'max_mib': a.max_mib, 'largest': largest}))
    result = inspect_archive(temporary)
    for row in files:
        if digest(ROOT / row['path']) != row['sha256']:
            raise RuntimeError('Input changed while packaging: ' + row['path'])
    with temporary.open('rb') as f:
        os.fsync(f.fileno())
    temporary.replace(a.output)
    result.update(archive=str(a.output.resolve()), archive_bytes=a.output.stat().st_size,
                  archive_sha256=digest(a.output), size_guard_mib=a.max_mib,
                  roles=dict(Counter(r['role'] for r in files)))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
