from pathlib import Path
import datetime, hashlib, json, subprocess
root=Path('/tmp/conaled-wave-20261115/534/preparer')
repo=root/'checkout'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
paths=['Examples/CubicalAuthorTransport.lean','Examples/CubicalAuthorTransportCalibration.lean',
'Examples/CubicalFiniteStateIdentity.lean','Examples/CubicalStructuredState.lean',
'Examples/CubicalStateTransport.lean','Examples/CubicalStatePackageFamily.lean',
'Examples/CubicalStatePackageUa.lean','Examples/CubicalUnivalenceTransport.lean',
'SquareKit/Internal/Cubical/HomotopyEquivalenceComposition.lean',
'SquareKit/Internal/Cubical/SelectedInverse.lean','docs/research/univalent-author-interface.md',
'lean-toolchain','lakefile.toml','lake-manifest.json','flake.nix','flake.lock']
files={str(p.relative_to(root)):digest(p) for p in sorted(root.glob('public/*')) if p.is_file()}
for name in ['PrivateMathematics.lean','PrivateFeasibility.lean','PrivateFacadeFeasibility.lean',
'PrivateOracle.lean','PrivateOracleFacade.lean','InterfaceNative.lean','InterfaceFacade.lean']:
 p=repo/name;files[str(p.relative_to(root))]=digest(p)
for name in ['check-private.sh','check-interface.sh','task.md','protocol-notes.md','preparation-record.md','feasibility-10.log','interface-check-01.log','interface-check-02.log']:
 p=root/name
 if p.exists(): files[name]=digest(p)
record={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'status':'prepared; not released; freeze/review pending','source_commit':git('rev-parse','HEAD'),
'source_tree':git('rev-parse','HEAD^{tree}'),'baseline_sha256':{p:digest(repo/p) for p in paths},
'artifact_sha256':files,'lean_toolchain':(repo/'lean-toolchain').read_text().strip(),
'dependencies':json.loads((repo/'lake-manifest.json').read_text()),
'private_project_cache':'copied --reflink=auto from worker534; no shared writable project outputs',
'dependency_cache':'symlink to pinned worker534 .lake/packages; shared dependency outputs',
'validation_wrapper':'flock /tmp/conaled-wave-20261115/build.lock taskset -c 0 nice -n 10 direnv exec /home/vlad/Code/conaled',
'model_metadata':'not supplied beyond inherited agent configuration; no author cohort exists'}
record['actual_dependency_revisions'] = {}
for package in record['dependencies']['packages']:
 if package.get('type') == 'git':
  dep=repo/'.lake/packages'/package['name']
  rev=subprocess.check_output(['git','-C',str(dep),'rev-parse','HEAD'],text=True).strip()
  status=subprocess.check_output(['git','-C',str(dep),'status','--porcelain'],text=True).strip()
  assert rev == package['rev'], (package['name'],rev,package['rev'])
  assert not status, (package['name'],status)
  record['actual_dependency_revisions'][package['name']]=rev
assert (repo/'PrivateOracle.lean').read_text().splitlines()[1:] == (repo/'PrivateOracleFacade.lean').read_text().splitlines()[1:]
record['oracle_body_sha256'] = hashlib.sha256('\n'.join((repo/'PrivateOracle.lean').read_text().splitlines()[1:]).encode()).hexdigest()
(root/'source-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
