# #534 independent task preparation handoff

Prepared and privately validated. No author has received the task, and no
usability trial or conclusion is claimed. Source revision:
`4473f02225d84cdb99694a284e1898157c2e790c`. Worker534 remains unchanged and clean.

The new task transports paired finite Nat journals under reversal: append
becomes prepend. The main dependent invariant is equal lengths; the variation
changes it to equal totals. Direct target definitions, universal observations,
two separating list pairs and rejection of invariant erasure distinguish it
from the public Bool/Int/Fin3/Phase calibrations.

The common named declaration interface retains the exact arbitrary supplied
native equivalence E, complete native paths and filled sections, both endpoint
observations, complete decoded records, native recovery and the rejecting case.
The private oracle's two replay files differ only in the submission import.

## Artifacts

- `public/task.md`, `public/TrialTask.lean`, `public/ExpectedInterface.lean`:
  proposed common author bundle. Release only after coordinator freeze/review.
- `checkout/PrivateMathematics.lean`, `PrivateFeasibility.lean`,
  `PrivateFacadeFeasibility.lean`: private checked feasibility, excluded from
  both author environments.
- `checkout/PrivateOracle.lean`, `PrivateOracleFacade.lean`: private matching
  acceptance oracle replays.
- `source-manifest.json`: complete relevant baseline/facade/task/oracle hashes,
  dependency manifest and actual clean pinned dependency revisions.
- `validation.json`: exact focused validation scope and exit results.
- `preparation-record.md`: statement review, novelty, failures, repairs,
  native/decoded coverage and limitations.
- `protocol-notes.md`: proposed calibration-exposure wording and release policy.

## Validation and invocation limitation

`feasibility-10.log` passed both private solutions through the common oracle.
`interface-check-02.log` passed the same public declaration checker against
both solutions. Both commands exited 0 at default heartbeat limits under the
required serialized CPU-0/nice-10/direnv wrapper. Named transitive axiom queries
show only the permitted three axioms. This is focused private feasibility,
not the final integrated exhaustive audit or independent protocol review.

Direct applications of facade `Change.path_recovery` across the baseline-typed
acceptance boundary timed out in preparation, including explicit endpoints and
a locally typed path. The passing facade feasibility keeps facade path,
section and decoded transport, and uses the permitted baseline
`uaStructureIdentity(...).symm_apply_apply` for that recovery equality. The
mathematical contract is unchanged. This limitation is preparer/interface
integration effort, not an author-trial outcome or a mathematical defect.
All failed preflight logs and the relevant source revisions are retained.

Public SHA-256:

| File | SHA-256 |
|---|---|
| `task.md` | `1c09e38f6e27e8ba675d5290c65eea38d46425e988cf116a5c64ff18acecba85` |
| `TrialTask.lean` | `da03cbc2ebf16e5d80734de7f99853a4d045cc07013eae9ea2e956f9c4f8f26d` |
| `ExpectedInterface.lean` | `31fcc43cf022bfa892b14b17ef0909f08babfa595efdbebc2f319c738a7e41f0` |

The private oracle body, excluding its import line, has SHA-256
`a0cbde8a8e35145e58932f63f9a6d05e8636645503d514077fcce32fbf153747`.

The coordinator owns integration, final freeze identity, independent reviews
and future author assignment. This preparer must not serve as an author.
