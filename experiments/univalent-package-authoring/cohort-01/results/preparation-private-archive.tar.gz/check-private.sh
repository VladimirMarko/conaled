#!/usr/bin/env bash
set -euo pipefail
cd /tmp/conaled-wave-20261115/534/preparer/checkout
flock /tmp/conaled-wave-20261115/build.lock taskset -c 0 nice -n 10 direnv exec /home/vlad/Code/conaled bash -c '
set -euo pipefail
export LEAN_PATH="$(lake env printenv LEAN_PATH):."
lean -o TrialTask.olean TrialTask.lean
lean -o PrivateMathematics.olean PrivateMathematics.lean
lean -o PrivateFeasibility.olean PrivateFeasibility.lean
lean -o PrivateOracle.olean PrivateOracle.lean
lean -o PrivateFacadeFeasibility.olean PrivateFacadeFeasibility.lean
lean -o PrivateOracleFacade.olean PrivateOracleFacade.lean
'
