#!/usr/bin/env bash
set -euo pipefail
cd /tmp/conaled-wave-20261115/534/preparer/checkout
flock /tmp/conaled-wave-20261115/build.lock taskset -c 0 nice -n 10 direnv exec /home/vlad/Code/conaled bash -c '
set -euo pipefail
export LEAN_PATH="$(lake env printenv LEAN_PATH):."
lean --version
lean InterfaceNative.lean
lean InterfaceFacade.lean
'
