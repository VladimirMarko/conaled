import TrialTask

set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option backward.isDefEq.respectTransparency false
set_option warningAsError true
namespace JournalTrial.Oracle
open CategoryTheory SquareKit.Cubical SquareKit.Cubical.Presheaf
open Examples.CubicalStateTransport Examples.CubicalStatePackageFamily
open Examples.CubicalStatePackageUa Examples.CubicalStructuredState

variable (E : HomotopyEquivalence nativeMap) (s : Submission E)

/-- Full records, including dependent proposition and proof fields. -/
theorem complete_packages : s.main.decoded = targetLength ∧ s.variation.decoded = targetSum :=
  ⟨s.main.decoded_target, s.variation.decoded_target⟩

/-- Universal observations use independently defined targets, not conjugation. -/
theorem all_observations (a b : List Nat) :
    s.main.decoded.initial = ([], []) ∧
    s.main.decoded.step (a,b) = (1::a,1::b) ∧
    (s.main.decoded.invariant (a,b) ↔ a.length = b.length) ∧
    s.variation.decoded.initial = ([], []) ∧
    s.variation.decoded.step (a,b) = (1::a,1::b) ∧
    (s.variation.decoded.invariant (a,b) ↔ a.sum = b.sum) := by
  rw [s.main.decoded_target, s.variation.decoded_target]
  exact ⟨rfl, rfl, Iff.rfl, rfl, rfl, Iff.rfl⟩

/-- The step check distinguishes prepend from append away from the initial orbit. -/
theorem separating_observations :
    s.main.decoded.step ([2,3],[5]) = ([1,2,3],[1,5]) ∧
    ¬ s.main.decoded.invariant ([2,3],[5]) ∧
    s.variation.decoded.invariant ([2,3],[5]) ∧
    s.main.decoded.invariant ([2],[3]) ∧
    ¬ s.variation.decoded.invariant ([2],[3]) := by
  rw [s.main.decoded_target, s.variation.decoded_target]
  decide

/-- Decode the submitted nativeSection itself at the final endpoint. -/
theorem section_decodes :
    (readOut (admittedLine (S := Journals) (T := Journals) nativeMap E) (endpointPoint true)
      (s.main.nativeSection.val (endpointPoint true))).conjugate
      ((admittedFinish (S := Journals) (T := Journals) nativeMap E).app point).toEquiv = targetLength := by
  rw [s.main.section_exact]
  exact s.main.decoded_exact.symm.trans s.main.decoded_target

theorem variation_section_decodes :
    (readOut (admittedLine (S := Journals) (T := Journals) nativeMap E) (endpointPoint true)
      (s.variation.nativeSection.val (endpointPoint true))).conjugate
      ((admittedFinish (S := Journals) (T := Journals) nativeMap E).app point).toEquiv = targetSum := by
  rw [s.variation.section_exact]
  exact s.variation.decoded_exact.symm.trans s.variation.decoded_target

/-- Full sections at every generalized point, including dependent proof data. -/
theorem sections_recovered :
    s.main.nativeSection = pullPackage (admittedLine (S := Journals) (T := Journals) nativeMap E) (admittedPresentation (S := Journals) (T := Journals) nativeMap E)
      (sourceLength.conjugate (admittedCarrier (S := Journals) (T := Journals) nativeMap E)) ∧
    s.variation.nativeSection = pullPackage (admittedLine (S := Journals) (T := Journals) nativeMap E) (admittedPresentation (S := Journals) (T := Journals) nativeMap E)
      (sourceSum.conjugate (admittedCarrier (S := Journals) (T := Journals) nativeMap E)) :=
  ⟨s.main.section_recovery, s.variation.section_recovery⟩

theorem path_start : (pathApp s.main.nativePath).reindex (endpointSub terminal false) =
    (pullPackage (admittedLine (S := Journals) (T := Journals) nativeMap E) (admittedPresentation (S := Journals) (T := Journals) nativeMap E)
      (sourceLength.conjugate (admittedCarrier (S := Journals) (T := Journals) nativeMap E))).reindex (endpointSub terminal false) :=
  pathApp_zero s.main.nativePath

theorem path_finish : (pathApp s.main.nativePath).reindex (endpointSub terminal true) =
    (pullPackage (admittedLine (S := Journals) (T := Journals) nativeMap E) (admittedPresentation (S := Journals) (T := Journals) nativeMap E)
      targetLength).reindex (endpointSub terminal true) := pathApp_one s.main.nativePath

theorem variation_path_start : (pathApp s.variation.nativePath).reindex (endpointSub terminal false) =
    (pullPackage (admittedLine (S := Journals) (T := Journals) nativeMap E) (admittedPresentation (S := Journals) (T := Journals) nativeMap E)
      (sourceSum.conjugate (admittedCarrier (S := Journals) (T := Journals) nativeMap E))).reindex (endpointSub terminal false) :=
  pathApp_zero s.variation.nativePath

theorem variation_path_finish : (pathApp s.variation.nativePath).reindex (endpointSub terminal true) =
    (pullPackage (admittedLine (S := Journals) (T := Journals) nativeMap E) (admittedPresentation (S := Journals) (T := Journals) nativeMap E)
      targetSum).reindex (endpointSub terminal true) := pathApp_one s.variation.nativePath

theorem paths_recovered :
    (uaStructureIdentity (S := Journals) (T := Journals) nativeMap E sourceLength targetLength).symm
      ((uaStructureIdentity (S := Journals) (T := Journals) nativeMap E sourceLength targetLength) s.main.nativePath) = s.main.nativePath ∧
    (uaStructureIdentity (S := Journals) (T := Journals) nativeMap E sourceSum targetSum).symm
      ((uaStructureIdentity (S := Journals) (T := Journals) nativeMap E sourceSum targetSum) s.variation.nativePath) = s.variation.nativePath :=
  ⟨s.main.native_recovery, s.variation.native_recovery⟩

theorem negative : IsEmpty (NativePath E sourceLength badTarget) := s.reject

end JournalTrial.Oracle
