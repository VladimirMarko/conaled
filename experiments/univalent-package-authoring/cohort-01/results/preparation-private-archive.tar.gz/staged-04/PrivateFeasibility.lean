import TrialTask

set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option backward.isDefEq.respectTransparency false
set_option warningAsError true
namespace JournalTrial.Private
open CategoryTheory SquareKit.Cubical SquareKit.Cubical.Presheaf
open Examples.CubicalStateTransport Examples.CubicalStatePackageFamily
open Examples.CubicalStatePackageUa Examples.CubicalStructuredState
open Examples.CubicalUnivalenceTransport Examples.CubicalGlue

 theorem carrier (E : HomotopyEquivalence nativeMap) :
    admittedCarrier (S := Journals) (T := Journals) nativeMap E = reverseJournals := by
  apply Equiv.ext
  intro s
  change (constantLocal _ Journals).decodeCodeIso.hom.app point
    ((codeIso reverseJournals).hom.app point
      ((constantLocal _ Journals).decodeCodeIso.inv.app point s)) = reverseJournals s
  exact congrArg (fun t => t.val point) (codeIso_action reverseJournals s)

 theorem length_eq : sourceLength.conjugate reverseJournals = targetLength := by
  apply statePackage_ext
  · rfl
  · funext s
    simp [StatePackage.conjugate, reverseJournals, sourceLength, targetLength]
  · funext s
    simp [StatePackage.conjugate, reverseJournals, sourceLength, targetLength]

 theorem sum_eq : sourceSum.conjugate reverseJournals = targetSum := by
  apply statePackage_ext
  · rfl
  · funext s
    simp [StatePackage.conjugate, reverseJournals, sourceSum, targetSum]
  · funext s
    simp [StatePackage.conjugate, reverseJournals, sourceSum, targetSum]

noncomputable def construct (E : HomotopyEquivalence nativeMap)
    (p q : StatePackage Journals) (h : p.conjugate reverseJournals = q) : Construction E p q where
  nativePath := (uaStructureIdentity (S := Journals) (T := Journals) nativeMap E p q).symm
    (Preserves.of_eq (by rw [carrier E]; exact h))
  nativeSection := transported (S := Journals) (T := Journals) nativeMap E p
  section_exact := rfl
  section_recovery := transported_recovery (S := Journals) (T := Journals) nativeMap E p
  decoded := targetPackage (S := Journals) (T := Journals) nativeMap E p
  decoded_exact := rfl
  decoded_target := by rw [targetPackage_eq, carrier E]; exact h
  native_recovery := (uaStructureIdentity (S := Journals) (T := Journals) nativeMap E p q).symm_apply_apply _

noncomputable def answer (E : HomotopyEquivalence nativeMap) : Submission E where
  main := construct E sourceLength targetLength length_eq
  variation := construct E sourceSum targetSum sum_eq
  reject := ⟨fun r => by
    have h := ((uaStructureIdentity (S := Journals) (T := Journals) nativeMap E sourceLength badTarget) r).invariant
    rw [carrier E] at h
    have hx := congrFun h (([0] : List Nat), [])
    change (([0] : List Nat).reverse.length = ([] : List Nat).reverse.length) = True at hx
    simp at hx⟩

end JournalTrial.Private
