import Examples.CubicalFiniteStateIdentity
import Mathlib.Algebra.BigOperators.Group.List.Basic

set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option warningAsError true
namespace JournalTrial
open CategoryTheory SquareKit.Cubical SquareKit.Cubical.Presheaf
open Examples.CubicalStateTransport Examples.CubicalStatePackageFamily
open Examples.CubicalStatePackageUa Examples.CubicalStructuredState
open Examples.CubicalUnivalenceTransport Examples.CubicalGlue

abbrev Journals := List Nat × List Nat

def reverseJournals : Journals ≃ Journals where
  toFun s := (s.1.reverse, s.2.reverse)
  invFun s := (s.1.reverse, s.2.reverse)
  left_inv s := by cases s; simp
  right_inv s := by cases s; simp

def sourceLength : StatePackage Journals where
  initial := ([], [])
  step s := (s.1 ++ [1], s.2 ++ [1])
  invariant s := s.1.length = s.2.length
  initial_valid := rfl
  preserves s h := by simpa using h

def targetLength : StatePackage Journals where
  initial := ([], [])
  step s := (1 :: s.1, 1 :: s.2)
  invariant s := s.1.length = s.2.length
  initial_valid := rfl
  preserves s h := by simpa using h

/-- Changed dependent field: equal totals permits journals of different lengths. -/
def sourceSum : StatePackage Journals where
  initial := ([], [])
  step s := (s.1 ++ [1], s.2 ++ [1])
  invariant s := s.1.sum = s.2.sum
  initial_valid := rfl
  preserves s h := by simpa using h

def targetSum : StatePackage Journals where
  initial := ([], [])
  step s := (1 :: s.1, 1 :: s.2)
  invariant s := s.1.sum = s.2.sum
  initial_valid := rfl
  preserves s h := by simpa using h

/-- Same initial point and transition; the invariant was incorrectly discarded. -/
def badTarget : StatePackage Journals where
  initial := ([], [])
  step s := (1 :: s.1, 1 :: s.2)
  invariant _ := True
  initial_valid := trivial
  preserves _ _ := trivial

noncomputable def nativeMap := (codeIso reverseJournals).hom

/-- The original supplied contraction is a parameter, never reconstructed. -/
noncomputable abbrev NativePath (E : HomotopyEquivalence nativeMap)
    (p q : StatePackage Journals) :=
  StructuredPath (admittedLine nativeMap E) (admittedPresentation nativeMap E)
    (admittedCarrier nativeMap E) p q

/-- Common interface for both arms. Fields intentionally name the native baseline,
so a decoded answer without an actual path and filling cannot pass. -/
structure Construction (E : HomotopyEquivalence nativeMap)
    (p q : StatePackage Journals) where
  nativePath : NativePath E p q
  nativeSection : Term (package (admittedLine nativeMap E)).family
  section_exact : nativeSection = transported nativeMap E p
  section_recovery : nativeSection = pullPackage (admittedLine nativeMap E)
    (admittedPresentation nativeMap E) (p.conjugate (admittedCarrier nativeMap E))
  decoded : StatePackage Journals
  decoded_exact : decoded = targetPackage nativeMap E p
  decoded_target : decoded = q
  native_recovery : (uaStructureIdentity nativeMap E p q).symm
    ((uaStructureIdentity nativeMap E p q) nativePath) = nativePath

structure Submission (E : HomotopyEquivalence nativeMap) where
  main : Construction E sourceLength targetLength
  variation : Construction E sourceSum targetSum
  reject : IsEmpty (NativePath E sourceLength badTarget)

end JournalTrial
