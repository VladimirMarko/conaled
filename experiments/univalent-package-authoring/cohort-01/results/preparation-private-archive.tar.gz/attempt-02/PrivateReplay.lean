import PrivateFeasibility
import PrivateFacadeFeasibility
import PrivateOracle

namespace JournalTrial.PrivateReplay
open SquareKit.Cubical
variable (E : HomotopyEquivalence nativeMap)
example := Oracle.complete_packages E (Private.answer E)
example := Oracle.all_observations E (Private.answer E)
example := Oracle.separating_observations E (Private.answer E)
example := Oracle.section_decodes E (Private.answer E)
example := Oracle.variation_section_decodes E (Private.answer E)
example := Oracle.sections_recovered E (Private.answer E)
example := Oracle.path_start E (Private.answer E)
example := Oracle.path_finish E (Private.answer E)
example := Oracle.variation_path_start E (Private.answer E)
example := Oracle.variation_path_finish E (Private.answer E)
example := Oracle.paths_recovered E (Private.answer E)
example := Oracle.negative E (Private.answer E)
example := Oracle.complete_packages E (PrivateFacade.answer E)
example := Oracle.all_observations E (PrivateFacade.answer E)
example := Oracle.separating_observations E (PrivateFacade.answer E)
example := Oracle.section_decodes E (PrivateFacade.answer E)
example := Oracle.variation_section_decodes E (PrivateFacade.answer E)
example := Oracle.sections_recovered E (PrivateFacade.answer E)
example := Oracle.path_start E (PrivateFacade.answer E)
example := Oracle.path_finish E (PrivateFacade.answer E)
example := Oracle.variation_path_start E (PrivateFacade.answer E)
example := Oracle.variation_path_finish E (PrivateFacade.answer E)
example := Oracle.paths_recovered E (PrivateFacade.answer E)
example := Oracle.negative E (PrivateFacade.answer E)
#print axioms Private.answer
#print axioms PrivateFacade.answer
#print axioms Oracle.all_observations
#print axioms Oracle.sections_recovered
#print axioms Oracle.paths_recovered
#print axioms Oracle.negative
end JournalTrial.PrivateReplay
