import PrivateFeasibility
import Examples.CubicalAuthorTransport

set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option warningAsError true
namespace JournalTrial.PrivateFacade
open CategoryTheory SquareKit.Cubical SquareKit.Cubical.Presheaf
open Examples.CubicalStateTransport Examples.CubicalStructuredState
open Examples.CubicalAuthorTransport

noncomputable def change (E : HomotopyEquivalence nativeMap) : Change Journals Journals :=
  ⟨nativeMap, E⟩

noncomputable def construct (E : HomotopyEquivalence nativeMap)
    (p q : StatePackage Journals) (h : p.conjugate reverseJournals = q) : Construction E p q := by
  have hp : Preserves (change E).carrier p q :=
    Preserves.of_eq (by change p.conjugate (admittedCarrier nativeMap E) = q; rw [Private.carrier E]; exact h)
  exact {
    nativePath := (change E).path hp
    nativeSection := (change E).nativeSection p
    section_exact := rfl
    section_recovery := (change E).native_recovery p
    decoded := (change E).transport p
    decoded_exact := rfl
    decoded_target := (change E).transport_of_preserves hp
    native_recovery := (change E).path_recovery _ }

noncomputable def answer (E : HomotopyEquivalence nativeMap) : Submission E where
  main := construct E sourceLength targetLength Private.length_eq
  variation := construct E sourceSum targetSum Private.sum_eq
  reject := (Private.answer E).reject

end JournalTrial.PrivateFacade
