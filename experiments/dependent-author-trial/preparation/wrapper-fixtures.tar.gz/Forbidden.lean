def forbiddenValue : Nat := 9
