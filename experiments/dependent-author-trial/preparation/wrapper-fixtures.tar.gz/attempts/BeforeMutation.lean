example : True := True.intro
