import Support
example : supportValue = 7 := rfl
