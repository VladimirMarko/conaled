#eval do
  IO.FS.writeFile "attempts/interrupt-ready" "ready"
  IO.sleep 10000
