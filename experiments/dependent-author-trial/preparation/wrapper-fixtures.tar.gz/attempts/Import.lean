import Forbidden
example : forbiddenValue = 9 := rfl
