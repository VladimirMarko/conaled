import Support
example : supportValue = 8 := rfl
