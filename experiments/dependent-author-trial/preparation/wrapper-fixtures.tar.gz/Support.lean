def supportValue : Nat := 7
