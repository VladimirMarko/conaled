import GraphDeclarations
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option cbv.maxSteps 10000000
example : (Expr.sort .zero).bvarBRaw = 0 := by cbv
example : (Expr.const eqName [.zero]).bvarBRaw = 0 := by cbv
