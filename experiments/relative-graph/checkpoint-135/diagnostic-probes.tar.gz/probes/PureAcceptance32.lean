import GraphDeclarations
import ConLeche.Model.Fold
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option cbv.maxSteps 10000000
example : checkDeclsPure .verified (fueledOps .verified 32) [] GraphDeclarations.declarations.toList =
  .ok GraphDeclarations.environment := by cbv
