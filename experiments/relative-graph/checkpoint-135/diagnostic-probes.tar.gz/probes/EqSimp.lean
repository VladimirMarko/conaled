import GraphDeclarations
open ConLeche ConLeche.Cached
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
example : Cached.checkDecls .verified [] #[.indDecl eqBasis 2] = .ok ⟨[eqRecA, eqReflA, eqA], []⟩ := by
  simp only [checkDecls, ← Array.foldlM_toList, Array.toList_mk, List.foldlM_cons, List.foldlM_nil]
  simp only [installDeclStep, andPinOk, installStepC, checkDeclStepC, checkDeclC]
  trace_state
