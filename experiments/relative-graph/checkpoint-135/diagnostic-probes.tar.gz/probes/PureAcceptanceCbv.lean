import GraphDeclarations
import ConLeche.Model.Fold
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
example : checkDeclsPure .verified (fueledOps .verified 256) [] GraphDeclarations.declarations.toList =
  .ok GraphDeclarations.environment := by cbv
