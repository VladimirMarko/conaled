import AndPositivityStages
set_option pp.maxSteps 500
open ConLeche AcceptanceStages.Reference AndPositivityStages
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option cbv.maxSteps 10000000
attribute [local cbv_eval] Expr.bvarBRaw_bvar Expr.bvarBRaw_fvar Expr.bvarBRaw_sort Expr.bvarBRaw_const Expr.bvarBRaw_lit Expr.bvarBRaw_app Expr.bvarBRaw_lam Expr.bvarBRaw_forallE Expr.bvarBRaw_letE Expr.bvarBRaw_proj Expr.fvarBRaw_bvar Expr.fvarBRaw_fvar Expr.fvarBRaw_sort Expr.fvarBRaw_const Expr.fvarBRaw_lit Expr.fvarBRaw_app Expr.fvarBRaw_lam Expr.fvarBRaw_forallE Expr.fvarBRaw_letE Expr.fvarBRaw_proj Expr.hasLP_bvar Expr.hasLP_fvar Expr.hasLP_sort Expr.hasLP_const Expr.hasLP_lit Expr.hasLP_app Expr.hasLP_lam Expr.hasLP_forallE Expr.hasLP_letE Expr.hasLP_proj

example : (match nestRoot (fueledOps .verified 32) indsResult.1 ctx holes ctorResult.1 {} with | .ok _ => true | .error _ => false) = true := by
  have hinst : andIntroRaw.toConstantVal.type.instantiateLevelParams andIntroRaw.toConstantVal.levelParams
      [] = andIntroRaw.toConstantVal.type := rfl
  have hsort : (fueledOps .verified 32).ensureSort indsResult.1 3 (.sort (.imax .zero (.imax .zero .zero))) =
      .ok (.imax .zero (.imax .zero .zero)) := by cbv
  have hfuel : whnfWalkFuel crest = 1027 := by rw [whnfWalkFuel, CheckerReduction.depth_eq]; cbv
  simp only [ctorResult, nestRoot, nestCtors,
    show Name.nodup andIntroRaw.toConstantVal.levelParams = true from rfl,
    ↓reduceIte, hinst,
    show ctx.lps.map Level.param = [] from rfl,
    crest_ok, unwrapOr, bind, pure, Except.pure, Except.bind,
    show ctx.hiAt 0 = 3 from rfl, inferCrest, hsort, hfuel, fieldsCrest]
  have hguard : ((List.range 2).any fun i =>
      ([NestFieldKind.ordinary, .ordinary].getD i .ordinary != .ordinary) &&
        structUsedLater (closeTelescope [.fvar 0 (.sort .zero), .fvar 1 (.sort .zero)] 3
          (.fvar 2 (.sort .zero))) 0 i) = false := rfl
  have hres : (nestResHead (.fvar 2 (.sort .zero)) &&
      (Expr.fvar 2 (.sort .zero)).getAppArgs.all (fun x => !x.nestOcc ctx.names ctx.nP 3)) = true := rfl
  have hclose : closeTelescope [.fvar 0 (.sort .zero), .fvar 1 (.sort .zero)] 3 (.fvar 2 (.sort .zero)) = crest := by cbv
  simp only [hguard, hres, Bool.false_eq_true, ↓reduceIte]
  rfl
