import CheckerReduction
import GraphDeclarations
import ConLeche.Model.Fold
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option cbv.maxSteps 10000000
attribute [local cbv_eval] Expr.bvarBRaw_bvar Expr.bvarBRaw_fvar Expr.bvarBRaw_sort Expr.bvarBRaw_const Expr.bvarBRaw_lit Expr.bvarBRaw_app Expr.bvarBRaw_lam Expr.bvarBRaw_forallE Expr.bvarBRaw_letE Expr.bvarBRaw_proj Expr.fvarBRaw_bvar Expr.fvarBRaw_fvar Expr.fvarBRaw_sort Expr.fvarBRaw_const Expr.fvarBRaw_lit Expr.fvarBRaw_app Expr.fvarBRaw_lam Expr.fvarBRaw_forallE Expr.fvarBRaw_letE Expr.fvarBRaw_proj Expr.hasLP_bvar Expr.hasLP_fvar Expr.hasLP_sort Expr.hasLP_const Expr.hasLP_lit Expr.hasLP_app Expr.hasLP_lam Expr.hasLP_forallE Expr.hasLP_letE Expr.hasLP_proj

@[local cbv_eval] theorem canonEq_self (xs : List ConstantInfo) : canonEqList xs xs = true := by
  simp [canonEqList]
attribute [local cbv_eval] CheckerReduction.depth_eq
def eqEnv : Env := ⟨[eqRecA, eqReflA, eqA], []⟩
def andEnv : Env := ⟨(andPin.map GraphEnvironment.storedProposition).reverse ++ eqEnv.consts, [GraphEnvironment.andTable]⟩
example : checkDecl .verified (fueledOps .verified 32) [] eqEnv (.indDecl andPin 2) = .ok andEnv := by cbv
