import GraphDeclarations
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
#reduce (types := true) (proofs := true) (match Cached.checkDecls .verified [] GraphEnvironment.declarations with | .ok _ => true | .error _ => false)
