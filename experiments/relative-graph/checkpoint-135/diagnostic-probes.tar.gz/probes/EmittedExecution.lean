import EmittedEnvironment
import ConLeche.Model.Fold
open ConLeche
#eval match checkDeclsPure .verified (fueledOps .verified 64) [] EmittedEnvironment.declarations with
  | .ok _ => "Accepted actual emitted family"
  | .error e => reprStr e
