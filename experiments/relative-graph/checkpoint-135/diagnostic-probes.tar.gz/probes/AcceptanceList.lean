import GraphDeclarations
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
example : Cached.checkDecls .verified [] GraphDeclarations.declarations =
    .ok GraphDeclarations.environment := by
  unfold Cached.checkDecls
  rw [← Array.foldlM_toList]
  rfl
