import EmissionSemantics
set_option pp.explicit true in
#check @SquareKit.Internal.Env.extend
set_option pp.explicit true in
#check @EmissionSemantics.interpretation
set_option pp.explicit true in
#check @EmissionSemantics.Laws
set_option pp.explicit true in
#check @GraphAdapter.Member
