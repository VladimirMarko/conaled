import GraphDeclarations
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
def succeeds : Bool := match Cached.checkDecls .verified [] GraphDeclarations.declarations with
  | .ok _ => true | .error _ => false
example : succeeds = true := by decide +kernel
