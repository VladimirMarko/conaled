import AndPositivityStages
set_option pp.maxSteps 500
open ConLeche AcceptanceStages.Reference AndPositivityStages
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option cbv.maxSteps 10000000
attribute [local cbv_eval] Expr.bvarBRaw_bvar Expr.bvarBRaw_fvar Expr.bvarBRaw_sort Expr.bvarBRaw_const Expr.bvarBRaw_lit Expr.bvarBRaw_app Expr.bvarBRaw_lam Expr.bvarBRaw_forallE Expr.bvarBRaw_letE Expr.bvarBRaw_proj Expr.fvarBRaw_bvar Expr.fvarBRaw_fvar Expr.fvarBRaw_sort Expr.fvarBRaw_const Expr.fvarBRaw_lit Expr.fvarBRaw_app Expr.fvarBRaw_lam Expr.fvarBRaw_forallE Expr.fvarBRaw_letE Expr.fvarBRaw_proj Expr.hasLP_bvar Expr.hasLP_fvar Expr.hasLP_sort Expr.hasLP_const Expr.hasLP_lit Expr.hasLP_app Expr.hasLP_lam Expr.hasLP_forallE Expr.hasLP_letE Expr.hasLP_proj

theorem inferCrest : (fueledOps .verified 32).inferType indsResult.1 3 crest = .ok (.sort (.imax .zero (.imax .zero .zero))) := by cbv
theorem crest_ok : nestCrest ctx.names [] ctx.params holes andIntroRaw.toConstantVal.type = some crest := by cbv

def rootResult : List (List (List NestFieldKind × Expr)) × NestState :=
  ([[([.ordinary, .ordinary], crest)]],
    { ctorNfs := #[nestCtorNf ctx [] 3 [] ctx.params andIntroRaw.toConstantVal
      [.fvar 0 (.sort .zero), .fvar 1 (.sort .zero)] (.fvar 2 (.sort .zero))] })
example : nestRoot (fueledOps .verified 32) indsResult.1 ctx holes ctorResult.1 {} = .ok rootResult := by
  simp only [ctorResult, nestRoot, nestCtors]
  simp only [show Name.nodup andIntroRaw.toConstantVal.levelParams = true from rfl, Bool.not_true,
    Bool.false_eq_true, ↓reduceIte, bind, pure, Except.pure, Except.bind]
  rw [show andIntroRaw.toConstantVal.type.instantiateLevelParams andIntroRaw.toConstantVal.levelParams (ctx.lps.map Level.param) = andIntroRaw.toConstantVal.type from rfl]
  rw [show ctx.lps.map Level.param = [] from rfl, crest_ok]
  simp only [unwrapOr, bind, pure, Except.pure, Except.bind]
  rw [show ctx.hiAt 0 = 3 from rfl, inferCrest]
  simp only [bind, pure, Except.pure, Except.bind]
  rw [show (fueledOps .verified 32).ensureSort indsResult.1 3 (.sort (.imax .zero (.imax .zero .zero))) = .ok (.imax .zero (.imax .zero .zero)) from rfl]
  simp only [bind, pure, Except.pure, Except.bind]
  fail "before fuel"
