import GraphDeclarations
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
example : Cached.checkDecls .verified [] #[] = .ok Env.empty := by rfl
example : Cached.checkDecls .verified [] #[.indDecl eqBasis 2] =
  .ok ⟨[eqRecA, eqReflA, eqA], []⟩ := by rfl
set_option pp.all false in
#reduce (types := true) (proofs := true) (match Cached.checkDecls .verified [] #[.indDecl eqBasis 2] with | .ok _ => true | .error _ => false)
