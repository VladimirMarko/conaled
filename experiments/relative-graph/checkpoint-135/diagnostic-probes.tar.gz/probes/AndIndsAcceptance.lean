import GraphDeclarations
import ConLeche.Model.Fold
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option cbv.maxSteps 10000000
attribute [local cbv_eval] Expr.bvarBRaw_bvar Expr.bvarBRaw_fvar Expr.bvarBRaw_sort Expr.bvarBRaw_const Expr.bvarBRaw_lit Expr.bvarBRaw_app Expr.bvarBRaw_lam Expr.bvarBRaw_forallE Expr.bvarBRaw_letE Expr.bvarBRaw_proj Expr.fvarBRaw_bvar Expr.fvarBRaw_fvar Expr.fvarBRaw_sort Expr.fvarBRaw_const Expr.fvarBRaw_lit Expr.fvarBRaw_app Expr.fvarBRaw_lam Expr.fvarBRaw_forallE Expr.fvarBRaw_letE Expr.fvarBRaw_proj Expr.hasLP_bvar Expr.hasLP_fvar Expr.hasLP_sort Expr.hasLP_const Expr.hasLP_lit Expr.hasLP_app Expr.hasLP_lam Expr.hasLP_forallE Expr.hasLP_letE Expr.hasLP_proj

def eqEnv : Env := ⟨[eqRecA, eqReflA, eqA], []⟩
def parts := (blockParts? 2 andPin).getD default
example : (match checkBlockInds (fueledOps .verified 32) eqEnv parts false with | .ok _ => true | .error _ => false) = true := by cbv
