import GraphDeclarations
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
attribute [local reducible] checkFuel
example : Cached.checkDecls .verified [] GraphDeclarations.declarations =
    .ok GraphDeclarations.environment := by rfl
