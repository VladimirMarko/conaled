import GraphDeclarations
import ConLeche.Model.Fold
open ConLeche
#eval [8,16,32,64].map fun fuel => (fuel, match checkDeclsPure .verified (fueledOps .verified fuel) [] GraphDeclarations.declarations.toList with | .ok _ => true | .error _ => false)
