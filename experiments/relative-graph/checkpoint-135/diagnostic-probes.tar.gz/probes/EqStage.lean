import GraphDeclarations
open ConLeche ConLeche.Cached
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
theorem eqPin : basisPinHit eqBasis = some .eqK := by
  simp [basisPinHit, BasisKind.decls, canonEqList]
theorem eqGuard : andPinOk (.indDecl eqBasis 2) = true := by
  decide +kernel
example : Cached.checkDecls .verified [] #[.indDecl eqBasis 2] = .ok ⟨[eqRecA, eqReflA, eqA], []⟩ := by
  simp only [checkDecls, ← Array.foldlM_toList, List.foldlM_cons, List.foldlM_nil]
  simp only [installDeclStep, eqGuard, ↓reduceIte, installStepC, checkDeclStepC, checkDeclC, eqPin]
  rfl
