import GraphDeclarations
import ConLeche.Model.Fold
open ConLeche
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
theorem eqPin : basisPinHit eqBasis = some .eqK := by
  simp [basisPinHit, BasisKind.decls, canonEqList]
example : checkDeclsPure .verified (fueledOps .verified 64) [] GraphDeclarations.declarations.toList =
  .ok GraphDeclarations.environment := by
  simp only [checkDeclsPure, GraphDeclarations.declarations, GraphEnvironment.declarations,
    Array.toList_append, List.append, List.foldlM_cons, List.foldlM_nil, checkDecl, eqPin]
  trace_state
