import GraphDeclarations
open ConLeche Lean Meta Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
run_elab do
 let e ← Lean.Elab.Term.elabTerm (← `(Cached.checkDecls .verified [] #[.indDecl eqBasis 2])) none
 let r ← withTransparency .all (whnf e)
 logInfo m!"{r}"
