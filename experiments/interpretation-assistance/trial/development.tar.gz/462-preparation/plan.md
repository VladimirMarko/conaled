# #462 preparation: finite interpretation assistance

Read-only preparation at staged integration `2fb83d0e4e3ca5101d18bbd78873b3dd50a5a07a`.
Live issues #462, #290 and #235 were read. No prototype or author trial has been
started. The owner is AFK; broader architectural adoption remains held.

## Feasible bounded implementation

Use a command-line planner with a finite registry of typed Lean route templates.
Its input is registered construction ID, target/map IDs, observation ID and
optional named law declarations. Preserve the option to emit a direct native
proof skeleton. Do not add a universal construction type or force every entry
through `DiagonalConstruction.Map`.

The proposed implementation has three distinct stages:

1. Registry lookup returns applicable named route schemas and requested
   propositions. It may return no registered route. This is bounded discovery,
   never a proof that an interpretation does not exist.
2. A generated Lean request module applies the chosen schema to the concrete
   registered data. Lean checks each supplied certificate against the requested
   type and checks the final result. Export the exact generated file, hashes,
   compiler identity, command and diagnostics. Successful process exit alone
   is insufficient: require the requested declaration to be present and audit
   its actual axioms, including local/generated helper declarations.
3. The CLI displays the chosen code/state expression, observation expression,
   established laws and unfilled goals, tied to named request declarations and
   source locations. No missing proof is compiled using `sorry`, an added axiom
   or unchecked dummy data. Print obligations as Lean types; a pretty summary
   supplements that type rather than replacing it.

Prefer Python for fixed-registry orchestration and a small Lean checker module
for typed request checking/printing. Reuse native Lean elaboration; do not parse
Lean proof text using Python regexes. Arbitrary user Lean input is outside this
finite prototype's contract; optional certificate identifiers come from the
frozen registry or an explicitly named user module checked by Lean. An explicit
user module remains a trusted local input, not a sandboxed proof service.

## Initial registry and development examples

| Route | Existing declarations | Requested evidence / observations |
|---|---|---|
| Diagonal covered transport | `Map.selected`, `Map.witness_preserved`, `Map.comp` | Exact code, fixed value and all-input representation; surjective code map certificate |
| Diagonal local extension | `Map.Extension`, `selectedExtension`, `extension_comp`, `selectedExtension_comp_code`, `selectedExtension_comp_witness` | Off-image selected-row equation; retain exact mapped code and witness |
| Image-only transport | `imageMap`, `selectedImage` | Restricted target input type and its explicit image witness, visibly weaker domain |
| Lost selected code | `Examples.DiagonalConstruction.witness_forgetting_not_injective` | Display checked noninjectivity; value equality does not recover the selected code |
| Measured execution | `Resources.reweight_run`, `reweight_bind`, `Examples.ConstructionTransport.Fold.compiled_reweighted_run` | Additive map, actual transition/seed costs and requested value/resource observation |
| Optional guarded stream route | `run_interpretation`, `selected_compiled`, `selected_quotient` | Constructor equations and retained state; no runtime scheduler claim |

Use #461's `good`, `larger`, `partialPresentation`, and composed resource scales
as development fixtures. Accepted diagonal composition must emit actual Lean
application evidence. `omitted_extension_rejected` must be distinguished from
absence of a supplied certificate: it is a checked negation of this specific
extension proposition. The erasure fixture should display the checked loss and
retain the original data as an available alternative, never invent a selector.

Implement the diagonal and resource routes first. The stream route is optional
unless the chosen held-out tasks require it. #460 reflection is optional and
must not delay the initial prototype.

## Status vocabulary and executable tests

- `checked`: final requested declaration was checked and audited at the receipt.
- `rejected evidence`: supplied term fails its declared proposition. Preserve
  Lean diagnostics; this is not a proof that the proposition is false.
- `missing evidence`: named obligation has no supplied certificate; show its type.
- `refuted obligation`: a separately checked theorem proves the negation of the
  exact proposition for this registered example. Scope the conclusion to it.
- `registry exhausted`: no listed route meets the input IDs/observation. This
  does not prove there is no route outside the registry.
- `checker failure`: process/environment/type-loading failure, not mathematics.

Test these separately with actual checker executions, not mocked success strings.
Include wrong-type certificates, unchanged omitted-input rejection, successful
composition, resource execution, selected-code loss and unknown registry IDs.
Change a valid certificate to an invalid one and ensure the cached success is
not reused. An audit fixture containing an otherwise valid result with a
forbidden dependency must fail. Receipt hashes cover inputs, registry, generated
source and checker/toolchain; cached display cannot silently upgrade evidence.

## Sequence and decisions

Freeze scope/schema and independent task contracts; implement typed checker and
negative cases; implement diagnostics; freeze reviewed prototype/docs/registry;
prepare isolated author environments; freeze trial manifest; dispatch authors;
replay frozen attempts and audit; assess incremental benefit and cost. Full
repository acceptance and independent Standards/Spec review remain required.

No architecture change is needed to test this finite CLI. A plugin system,
general elaborator tactic, proof importer, automated synthesis, universal
transport record, or repository migration would be a separate decision and is
not adopted while the owner is absent. #235/#290 retain those decisions.
