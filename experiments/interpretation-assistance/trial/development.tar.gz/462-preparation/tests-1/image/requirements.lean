import SquareKit.InterpretationDiagnostics
import Examples.DiagonalCoverage

namespace Requested
def selectedSource := Examples.DiagonalConstruction.sourceSelected
def route := Examples.DiagonalConstruction.partialPresentation
def requestPresent : Unit := ()
#transport_audit Requested.requestPresent

end Requested
