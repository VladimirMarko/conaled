import SquareKit.InterpretationDiagnostics
import Examples.DiagonalCoverage

namespace Requested
def selectedSource := Examples.DiagonalConstruction.sourceSelected
def route := Examples.DiagonalConstruction.partialPresentation
def requestPresent : Unit := ()
def result := route.selectedImage selectedSource
#check result.code
#check result.witness
#transport_audit Requested.result

end Requested
