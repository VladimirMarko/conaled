import SquareKit.InterpretationDiagnostics
import Examples.DiagonalCoverage

namespace Requested
def selectedSource := Examples.DiagonalConstruction.sourceSelected
def route := Examples.DiagonalConstruction.partialPresentation
def requirement_0 : Prop := SquareKit.DiagonalConstruction.Map.Extension route selectedSource
#transport_requirement Requested.requirement_0
def requestPresent : Unit := ()
theorem refuted : ¬ requirement_0 := Examples.DiagonalCoverage.omitted_extension_rejected
#transport_audit Requested.refuted

end Requested
