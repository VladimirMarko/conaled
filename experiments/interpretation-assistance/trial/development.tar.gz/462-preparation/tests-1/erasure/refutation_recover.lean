import SquareKit.InterpretationDiagnostics
import Examples.DiagonalConstruction

namespace Requested
def requirement_0 : Prop := Function.Injective (fun s : SquareKit.DiagonalConstruction.Selected (fun _ _ : Bool => ()) id => s.witness)
#transport_requirement Requested.requirement_0
def requestPresent : Unit := ()
theorem refuted : ¬ requirement_0 := Examples.DiagonalConstruction.witness_forgetting_not_injective
#transport_audit Requested.refuted

end Requested
