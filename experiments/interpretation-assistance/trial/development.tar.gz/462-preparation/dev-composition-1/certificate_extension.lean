import SquareKit.InterpretationDiagnostics
import Examples.DiagonalCoverage

namespace Requested
def selectedSource := Examples.DiagonalConstruction.sourceSelected
def route := (Examples.DiagonalCoverage.larger.comp Examples.DiagonalCoverage.good)
def requirement_0 : Prop := SquareKit.DiagonalConstruction.Map.Extension route selectedSource
#transport_requirement Requested.requirement_0
def requestPresent : Unit := ()
theorem certificate_0 : requirement_0 := SquareKit.DiagonalConstruction.Map.extension_comp Examples.DiagonalCoverage.good Examples.DiagonalCoverage.larger Examples.DiagonalConstruction.sourceSelected Examples.DiagonalCoverage.good_extra Examples.DiagonalCoverage.larger_extra
#transport_audit Requested.certificate_0

end Requested
