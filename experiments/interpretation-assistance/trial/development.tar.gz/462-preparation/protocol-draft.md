# Draft protocol for #462 (not frozen; do not launch)

Question: does the runnable finite-registry tool remove concrete obligation
identification or certificate-application work relative to direct Lean, under
identical mathematical contracts? This tests a tool, not whether native
preservation theorems exist. Both arms may use the same native theorems.

## Development / held-out separation

Development examples are exactly the #444/#461 Bool/Unit omitted-code case,
constant-true extension chain and squares with scalar resource reweighting.
The following proposed held-out contracts must be checked by a coordinator and
frozen before dispatch. They are new clients of supported route schemas;
neither successful final proof nor their exact diagnostic transcripts appears
in prototype documentation. Parameter changes alone are insufficient.

H1: selected-row extension with nonconstant target evaluation. Source codes are
Bool, evaluator `e c a = c`, step constantly false, selected code false. Target
codes are `Option Bool`, evaluator `e' c a = c.getD true`, step constantly false,
and code map `some`. Preserve the selected `some false` code, its value false,
and representation at every target input including `none`. Show the code map
is not onto, supply the missing local extension certificate, and compare the
full-target route with image restriction without claiming equal domains.
The target evaluator has different rows; the author must identify why the
selected row alone extends. A wrong proposed selected source code true is
rejected at its representation obligation, not accepted by value renaming.
This is structurally different from the development constant-true target.

H2: measured finite total compilation with product resource observations.
Use existing `Examples.RecursiveCompilation.total` for every integer list.
Interpret cost by `n ↦ (n, 2*n)` and then `(u,v) ↦ u+3*v` as additive maps.
Prove executed seed/transition transport and resulting observation
`(xs.sum, 7*(1+2*xs.length))`; recover the ordinary value and original counted
contract before reweighting. Include empty and `[1,2]` cases. Reject candidate
resource map `n ↦ n+1` at the zero law, with a checked counterexample. Its failure
does not imply that its final numeric expression is undefined or no other
resource model exists. This requires an intermediate product observation,
rather than renaming scalar weights in the prototype example.

Both proposals are mathematical specifications, not yet Lean-validated fixtures.
Private reference solutions and exact negative controls must pass before freeze.
If either proposal fails its intended meaning, revise before authors start and
record the reason. Do not change expectations after observing authors.

## Registry boundary

Freeze generic route templates separately from task-specific construction IDs.
A coordinator may add the held-out data declarations and names to a task registry
before trial freeze, without adding new route templates or final proof terms.
Both arms receive the same definitions and native API descriptions. The assisted
arm alone receives the CLI and its diagnostics. Otherwise a handcrafted solved
registry entry would conceal coordinator mathematical work as tool capability.

No registry or documentation edits during author attempts. Schema changes needed
by a held-out task return the prototype to preparation and require a new frozen
task; record that as a limitation, not a successful held-out result.

## Allocation and budget proposal

Use two independent fresh-context agents who did not implement the tool or write
reference solutions, one direct and one assisted. No crossover: both do H1 then
H2. Identical model configuration where available; record exact exposed model,
effort, toolchain and source pins. Unexposed model or token metadata is unknown,
not inferred. Author differences, fixed order and tiny sample limit conclusions.

Proposed cap per arm: 45 active minutes and 30 actual Lean feedback rounds across
both tasks. Each CLI invocation that runs Lean counts its internal checker
invocations separately; wrappers must log those counts. Read/search/CLI planning
without checking still counts elapsed time. Only logged provisioning/build-lock
waits with no other task work may be excluded. At either cap freeze immediately;
an already-started check may finish, with no more author edits afterward.
Freeze these numbers prospectively in the final reviewed protocol.

Prepare pinned isolated allowlisted handoffs, independently writable output
folders, available dependency caches and a neutral smoke check before launch.
Exclude reference solutions, prior author artifacts and other-arm output;
record hashes and allowed sources. Authors can read native library declarations
and public documentation, but cannot seek task-specific coaching, delegate,
change production interfaces or inspect the other arm. Any mathematical coaching
ends the independent attempt and starts separately labeled post-trial repair.

## Evidence and rubric

Retain every checked source snapshot, generated request, tool JSON/text output,
actual compiler command/start/end/exit, logs and final source hash. Log environment
repairs separately. Report both first-attempt and final success. Freeze files
before coordinator replay; do not feed reproduction failures back as author rounds.

Score each contract pass/partial/fail/unavailable, with exact declaration and
statement-review evidence. Required dimensions: all inputs; selected data and
observation unchanged; additive/extension laws supplied; composition through the
public result; negative-control scope; explicit distinction between missing,
rejected and refuted evidence. Alternative valid sufficient proofs pass. Do not
require a unique proof spelling or weakest assumption set.

Record concrete work: obligations discovered/supplied, tool-generated applications,
manual proofs, casts/wrappers, API searches, diagnostic-driven repairs, and unused
assistance. Separate prototype/task preparation, environment setup, and author
work. Count commands and elapsed time descriptively; proof lines alone and an
n=1 completion difference do not establish productivity or capability rankings.

Replay exact successful sources and audit all local/generated declarations.
Inspect diagnostic claims against the actual requested types, especially failure
at a sufficient condition versus impossibility of transport. Publish failed
attempts too. Decide adopt/investigate/defer/reject for the finite diagnostic
interface; synthesis or broader language adoption needs separately scoped evidence.
