theorem supplied : Examples.DiagonalCoverage.good.Extension Examples.DiagonalConstruction.sourceSelected := Examples.DiagonalCoverage.good_extra
