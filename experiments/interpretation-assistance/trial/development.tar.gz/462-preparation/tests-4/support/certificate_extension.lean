import SquareKit.InterpretationDiagnostics
import Examples.DiagonalCoverage

theorem supplied : Examples.DiagonalCoverage.good.Extension Examples.DiagonalConstruction.sourceSelected := Examples.DiagonalCoverage.good_extra

namespace Requested
def selectedSource := Examples.DiagonalConstruction.sourceSelected
def route := Examples.DiagonalCoverage.good
def requirement_0 : Prop := SquareKit.DiagonalConstruction.Map.Extension route selectedSource
#transport_requirement Requested.requirement_0
def requestPresent : Unit := ()
theorem certificate_0 : requirement_0 := supplied
#transport_audit Requested.certificate_0

end Requested
