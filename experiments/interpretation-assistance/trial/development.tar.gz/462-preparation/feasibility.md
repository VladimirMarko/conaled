# Feasibility and relation to earlier evidence

The initial prototype is feasible without a common recursion abstraction:
#461 supplies distinct native schemas, each with real preservation theorems.
A registry can label those schemas without identifying their mathematical
contracts. The main implementation risk is diagnostic fidelity, not search.
Showing a manually maintained checklist is insufficient: each displayed law
must be the proposition actually required by the generated Lean application.

Earlier #293 (`docs/research/proof-requirement-author-trial.md`) found both
manual and ledger-assisted authors successful and no demonstrated incremental
benefit. Its assistance sometimes retained a stronger sufficient law; missing
a weaker law did not retroactively fail the author. #462 must therefore check
whether executable typed obligations remove work beyond a static ledger.

The #235 preservation trials (`docs/research/preservation-architecture.md`)
found a direct bound proof simpler but an indexed facade removed casts.
Specialization value varies by contract. Permit direct native proofs here and
record when the registry adds ceremony. #249's
`docs/research/toolkit-author-effectiveness.md` also records an experimental
audit initially missing local declarations. Use an explicit trial-module root
scope and inspect it, not merely a passing audit message.

#25's prospective protocol supplies stronger freeze/logging practice: count
actual compiler feedback, retain every failed snapshot, distinguish provisioning
from author work and replay immutable submissions. Neither available author
model identity nor exact token/serving metadata should be invented.

Unresolved routine design choices before implementation: Lean checker protocol
for typed holes without admissions; concrete JSON schema; generated-source
locations; deterministic exit codes; dependency-isolated test harness. These can
be resolved locally with tests inside #462. Freeze them before author dispatch.

Major decisions held for the returning owner: adopting a general registry as
shared architecture, automatic proof/interpretation search beyond listed
candidates, general Lean importing, changing compiler/recursion contracts, or
claiming this tool should become the standard author interface. No such decision
is required for the bounded prototype. The current plan does not adopt one.

The proposed held-out H1/H2 tasks still need private reference checks and
independent protocol review. No trial should start from this planning document.
A narrow diagnostic remains a useful deliverable if the author comparison finds
no savings. A missing supported schema should be reported and scoped; do not
manufacture a universal positive result from the finite examples.

One concrete schema constraint: #461's `Fold.compiled_reweighted_run` specializes
resource codomain to `Nat`. H2 must use the existing polymorphic
`Resources.reweight_bind` and `Resources.reweight_run`, which support product
additive observations. The prototype should freeze that generic native template
before seeing H2 proofs, rather than extend a Nat-only template during the trial.
The compiler-definition unfolding needed to connect it is explicit caller/setup
work in both arms. This is a finite selection of existing generic declarations,
not a new shared framework.
