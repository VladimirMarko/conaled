import SquareKit.InterpretationDiagnostics
import Examples.DiagonalCoverage

theorem supplied : Examples.DiagonalCoverage.good.Extension Examples.DiagonalConstruction.sourceSelected := Examples.DiagonalCoverage.good_extra

namespace Requested
def selectedSource := Examples.DiagonalConstruction.sourceSelected
def route := Examples.DiagonalCoverage.good
def requirement_0 : Prop := SquareKit.DiagonalConstruction.Map.Extension route selectedSource
#transport_requirement Requested.requirement_0
def requestPresent : Unit := ()
#check selectedSource.code
#check selectedSource.witness
#check route.code selectedSource.code
#check route.value selectedSource.witness
theorem certificate_0 : requirement_0 := supplied
def result := route.selectedExtension selectedSource certificate_0
theorem observation : result.witness = route.value selectedSource.witness :=
  route.extension_witness selectedSource certificate_0
#check result.code
#check result.witness
#transport_audit Requested.result

end Requested
