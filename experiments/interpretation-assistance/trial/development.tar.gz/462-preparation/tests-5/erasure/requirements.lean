import SquareKit.InterpretationDiagnostics
import Examples.DiagonalConstruction

namespace Requested
def requirement_0 : Prop := Function.Injective (fun s : SquareKit.DiagonalConstruction.Selected (fun _ _ : Bool => ()) id => s.witness)
#transport_requirement Requested.requirement_0
def requestPresent : Unit := ()
#check Examples.DiagonalConstruction.erased false
#check Examples.DiagonalConstruction.erased true
#transport_audit Requested.requestPresent

end Requested
