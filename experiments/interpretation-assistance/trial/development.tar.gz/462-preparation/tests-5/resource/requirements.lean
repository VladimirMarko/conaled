import SquareKit.InterpretationDiagnostics
import Examples.ConstructionTransport
import SquareKit.InterpretationAssistance

namespace Requested
def weight : (Nat) → (Nat) := (Examples.ConstructionTransport.Fold.scale 3).comp (Examples.ConstructionTransport.Fold.scale 2)
def initial : Resources.Measured (Int) (Nat) := FirstOrderCompiler.compile Examples.RecursiveCompilation.counted.scalar Examples.RecursiveCompilation.seed ()
def transition : (Int) → (Int) → Resources.Measured (Int) (Nat) := Examples.ConstructionTransport.Fold.transition
def requirement_0 : Prop := weight 0 = 0
#transport_requirement Requested.requirement_0
def requirement_1 : Prop := ∀ a b : (Nat), weight (a+b) = weight a + weight b
#transport_requirement Requested.requirement_1
def requestPresent : Unit := ()
#check initial
#check transition
#check weight
#transport_audit Requested.requestPresent

end Requested
