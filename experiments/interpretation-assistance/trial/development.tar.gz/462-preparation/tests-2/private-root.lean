import SquareKit.InterpretationDiagnostics
namespace Fixture
private axiom hidden : True
theorem result : True := True.intro
#transport_audit Fixture.result
end Fixture
