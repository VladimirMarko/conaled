import SquareKit.InterpretationDiagnostics
import Examples.DiagonalCoverage

namespace Requested
def selectedSource := Examples.DiagonalConstruction.sourceSelected
def route := Examples.DiagonalCoverage.good
def requirement_0 : Prop := SquareKit.DiagonalConstruction.Map.Extension route selectedSource
#transport_requirement Requested.requirement_0
def requestPresent : Unit := ()
#check selectedSource.code
#check selectedSource.witness
#check route.code selectedSource.code
#check route.value selectedSource.witness
theorem certificate_0 : requirement_0 := Examples.DiagonalCoverage.good_extra
#transport_audit Requested.certificate_0

end Requested
