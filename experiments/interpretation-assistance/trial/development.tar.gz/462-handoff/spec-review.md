# #462 prototype and protocol Spec review

Outcome: **Prototype source findings resolved; author launch remains blocked on evidence.** This is preparation/prototype review, not full #462 acceptance. The author trial and resulting comparison have not occurred.

Current candidate `3b5c9002c9e799b00d01b6f1e0ca0dfe155d465b`, superseding reviewed `e8704a20e97dd01d2e7736df73322cdeec6276e0`; base `77960fad3c697fed44e4d525aa0157fdae9c10ea`. Reviewed all eleven changed files, the full saved issue, prior PROTO-1–4 findings, private-reference readiness result, frozen protocol, registry, real test outputs, and generated declarations/diagnostics. All nine source hashes in `prototype-freeze.json` match. No builds, author dispatches or source changes were performed.

## Prototype finding

**462-SPEC-1: resolved at 3b5c9002.** The earlier candidate collapsed process failures into evidence rejection during certificate checking. The correction preserves budget exhaustion separately, classifies nonstandard exit statuses and missing audit confirmation as checker failure, and requires an actual Lean JSON error diagnostic before treating exit 1 as ordinary evidence rejection.

`tests-9` retains three real fault cases after successful requirement inspection: infrastructure exit 74, terminated checker exit 241 through the runner, and runner failure exit 1 without a Lean error. All report `checker failure`. Genuine wrong-type and forbidden-axiom cases still report `rejected evidence`; the ordinary success, missing, refuted, exhausted, budget and support cases also pass. The fault launchers forward to actual Lake/Lean for the successful first stage rather than fabricating a passing checker message. I inspected the updated scripts, logs and receipts; all nine corrected freeze hashes match.

## Prototype assessment otherwise

The finite registry and four schemas respect the bounded contract. The extension route requires the actual selected-row proposition; image restriction has a visibly different type; erasure checks a particular noninjectivity result; resource transport uses a polymorphic additive observation theorem on executed seed and transitions. Composition consumes the actual native extension composition certificate. Missing, refuted and unknown-registry cases are separated in the retained ordinary tests. Generated accepted results have explicit declarations and typed applications.

`seeded_reweight` correctly composes the existing bind/run preservation laws without another induction or a Nat-only codomain. It is made available to both arms. Arithmetic simplification and the link to compiled execution remain explicit caller obligations, rather than a solved registry result disguised as tool benefit.

The audit inspects every current-module logical declaration and the requested result's dependencies. The real unused-private-axiom case fails, and forbidden proof evidence fails despite an otherwise valid result. Imported unused declarations are explicitly outside this local scope; the repository full audit and trial replay must cover their separate roots. Trusted local registry/support inputs and the absence of sandbox or cache-authentication guarantees are stated clearly. No broad architectural adoption occurs.

## Protocol finding reconciliation

**462-PROTO-1: partially resolved.** Direct mathematical feasibility and its negative controls passed independent private review. Private application through unchanged frozen templates is still absent. Preserve that gate, including proof/data separation and exact expected proposition matching. Do not treat ordinary development registry tests as held-out applicability evidence.

**462-PROTO-2: prospective policy resolved; concrete integration remains blocked.** The protocol now explicitly lists supplied setup versus author obligations for H1/H2, excludes solved certificates and final proofs from task entries, provides the common generic helper to both arms, and honestly discloses implementer visibility of task descriptions. Before launch, independently inspect the actual task-support files and registry diff against this table, record their hashes, and confirm that the generic template source did not change. Private proof sources/transcripts remain excluded.

**462-PROTO-3: prospective rules and basic enforcement implemented; concrete launch remains blocked.** The new protocol fixes 45 elapsed minutes, 30 actual Lean invocations, sequential arms on CPU0, all active time counted, no unlogged exclusions, and independent state/watchdog control. The CLI tests exercise refusal between internal checks, direct cap refusal, expired deadlines, cutoff snapshots and author support. The counter is incremented under a file lock before each invocation; source bytes and command receipts are retained. The watchdog is a cooperative cutoff copy with documented observation delay, not an OS permission boundary. The concrete launch manifest still needs exact prompts, allowlists, paths, toolchain/model metadata, coordinator watcher/interrupt supervision and scheduling. The corrected protocol explicitly requires complete-task submission filenames in the manifest and excludes mutable author-module imports. Helpers must be in the checked source or the included CLI support snapshot; imports are frozen and allowlisted. Verify the concrete handoffs implement those rules before launch.

**462-PROTO-4: prospective scoring resolved.** Mathematical completion, actual use of checked tool evidence and qualitative work removed are separate. Native fallback remains allowed, tool failure can coexist with mathematical success, and first/final/partial/fail/unavailable definitions and per-task checklists are fixed. Search/reading counts are qualitative unless fully logged. Tiny sample, order and author differences preclude general productivity ranking. Final task files must implement these unchanged checklists.

## Validation and remaining acceptance

`462-tests-9.log` and its retained receipts pass the real CLI/audit, external budget/support and three process-failure cases. The corrected full check in `462-corrected-full.log` passed all 2753 modules and the exhaustive three-axiom audit. `462-corrected-verification.json` and `462-corrected-verify.log` confirm exact candidate 3b5c9002; that validation gate is resolved. The new formal helper and audit implementation are unchanged by this correction.

Before author dispatch: complete private unchanged-template applicability, integrate and independently review the concrete task registry/support and launch manifest, and confirm root-owned exact validation. Full issue acceptance additionally requires retained independent trials, exact replay/audit, results, limits and owned follow-ups. No final author benefit claim is available yet.

Unresolved source findings: 0. 462-SPEC-1: resolved. Prelaunch evidence gates remain explicit. Prototype/prelaunch outcome: **Source review passed; launch blocked on evidence**. Full #462 Spec acceptance: **not yet eligible**.

Concrete launch draft review is recorded in `462-trial-preparation/launch-draft-review.md`. Common setup, registry additions, both handoff hashes and prompt hashes passed review. Private unchanged-template applicability, smoke evidence and immutable final launch manifest remain gates. No author launch is approved by this prototype report.

## Final prelaunch readiness update

The final immutable launch manifest `4596ee18af4569907dac7378ec488a45987434a79d34fbf942c9a0bfea2b3e9e` and private applicability/environment evidence passed independent review. See `462-trial-preparation/final-readiness-spec.md`. PROTO-1 through PROTO-4 are resolved for author launch; 462-SPEC-1 remains resolved. Both handoffs are clean, outputs empty and states uninitialized at review. Author launch is approved only under that frozen manifest. Full #462 acceptance remains pending actual trials, replay/audits and results review.
