# #462 prototype and protocol review handoff

Candidate `e8704a20e97dd01d2e7736df73322cdeec6276e0`, branch
`work/462-interpretation-diagnostics`, checkout
`/tmp/conaled-wave-20261111/worker462`. Exact incorporated base
`77960fad3c697fed44e4d525aa0157fdae9c10ea`. Source clean. Root full acceptance and
independent readiness reviews are active; do not edit this candidate.

Prototype freeze commit `feaa52e442506dcddb99bb25f0749fe15b3c67f9` precedes
coordinator task-registry integration and author dispatch. Merge e8704a20
resolved only entrypoint union, retaining BehavioralGames and both new modules
before final module documentation. No master or tracker changes by this worker.

## Scope and evidence

Finite schemas: diagonal Extension, image restriction, checked erasure
noninjectivity, and generic additive seeded resource execution. Actual Lean
request/certificate/result modules and local/generated root audit; seven
statuses separate missing/rejected/refuted evidence, exhaustion, tooling failure
and budget failure. No universal framework, importer, proof search or architectural
replacement. Resource helper works at arbitrary additive observation codomains.

Read experiments/interpretation-assistance/README.md, protocol.md,
prototype-freeze.json and docs/research/interpretation-assistance.md. The manifest
hashes implementation/docs/registry/protocol before private task-registry
integration. Formal statement review is in the report. Both native resource
proofs are visibly used by seeded_reweight; no new induction or fixed-point axiom.

Final focused support build: `/tmp/conaled-wave-20261111/462-focused-5.log`, exit0.
Final real executable suite: `/tmp/conaled-wave-20261111/462-tests-5.log`, exit0.
Every generated source, compiler diagnostic and receipt is retained in
`/tmp/conaled-wave-20261111/462-preparation/tests-5/` (99 files, ~484 KiB on disk).
Summary lists 13 named scenarios; additional direct-budget, deadline and cutoff
assertions are in the executable suite. Do not confuse a denied wrapper invocation
with an actual Lean round: `checker_started` distinguishes them.

Covered: accepted composition/image/resource, no evidence, wrong proof type,
exact omitted-code refutation, erased selected data, unknown registry entry,
missing import, sorryAx, unused private axiom, direct round cap, internal CLI
round cap, expired time cap, cutoff snapshot and author-supplied support.
All root worker commands finished. Python syntax and git diff checks passed.
Full exact-candidate build/audit remains root-owned.

Earlier evidence is preserved under 462-preparation/tests-{1,2,3,4}, the initial
composition receipt, focused logs1–4, and 462-tests-{1,2,3,4}. First resource
failure was AddMonoidHom positional constructor shape; repaired with named fields.
Budget harness initially reused a directory required to be new; repaired distinct
state/request directories. Initial checker compile failures needed explicit Lean
imports and inferred meta type annotations. Those logs remain; early checker
source snapshots were not separately archived beyond the tool conversation.
Full generated CLI attempts are retained. No author attempts exist yet.

Dependencies: initial Lake provisioning stopped with exit143 while fetching;
partial packages moved to 462-preparation/provisioning-partial-packages. The
checkout now links only pinned dependency packages from worker7 and has private
project outputs. No project artifact copying or shared writable project cache.

## Trial readiness

No authors launched. Root reports private direct H1/H2 checks and negative-control
statement review passed; no solutions or successful reference transcripts were
shared with this implementer. Task descriptions were visible and this is disclosed.

PROTO-2: protocol table identifies supplied definitions/Map/source-selection
proofs versus author extension/additive/final/negative obligations. Task-registry
diff must contain no author proofs or new templates.
PROTO-3: external runner atomically checks each round, snapshots source, and checks
elapsed deadline; CLI internal phases use same state. Separate coordinator watcher
snapshots author output at cutoff, with a documented 0.2-second observation delay.
Both arms run sequentially CPU0, no time exclusions, exact prompts/paths/allowlist
still required in the launch manifest. This is cooperative access, not OS isolation.
PROTO-4: math completion, actual tool use and work removed scored separately.
Native fallback stays allowed within the same budget; unavailable tooling is not
mathematical failure. Protocol fixes per-task checks and first/final/partial/fail.

Remaining gates: private applicability through unchanged templates; concrete
support/task registry hashes and diff; exact prompts/handoff/environment/model
metadata and runner/watchdog schedule; independent readiness confirmation. Root
must complete these before dispatch. Reproduction cannot add author feedback.
Broader architecture/search adoption remains held for owner.

## 462-SPEC-1 correction and renewed freeze

New candidate `3b5c9002c9e799b00d01b6f1e0ca0dfe155d465b`, same incorporated
base77960fad. Old freeze/history retained. The new manifest explicitly supersedes
e8704a20 before any author launch. No formal module changed in this correction.

Actual exits other than normal Lean0/1 and budget75 propagate checker failure.
Exit1 additionally requires an actual Lean JSON error diagnostic; a runner
traceback cannot be classified as rejected evidence. Missing audit confirmation
also remains a checker failure. Budget and checker failures use separate typed
exceptions. Runner74 is marked as not having started Lean in the CLI receipt.

Final suite `/tmp/conaled-wave-20261111/462-tests-9.log` passed, with full receipts
under462-preparation/tests-9. Normal type/audit rejection is retained. Additional
real failure tests first successfully check requirements, then cause executable
permission failure (actual runner74), terminate the launched checker, or corrupt
the runner state (actual exit1 traceback). All report checker failure, not rejected
evidence. Initial injection harness attempts are retained in tests6–8; they
exposed PATH fallback and the Nix Lake wrapper's dirname dependency, then passed.
No success output is mocked by the forwarding launcher.

Protocol also now requires fixed complete-task submission filenames and forbids
mutable author-module imports; helpers reside in the fully snapshotted checked
source/support. Exact paths remain coordinator launch-manifest work. All commands
finished, checkout clean, Python syntax and diff checks passed. New independent
review/full candidate receipt remains required; no authors launched.
